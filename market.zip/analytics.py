"""All financial and as-of calculations are shared by the UI and the agent."""
import re
import sqlite3
from contextlib import closing
from statistics import median
from datetime import date, timedelta
from difflib import SequenceMatcher
from archive import MAIN, COMP, OTHER, PEOPLE
from risk_model import HISTORY as PAYMENT_HISTORY

MISSING="В подключенных источниках на выбранную дату подтверждение не найдено"
CONFUSABLE=str.maketrans("авекмнорстухё","abekmhopctyxe")


def norm(s):
    return re.sub(r"[^a-zа-я0-9]", "", (s or "").lower().translate(CONFUSABLE))


def rows(db,sql,params=()):
    return [dict(row) for row in db.execute(sql,params)]


def moment(day,clock=None):
    date.fromisoformat(day)
    if clock and not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d",clock):
        raise ValueError("Некорректное время")
    return day+"T"+(clock+":59" if clock else "23:59:59")


def visible(col):
    # Unknown publication time becomes visible at the end of its day.
    return f"(CASE WHEN length({col})=10 THEN {col}||'T23:59:59' ELSE {col} END)<=?"


def dated_plans(db, issuer, cutoff):
    """Prefer detailed schedules over the latest board snapshot for the same payment."""
    plans=rows(db,"""SELECT p.*,b.name FROM plans p JOIN bonds b ON p.bond=b.id
        WHERE b.issuer=? AND p.date>=? AND """+visible("p.known")+" ORDER BY p.date,p.known DESC",
        (issuer,cutoff[:10],cutoff))
    unique={}
    latest_board={}
    announcements={}
    for p in plans:
        if p["id"].startswith("announced:"):
            announcements.setdefault((p["bond"],p["date"],p["kind"]),p)
        elif p["id"].startswith("next:"):
            previous=latest_board.get(p["bond"])
            if previous is None or p["known"]>previous["known"]:
                latest_board[p["bond"]]=p
        else:
            unique.setdefault((p["bond"],p["date"],p["kind"]),p)
    for p in latest_board.values():
        unique.setdefault((p["bond"],p["date"],p["kind"]),p)
    for key,p in announcements.items():unique.setdefault(key,p)
    return sorted(unique.values(),key=lambda p:(p["date"],p["name"] or ""))


def search(db, cutoff, query="", issuer="", currency="", circulation="", event="", offset=0, limit=25, exact_partial=False):
    day=cutoff[:10]
    records=rows(db,"""SELECT b.id,b.isin,b.secid,b.name,b.short,b.issuer,i.name issuer_name,i.inn,
        b.currency,b.traded,b.registered,b.seen,min(h.firstday) firstday,max(h.lastday) lastday
        FROM bonds b JOIN issuers i ON i.id=b.issuer LEFT JOIN boards h ON h.bond=b.id
        GROUP BY b.id""")
    evidence={r[0] for r in db.execute("""SELECT DISTINCT e.bond FROM events e JOIN documents d ON d.id=e.document
        WHERE e.kind IN ('Просрочка','Исполнение','Раскрытие') AND """+visible("d.published"),(cutoff,))}
    evidence.update(r[0] for r in db.execute("SELECT DISTINCT bond FROM moex_defaults WHERE observed<=?",(cutoff,)))
    if PAYMENT_HISTORY.exists():
        with closing(sqlite3.connect(PAYMENT_HISTORY.as_uri()+"?mode=ro",uri=True)) as hist:
            evidence.update(r[0] for r in hist.execute("""SELECT bond FROM evidence WHERE """+visible("published")+"""
                GROUP BY bond,due,kind HAVING min(late)=max(late)""",(cutoff,)))
    from credit_data import ISSUER_PROFILES
    query=next((p["inn"] for p in ISSUER_PROFILES if query.strip()==p["ogrn"] and p["known"]<=cutoff),query)
    query_key=norm(query)
    ranked=[]
    from credit_data import covered_bonds
    allowed = covered_bonds(db, cutoff)
    for b in records:
        if b['id'] not in allowed:
            if not exact_partial or not b["isin"] or query.strip().upper()!=b["isin"]:continue
            b["partial"]=True
        first=b["registered"] or b["firstday"] or (b["seen"] or "")[:10]
        if not first or first>day:
            continue
        b["event"]=b["id"] in evidence
        b["currency"]="RUB" if b["currency"] in ("SUR","RUR") else b["currency"]
        # Admission intervals describe the recorded board history, not proof of redemption.
        if b["seen"] and cutoff>=b["seen"] and b["traded"] is not None:
            status="В обращении" if b["traded"] else "Архив"
        elif b["firstday"] and b["lastday"]:
            status="В обращении" if b["firstday"]<=day<=b["lastday"] else "Архив" if day>b["lastday"] else "Нет сведений"
        else:
            status="Нет сведений"
        b["status"]=status
        if issuer and issuer!=b["issuer"] and norm(issuer) not in norm(b["issuer_name"]):
            continue
        if currency and b["currency"]!=currency or circulation and status!=circulation or event and not b["event"]:
            continue
        rank=0
        if query_key:
            names=[norm(b[k]) for k in ("id","secid","name","short","issuer_name","inn")]
            if query_key in names:
                rank=0
            elif any(query_key in name for name in names):
                rank=1
            else:
                if len(query_key)<4 or re.fullmatch(r"[a-z]{2}\w{10}",query_key) and any(c.isdigit() for c in query_key):
                    continue
                words=[norm(w) for w in re.findall(r"[\w-]+",(b["name"] or "")+" "+b["issuer_name"])]
                if not any(abs(len(w)-len(query_key))<=2 and SequenceMatcher(None,w,query_key).ratio()>=0.79 for w in words):
                    continue
                rank=2
        priority=(0 if status=="В обращении" else 1)
        ranked.append((rank,priority,b["name"] or "",b["id"],b))
    ranked.sort(key=lambda r:r[:4])
    issuers={r[4]["issuer"]:r[4]["issuer_name"] for r in ranked}
    return {"total":len(ranked),"items":[r[4] for r in ranked[offset:offset+limit]],"issuer_summary":next(iter(issuers.values())) if len(issuers)==1 else None}


def registry(db,bond,cutoff,issuer=None):
    where="b.issuer=?" if issuer else "b.id=?"
    return [dict(r) for r in db.execute(f"""SELECT m.*,b.name FROM moex_defaults m JOIN bonds b ON b.id=m.bond
        WHERE {where} AND m.observed<=? AND (b.issuer=m.inn OR m.inn='' OR b.issuer NOT GLOB '[0-9]*')
          AND m.observed=(SELECT max(v.observed) FROM moex_defaults v WHERE v.record_id=m.record_id AND v.observed<=?)
        ORDER BY m.due DESC,m.record_id DESC""",(issuer or bond,cutoff,cutoff))]


class CoverageError(ValueError):
    """A known issue has insufficient coverage at the cutoff."""
    def __init__(self, bond):
        super().__init__("Выпуск вне покрытия на выбранную дату")
        self.identity={k:bond[k] for k in ("id","name","isin","inn","issuer_name")}

    def payload(self):
        return {"code":"coverage","error":str(self),"identity":self.identity}


def snapshot(db,key,cutoff,horizon=90,period=30,board=None,*,prefer_primary=False):
    day=date.fromisoformat(cutoff[:10])
    result=rows(db,"SELECT b.*,i.name issuer_name,i.inn FROM bonds b JOIN issuers i ON b.issuer=i.id WHERE b.id=?",(key,))
    if not result:
        raise ValueError("Выпуск отсутствует в каталоге")
    from credit_data import covered_bonds
    allowed = covered_bonds(db, cutoff)
    if key not in allowed:
        raise CoverageError(result[0])
    bond=result[0]
    first=bond["registered"] or db.execute("SELECT min(firstday) FROM boards WHERE bond=?",(key,)).fetchone()[0] or (bond["seen"] or "")[:10]
    if first and first>str(day):
        raise ValueError("Выпуск ещё не был известен на эту дату")
    issuer=bond["issuer"]
    # Current outstanding nominal and status may reflect later amortization or delisting.
    if not bond["seen"] or bond["seen"]>cutoff:
        bond.update(traded=None,nominal=1000 if key in (MAIN,OTHER) else None,primary_board=None)
        if not bond["registered"]:
            bond["maturity"]=None
    docs=rows(db,"SELECT * FROM documents WHERE issuer=? AND (bond IS NULL OR bond=?) AND "+visible("published")+" ORDER BY published DESC",(issuer,key,cutoff))
    events=rows(db,"""SELECT e.*,d.published,d.url,d.body,d.publisher FROM events e JOIN documents d ON e.document=d.id
        WHERE e.issuer=? AND (e.bond IS NULL OR e.bond=?) AND """+visible("d.published")+" ORDER BY d.published DESC,e.day DESC",(issuer,key,cutoff))
    start=str(day-timedelta(days=period-1))
    # Daily close is only available for a completed session.
    last=str(day if cutoff.endswith("23:59:59") else day-timedelta(days=1))
    boards=[r[0] for r in db.execute("""SELECT board FROM quotes WHERE bond=? AND day<=? GROUP BY board
        ORDER BY CASE board WHEN 'TQCB' THEN 0 WHEN 'TQOB' THEN 0 ELSE 1 END,sum(trades) DESC""",(key,last))]
    for (listed,) in db.execute("""SELECT DISTINCT board FROM boards WHERE bond=? AND firstday<=?
         AND lastday>=? ORDER BY CASE WHEN board=? THEN 0 WHEN board IN ('TQCB','TQOB') THEN 1 ELSE 2 END,board""",
         (key,last,start,bond["primary_board"])):
        if listed not in boards:boards.append(listed)
    primary=bond["primary_board"]
    preferred=primary if prefer_primary and primary in boards else None
    chosen=board if board in boards else preferred or (boards[0] if boards else None)
    quotes=rows(db,"SELECT * FROM quotes WHERE bond=? AND board=? AND day BETWEEN ? AND ? ORDER BY day",(key,chosen,start,last))
    latest=rows(db,"SELECT * FROM quotes WHERE bond=? AND board=? AND day<=? ORDER BY day DESC LIMIT 1",(key,chosen,last))
    if chosen:
        from credit_data import saved_prices
        extra=saved_prices(bond["secid"],chosen,start,last)
        combined={r["day"]:r for r in quotes}
        combined.update({r["day"]:r for r in extra})
        if chosen=="TQCB" and PAYMENT_HISTORY.exists():
            with closing(sqlite3.connect(PAYMENT_HISTORY.as_uri()+"?mode=ro",uri=True)) as hist:
                for trading_day,close in hist.execute("SELECT day,close FROM prices WHERE bond=? AND day BETWEEN ? AND ?",(key,start,last)):
                    combined.setdefault(trading_day,{"day":trading_day,"price":close,"board":chosen,
                                        "volume":None,"trades":None,"yield_close":None})
        quotes=[combined[k] for k in sorted(combined)]
        if quotes and (not latest or latest[0]["day"]<=quotes[-1]["day"]):latest=[quotes[-1]]
    future=dated_plans(db,issuer,cutoff)
    plans=[p for p in future if p["date"]<str(day+timedelta(days=horizon))]
    next_rows=[p for p in future if p["bond"]==key and p["date"]>=str(day)]
    history=rows(db,"""SELECT x.*,p.label,p.kind,p.currency,p.date,d.url,d.publisher,d.published FROM executions x JOIN plans p ON p.id=x.plan
        JOIN documents d ON d.id=x.document WHERE p.bond=? AND """+visible("d.published")+" ORDER BY x.day,d.published",(key,cutoff))
    payment=None
    if history:
        latest_plan=max(history,key=lambda r:(r["date"],r["label"].startswith("Купон")))["plan"]
        relevant=[r for r in history if r["plan"]==latest_plan]
        payment=dict(relevant[-1])
        for field in ("planned","overdue","remaining"):
            payment[field]=next((r[field] for r in reversed(relevant) if r[field] is not None),None)
        p,o=payment["planned"],payment["overdue"]
        payment["ontime"]=round(p-o,2) if p is not None and o is not None else None
        payment["late"]=o if payment["remaining"]==0 and o is not None else None
        payment["percent"]=round(100*o/p,1) if p and o is not None else None
        payment["proofs"]=list(dict.fromkeys(r["url"] for r in relevant))
    news=rows(db,"SELECT * FROM news WHERE (scope='Рынок' OR (issuer=? AND (bond IS NULL OR bond=?))) AND "+visible("published")+" ORDER BY published DESC LIMIT 100",(issuer,key,cutoff))
    shortlist=rows(db,"""SELECT b.id,b.name,b.isin,
        (SELECT max(day) FROM quotes WHERE bond=b.id AND day<=?) last_trade
        FROM bonds b WHERE b.issuer=? AND b.id<>? AND
        (b.registered<=? OR EXISTS (SELECT 1 FROM boards h WHERE h.bond=b.id AND h.firstday<=?))
        ORDER BY last_trade DESC,b.name LIMIT 5""",(last,issuer,key,str(day),str(day)))
    return {"bond":bond,"asof":cutoff,"documents":docs,"events":events,"quotes":quotes,"board":chosen,
            "boards":boards,"last":latest[0] if latest else None,"plans":plans,"next":next_rows[0] if next_rows else None,
            "history":history,"payment":payment,"news":news,"shortlist":[r for r in shortlist if r["id"] in allowed],"registry":registry(db,key,cutoff),"start":start,"horizon":horizon}


def coverage(db):
    return {"registry_records":db.execute("SELECT count(DISTINCT record_id) FROM moex_defaults").fetchone()[0],
            "registry_bonds":db.execute("SELECT count(DISTINCT m.bond) FROM moex_defaults m JOIN bonds b ON m.bond=b.id WHERE m.inn=b.issuer OR m.inn=''").fetchone()[0],
            "bonds":db.execute("SELECT count(*) FROM bonds").fetchone()[0],
            "quotes":db.execute("SELECT count(DISTINCT bond) FROM quotes").fetchone()[0],
            "plans":db.execute("SELECT count(DISTINCT bond) FROM plans").fetchone()[0],
            "verified":db.execute("SELECT count(DISTINCT p.bond) FROM plans p JOIN executions x ON x.plan=p.id").fetchone()[0],
            "docs":db.execute("SELECT count(*) FROM documents").fetchone()[0],
            "boards":db.execute("SELECT count(DISTINCT board) FROM boards").fetchone()[0],
            "refresh":rows(db,"SELECT * FROM refresh ORDER BY source")}


def peer_move(db, bond, board, day):
    """Same-board comparison using two observed closes and identical measurement dates."""
    prev=db.execute("SELECT max(day) FROM quotes WHERE bond=? AND board=? AND day<?",(bond,board,day)).fetchone()[0]
    if not prev or (date.fromisoformat(day)-date.fromisoformat(prev)).days>4:
        return None
    peers=[r[0] for r in db.execute("""SELECT a.price-b.price FROM quotes a JOIN quotes b
        ON a.bond=b.bond AND a.board=b.board WHERE a.board=? AND a.day=? AND b.day=? AND a.bond<>?""",
        (board,day,prev,bond))]
    return {"from":prev,"to":day,"sample":len(peers),"median_pp":round(median(peers),3)} if len(peers)>=20 else None
