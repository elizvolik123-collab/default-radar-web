"""Read the same dated market data on the server and in the browser."""
import sqlite3
from contextlib import closing
from datetime import date, timedelta
from urllib.parse import urlsplit
from analytics import coverage, moment, search, snapshot
from risk_model import HISTORY, forecast, market_watch, payment_history, report
from storage import now
from credit_data import DB, market, issuer_reports, issuer_filings, bond_terms, open_data
from bond_radar import assess
from credit_data import credit_spreads
from terminal import screen, WEIGHTS, LABELS
from payment_journal import entries


def source_register(catalog):
    """Count only saved observations. The publication date is independent of the job status."""
    sources = []
    archive = list(catalog.execute("SELECT url,published FROM documents"))

    def add(name, access, link, unit, stats=(None, None)):
        sources.append(dict(name=name, access=access, url=link, unit=unit, count=stats[0], latest=stats[1]))

    def count(db, table, date_field, where=""):
        if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone():
            return None, None
        return db.execute(f"SELECT count(*), max({date_field}) FROM {table} {where}").fetchone()

    add("Московская биржа · реестр нарушений", "Ежедневная загрузка", "https://www.moex.com/ru/listing/emidocs.aspx?type=4",
        "версий записей", count(catalog, "moex_defaults", "observed"))
    if DB.is_file():
        with closing(open_data()) as facts:
            if facts.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='filings'").fetchone():
                archive.extend(facts.execute("""SELECT f.url,f.published FROM filings f
                    WHERE f.removed=0 AND f.url<>'' AND f.published=(
                    SELECT max(v.published) FROM filings v WHERE v.issuer=f.issuer AND v.uid=f.uid)"""))
            add("Московская биржа · история торгов", "MOEX ISS · ежедневная загрузка", "https://iss.moex.com/iss/reference/",
                "дневных записей по режимам торгов", count(facts, "daily", "day"))
            add("Банк России · ключевая ставка", "Официальный веб-сервис · ежедневная загрузка", "https://www.cbr.ru/hd_base/KeyRate/",
                "значений", count(facts, "series", "day", "WHERE code='KEY'"))
            add("Банк России · КБД", "Официальная таблица · ежедневная загрузка", "https://www.cbr.ru/hd_base/zcyc_params/",
                "узлов кривой", count(facts, "curve", "day"))
            add("Smart-Lab · финансовые показатели", "Агрегатор · ежедневная загрузка по сопоставленным ИНН",
                "https://smart-lab.ru/q/shares_fundamental/", "отчётных периодов по эмитентам",
                count(facts, "reports", "published", "WHERE url LIKE 'https://smart-lab.ru/%'"))
            cursor = count(facts, "disclosure_cursor", "event_id")[0]
            access = "Сохранён курсор договорного API" if cursor else "Архив документов · для регулярной загрузки нужен ключ Интерфакса"
            add("Интерфакс · ЦРКИ", access, "https://www.e-disclosure.ru/poluchenie-informacii/shlyuz-api",
                "версий документов в архиве", count(facts, "filings", "published",
                    "WHERE url LIKE 'https://www.e-disclosure.ru/%' OR url LIKE 'https://e-disclosure.ru/%'"))
            add("MarketTwits", "Новостные заголовки · ежедневная загрузка", "https://t.me/markettwits",
                "публикаций", count(facts, "headlines", "published"))
    outcome_bonds = None
    if HISTORY.is_file():
        with closing(sqlite3.connect(HISTORY.as_uri()+"?mode=ro", uri=True)) as payments:
            outcome_bonds = payments.execute("SELECT count(DISTINCT bond) FROM evidence").fetchone()[0]
            add("АК&М · сообщения эмитентов", "Ежедневная выборка раскрытий", "https://www.disclosure.ru/rus/corpnews/",
                "свидетельств о платежах", count(payments, "evidence", "published", "WHERE source='Раскрытие эмитента · АК&М'"))
    for name, url, domains, access in (
        ("ФНС · ГИР БО", "https://bo.nalog.gov.ru/about", ("bo.nalog.gov.ru","bo.nalog.ru"), "Импорт ссылок на отчёты · массовая выгрузка по подписке ФНС"),
        ("НРД", "https://nsddata.ru/", ("nsddata.ru","nsd.ru"), "Импорт документов о корпоративных действиях"),
        ("Федресурс", "https://fedresurs.ru/", ("fedresurs.ru",), "Импорт сообщений о юридически значимых событиях"),
        ("Картотека арбитражных дел", "https://kad.arbitr.ru/", ("arbitr.ru",), "Импорт судебных актов по делу"),
        ("ФССП", "https://fssp.gov.ru/iss/ip/", ("fssp.gov.ru",), "Импорт документов по исполнительным производствам"),
        ("АКРА", "https://www.acra-ratings.ru/", ("acra-ratings.ru",), "Импорт оригинальных рейтинговых релизов"),
        ("Эксперт РА", "https://raexpert.ru/", ("raexpert.ru",), "Архив отдельных решений и импорт релизов"),
        ("НКР", "https://ratings.ru/", ("ratings.ru",), "Архив отдельных решений и импорт релизов"),
        ("НРА", "https://www.ra-national.ru/", ("ra-national.ru",), "Импорт оригинальных рейтинговых релизов"),
    ):
        dates = {}
        for document, published in archive:
            if not document or not published:
                continue
            host = urlsplit(document).hostname or ""
            if any(host==d or host.endswith("."+d) for d in domains):
                dates[document] = max(published, dates.get(document,""))
        latest = max(dates, key=dates.get, default=None)
        add(name, access, url, "документов в архиве", (len(dates), dates.get(latest)))
        if latest:
            sources[-1]["latest_url"] = latest
    return {"source_registry":sources, "outcome_bonds":outcome_bonds}


def context(params):
    cutoff=moment(str(params.get("date",now()[:10])),params.get("time"))
    horizon=int(params.get("horizon",90))
    period=int(params.get("period",30))
    if horizon not in (30,90) or period not in (7,14,30,90,180,365,36500):
        raise ValueError("Период вне диапазона")
    week=params.get("week")
    week_end=None
    if week:
        start=date.fromisoformat(week)
        week_end=str(start+timedelta(days=7))
        if not (cutoff[:10]<=week<str(date.fromisoformat(cutoff[:10])+timedelta(days=horizon))):
            week=None
    point=params.get("point")
    if point and (date.fromisoformat(point)>date.fromisoformat(cutoff[:10])):
        point=None
    return {"at":cutoff,"id":str(params.get("id",""))[:80],"period":period,"horizon":horizon,
            "week":week,"week_end":week_end,"point":point,"board":params.get("board"),
            "event":str(params.get("event",""))[:60],"specific":params.get("specific") in (True,"1"),
            "choice_id":str(params.get("choice_id",""))[:80]}


def market_overview(db, at):
    day = at[:10]
    plans=db.execute("""SELECT b.id,b.name,b.issuer,p.date,p.kind,p.source
      FROM plans p JOIN bonds b ON b.id=p.bond WHERE p.date>? AND
      (CASE WHEN length(p.known)=10 THEN p.known||'T23:59:59' ELSE p.known END)<=?
      ORDER BY p.date,b.name,p.known DESC""",(day,at))
    seen=set();upcoming=[]
    for p in plans:
        if p["issuer"] not in seen:
            upcoming.append(dict(p));seen.add(p["issuer"])
        if len(upcoming)==8:break
    research=report()
    return {"upcoming": upcoming, **market(at), "research": research if research and day >= research["built"] else None}


def read_api(db, path, params, model):
    if path == "/api/coverage":
        mode, name = model
        return {**coverage(db), **source_register(db), "model": mode not in ("archive", "browser"),
                "provider": mode, "model_name": name}
    c = context(params)
    if path=="/api/screen":return screen(c["at"],params)
    if path == "/api/fundamentals":
        inn=params.get("issuer","")
        return {"issuer":inn,"asof":c["at"],"reports":issuer_reports(inn,c["at"]),"filings":issuer_filings(inn,c["at"])}
    if path == "/api/macro":
        return market(c["at"])
    if path == "/api/search":
        return search(db, c["at"], params.get("q", "")[:160], params.get("issuer", "")[:150],
                      params.get("currency", ""), params.get("status", ""), params.get("event_filter", ""),
                      max(0, int(params.get("offset", 0))), 20)
    if path == "/api/bond":
        current_session=params.get("mode")=="live" and not params.get("time") and c["at"][:10]==now()[:10]
        bond = snapshot(db, c["id"], c["at"], c["horizon"], c["period"], c["board"],prefer_primary=current_session)
        profile=screen(c["at"],{"one":c["id"]})
        spreads=credit_spreads(bond["bond"]["secid"],bond["board"],bond["start"],c["at"])
        return {**bond,"spreads":spreads,**assess(db,bond),"expert":profile,"weights":WEIGHTS,"block_labels":LABELS,
                "payment_journal":entries(c["id"],c["at"]),"terms":bond_terms(c["id"],c["at"])}
    if path == "/api/watch":
        return market_watch(db, c["at"])
    if path == "/api/market":
        return market_overview(db, c["at"])
    raise KeyError(path)
