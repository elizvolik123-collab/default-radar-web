"""Read the same dated market data on the server and in the browser."""
import sqlite3
import json
from pathlib import Path
from contextlib import closing
from datetime import date, timedelta
from urllib.parse import urlsplit
from analytics import coverage, moment, search, snapshot
from risk_model import HISTORY, forecast, market_watch, payment_history, report
from storage import now
from credit_data import period_date, fns_totals, DB, market, issuer_reports, issuer_filings, bond_terms, open_data
from bond_radar import assess
from credit_data import credit_spreads
from terminal import screen, WEIGHTS, LABELS
from payment_journal import entries


def source_register(catalog):
    """Count only saved observations. The publication date is independent of the job status."""
    sources = []
    archive = list(catalog.execute("SELECT url,published FROM documents"))

    def add(name, access, link, unit, stats=(None, None)):
        sources.append(dict(name=name, access=access, url=link, unit=unit, count=stats[0], latest=stats[1]))

    def count(db, table, date_field, where=""):
        if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone():
            return None, None
        return db.execute(f"SELECT count(*), max({date_field}) FROM {table} {where}").fetchone()

    add("Московская биржа · реестр нарушений", "Ежедневная загрузка", "https://www.moex.com/ru/listing/emidocs.aspx?type=4",
        "версий записей", count(catalog, "moex_defaults", "observed"))
    if DB.is_file():
        with closing(open_data()) as facts:
            if facts.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='filings'").fetchone():
                archive.extend(facts.execute("""SELECT f.url,f.published FROM filings f
                    WHERE f.removed=0 AND f.url<>'' AND f.published=(
                    SELECT max(v.published) FROM filings v WHERE v.issuer=f.issuer AND v.uid=f.uid)"""))
            add("Московская биржа · история торгов", "MOEX ISS · ежедневная загрузка", "https://iss.moex.com/iss/reference/",
                "дневных записей по режимам торгов", count(facts, "daily", "day"))
            add("Банк России · ключевая ставка", "Официальный веб-сервис · ежедневная загрузка", "https://www.cbr.ru/hd_base/KeyRate/",
                "значений", count(facts, "series", "day", "WHERE code='KEY'"))
            add("Банк России · КБД", "Официальная таблица · ежедневная загрузка", "https://www.cbr.ru/hd_base/zcyc_params/",
                "узлов кривой", count(facts, "curve", "day"))
            add("Smart-Lab · финансовые показатели", "Агрегатор · ежедневная загрузка по сопоставленным ИНН",
                "https://smart-lab.ru/q/shares_fundamental/", "отчётных периодов по эмитентам",
                count(facts, "reports", "published", "WHERE url LIKE 'https://smart-lab.ru/%'"))
            cursor = count(facts, "disclosure_cursor", "event_id")[0]
            access = "Сохранён курсор договорного API" if cursor else "Архив документов · для регулярной загрузки нужен ключ Интерфакса"
            add("Интерфакс · ЦРКИ", access, "https://www.e-disclosure.ru/poluchenie-informacii/shlyuz-api",
                "версий документов в архиве", count(facts, "filings", "published",
                    "WHERE url LIKE 'https://www.e-disclosure.ru/%' OR url LIKE 'https://e-disclosure.ru/%'"))
            add("MarketTwits", "Новостные заголовки · ежедневная загрузка", "https://t.me/markettwits",
                "публикаций", count(facts, "headlines", "published"))
    outcome_bonds = None
    if HISTORY.is_file():
        with closing(sqlite3.connect(HISTORY.as_uri()+"?mode=ro", uri=True)) as payments:
            outcome_bonds = payments.execute("SELECT count(DISTINCT bond) FROM evidence").fetchone()[0]
            add("АК&М · сообщения эмитентов", "Ежедневная выборка раскрытий", "https://www.disclosure.ru/rus/corpnews/",
                "свидетельств о платежах", count(payments, "evidence", "published", "WHERE source='Раскрытие эмитента · АК&М'"))
    for name, url, domains, access in (
        ("ФНС · ГИР БО", "https://bo.nalog.gov.ru/about", ("bo.nalog.gov.ru","bo.nalog.ru"), "Импорт ссылок на отчёты · массовая выгрузка по подписке ФНС"),
        ("НРД", "https://nsddata.ru/", ("nsddata.ru","nsd.ru"), "Импорт документов о корпоративных действиях"),
        ("Федресурс", "https://fedresurs.ru/", ("fedresurs.ru",), "Импорт сообщений о юридически значимых событиях"),
        ("Картотека арбитражных дел", "https://kad.arbitr.ru/", ("arbitr.ru",), "Импорт судебных актов по делу"),
        ("ФССП", "https://fssp.gov.ru/iss/ip/", ("fssp.gov.ru",), "Импорт документов по исполнительным производствам"),
        ("АКРА", "https://www.acra-ratings.ru/", ("acra-ratings.ru",), "Импорт оригинальных рейтинговых релизов"),
        ("Эксперт РА", "https://raexpert.ru/", ("raexpert.ru",), "Архив отдельных решений и импорт релизов"),
        ("НКР", "https://ratings.ru/", ("ratings.ru",), "Архив отдельных решений и импорт релизов"),
        ("НРА", "https://www.ra-national.ru/", ("ra-national.ru",), "Импорт оригинальных рейтинговых релизов"),
    ):
        dates = {}
        for document, published in archive:
            if not document or not published:
                continue
            host = urlsplit(document).hostname or ""
            if any(host==d or host.endswith("."+d) for d in domains):
                dates[document] = max(published, dates.get(document,""))
        latest = max(dates, key=dates.get, default=None)
        add(name, access, url, "документов в архиве", (len(dates), dates.get(latest)))
        if latest:
            sources[-1]["latest_url"] = latest
    return {"source_registry":sources, "outcome_bonds":outcome_bonds}


def context(params):
    cutoff=moment(str(params.get("date",now()[:10])),params.get("time"))
    horizon=int(params.get("horizon",90))
    period=int(params.get("period",30))
    if horizon not in (30,90) or period not in (7,14,30,90,180,365,36500):
        raise ValueError("Период вне диапазона")
    week=params.get("week")
    week_end=None
    if week:
        start=date.fromisoformat(week)
        week_end=str(start+timedelta(days=7))
        if not (cutoff[:10]<=week<str(date.fromisoformat(cutoff[:10])+timedelta(days=horizon))):
            week=None
    point=params.get("point")
    if point and (date.fromisoformat(point)>date.fromisoformat(cutoff[:10])):
        point=None
    return {"at":cutoff,"id":str(params.get("id",""))[:80],"period":period,"horizon":horizon,
            "week":week,"week_end":week_end,"point":point,"board":params.get("board"),
            "event":str(params.get("event",""))[:60],"specific":params.get("specific") in (True,"1"),
            "choice_id":str(params.get("choice_id",""))[:80],
            "trend_key":str(params.get("trend_key",""))[:64],"trend_period":str(params.get("trend_period",""))[:12],
            "previous_period":str(params.get("previous_period",""))[:12]}


FIRST_COUPONS=json.loads((Path(__file__).resolve().parent/"data/first_coupons.json").read_text("utf-8"))

def market_attention(db, at, allowed, watch):
    from payment_journal import calendar_outcomes
    day=date.fromisoformat(at[:10])
    previous=(day-timedelta(days=1)).isoformat()+"T23:59:59"
    names=dict(db.execute("SELECT id,name FROM bonds"))
    items=[]
    def add(group,bond,due,kind,url):
        items.append(dict(group=group,id=bond,name=names[bond],due=due,kind=kind,url=url))
    facts=calendar_outcomes(db,"0001-01-01",(day+timedelta(days=1)).isoformat(),at)
    for (bond,due,kind),rows in facts.items():
        if bond not in names:continue
        new=[r for r in rows if r["published"][:10]==day.isoformat()]
        if not new:continue
        if all(r["late"] and not r["actual"] for r in rows):
            add("overdue",bond,due,kind,new[0]["url"])
        elif bond in allowed and len({r["actual"] for r in rows})==1 and all(r["actual"] for r in rows) and not any(r["actual"] for r in rows if r["published"][:10]<day.isoformat()):
            add("paid",bond,due,kind,new[0]["url"])
    old={(r["id"],r["due"],r["kind"]):r for r in market_watch(db,previous)["rows"]}
    for r in watch["rows"]:
        prior=old.get((r["id"],r["due"],r["kind"]))
        if r["alert"] and prior and not prior["alert"]:
            add("raised",r["id"],r["due"],r["kind"],r["url"])
    end=(day+timedelta(days=7)).isoformat()
    for bond,due,kind,url in db.execute("""SELECT bond,date,kind,source FROM plans WHERE date BETWEEN ? AND ?
        AND source LIKE 'http%' AND (CASE WHEN length(known)=10 THEN known||'T23:59:59' ELSE known END)<=?
        ORDER BY date,known""",(day.isoformat(),end,at)):
        if bond in allowed and due==end and not db.execute("""SELECT 1 FROM plans WHERE bond=? AND date BETWEEN ? AND ?
            AND source LIKE 'http%' AND (CASE WHEN length(known)=10 THEN known||'T23:59:59' ELSE known END)<=?""",
            (bond,previous[:10],(day+timedelta(days=6)).isoformat(),previous)).fetchone():
            add("entered",bond,due,kind,url)
    unique={}
    for item in items:unique.setdefault((item["group"],item["id"],item["due"],item["kind"]),item)
    return sorted(unique.values(),key=lambda r:(["overdue","raised","paid","entered"].index(r["group"]),r["due"],r["name"]))

def full_analysis(db, at, allowed, watch=None, details=False):
    from credit_data import statement_trends
    from payment_journal import calendar_outcomes
    day=date.fromisoformat(at[:10])
    scored={r["id"]:r for r in (watch if watch is not None else market_watch(db,at))["rows"]}
    facts=calendar_outcomes(db,"0001-01-01",day.isoformat(),at)
    previous={}
    for bond,due,kind in facts:
        previous.setdefault(bond,set()).add((due,kind))
    for bond,due,kind in db.execute("""SELECT bond,date,kind FROM plans WHERE date<? AND source LIKE 'http%'
        AND (CASE WHEN length(known)=10 THEN known||'T23:59:59' ELSE known END)<=?""",(day.isoformat(),at)):
        previous.setdefault(bond,set()).add((due,kind))
    issuers=dict(db.execute("SELECT id,issuer FROM bonds"))
    comparable={}
    next_dates=dict(db.execute("""SELECT bond,min(date) FROM plans WHERE date>=? AND source LIKE 'http%'
        AND (CASE WHEN length(known)=10 THEN known||'T23:59:59' ELSE known END)<=? GROUP BY bond""",(day.isoformat(),at)))
    with closing(open_data()) as store:
        terms_by_bond={r["bond"]:r for r in store.execute("SELECT * FROM terms WHERE seen<=? ORDER BY seen",(at,))}
    missing=dict(price=0,accrued=0,coupon=0,coupon_date=0,previous=0,no_previous_date=0,reports=0,stale_reports=0)
    missing_scored=dict.fromkeys(missing,0)
    outside=inside_unscored=sovereign=0
    ready=[]
    quality={}
    for bond in allowed:
        row=scored.get(bond)
        in_window=next_dates[bond]<=(day+timedelta(days=7)).isoformat()
        outside+=int(not in_window)
        inside_unscored+=int(in_window and not row)
        terms=terms_by_bond.get(bond)
        sourced=terms is not None and bool(terms["source"])
        accrued=sourced and terms["accrued"] is not None
        coupon=sourced and terms["coupon"] is not None
        dated=sourced and bool(terms["due"]) and terms["due"]>=day.isoformat()
        if row and row["kind"]=="Купон":
            dated=dated and terms["due"]==row["due"]
        prior=previous.get(bond,set())
        latest=max((d for d,k in prior),default=None)
        def confirmed(kind):
            records=facts.get((bond,latest,kind),[])
            return (len({r["late"] for r in records})==1 and
                    len({r["actual"] for r in records if r["actual"]})==1)
        previous_paid=bool(prior) and all(confirmed(k) for d,k in prior if d==latest)
        inn=issuers[bond]
        if inn not in comparable:
            trends=statement_trends(issuer_reports(inn,at), limit=None)
            fresh=False
            for trend in trends:
                period=trend["points"][-1]["period"]
                end=period_date(period)
                if 0<=(day-end).days<=370:
                    fresh=True
                    break
            comparable[inn]=bool(trends),fresh
        pair,fresh=comparable[inn]
        federal=inn=="7710168360"
        sovereign+=int(federal)
        for key,absent in (("accrued",not accrued),("coupon",not coupon),("coupon_date",not dated),
                           ("previous",not previous_paid),("no_previous_date",not prior),("reports",not pair and not federal),("stale_reports",pair and not fresh)):
            missing[key]+=int(absent)
            if row:missing_scored[key]+=int(absent)
        if details:
            records=[r for d,k in prior if d==latest for r in facts.get((bond,d,k),[])]
            evidence_state="confirmed" if previous_paid else "unknown"
            for d,k in sorted(prior):
                if d!=latest:continue
                group=facts.get((bond,d,k),[])
                if len({r["actual"] for r in group if r["actual"]})>1 or len({r["late"] for r in group})>1:
                    evidence_state="conflict"
                    break
                if group and all(r["late"] and not r["actual"] for r in group):
                    evidence_state="overdue"
            first=FIRST_COUPONS.get(bond)
            if not latest and first and first["verified"]<=at and day.isoformat()<=first["due"] and next_dates[bond]==first["due"]:
                evidence_state="first"
            documents=list(dict.fromkeys(r["url"] for r in records))
            if evidence_state=="first":
                documents.extend(first.get("sources",[]))
            quality[bond]=dict(previous=evidence_state, due=latest, fresh=fresh, federal=federal,
                               terms=bool(accrued and coupon and dated), documents=documents)
        if row and accrued and coupon and dated and previous_paid and fresh:
            ready.append(bond)
    return {"total":len(allowed),"scored":len(scored),"full":len(ready),"ids":sorted(ready),"asof":at,
            **({"quality":quality} if details else {}),"missing":missing,"missing_scored":missing_scored,"sovereign":sovereign,"outside_window":outside,"inside_unscored":inside_unscored}



def market_overview(db, at):
    day = at[:10]
    plans=db.execute("""SELECT b.id,b.name,b.issuer,p.date,p.kind,p.source
      FROM plans p JOIN bonds b ON b.id=p.bond WHERE p.date>? AND
      (CASE WHEN length(p.known)=10 THEN p.known||'T23:59:59' ELSE p.known END)<=?
      ORDER BY p.date,b.name,p.known DESC""",(day,at))
    seen=set();upcoming=[]
    from credit_data import covered_bonds
    allowed = covered_bonds(db, at)
    for p in plans:
        if p['id'] not in allowed or not p['source']:
            continue
        if p["issuer"] not in seen:
            upcoming.append(dict(p));seen.add(p["issuer"])
        if len(upcoming)==8:break
    research=report()
    cohort_file=HISTORY.parent/"cohort_validation.json"
    if research and cohort_file.is_file():
        cohort=json.loads(cohort_file.read_text("utf-8"))
        if cohort["asof"]+"T23:59:59"<=at:
            research["cohorts"]=cohort
    watch=market_watch(db,at)
    return {"attention":market_attention(db,at,allowed,watch),"analysis_coverage":full_analysis(db,at,allowed,watch),"upcoming": upcoming, **market(at), "research": research if research and day >= research["built"] else None}


def read_api(db, path, params, model):
    if path == "/api/coverage":
        mode, name = model
        return {**coverage(db), **source_register(db), "model": mode not in ("archive", "browser"),
                "provider": mode, "model_name": name}
    c = context(params)
    if path=="/api/screen":return screen(c["at"],params)
    if path == "/api/fundamentals":
        inn=params.get("issuer","")
        return {"issuer":inn,"asof":c["at"],"fns":fns_totals(inn,c["at"]),"reports":issuer_reports(inn,c["at"]),"filings":issuer_filings(inn,c["at"])}
    if path == "/api/macro":
        return market(c["at"])
    if path == "/api/search":
        return search(db, c["at"], params.get("q", "")[:160], params.get("issuer", "")[:150],
                      params.get("currency", ""), params.get("status", ""), params.get("event_filter", ""),
                      max(0, int(params.get("offset", 0))), 20,exact_partial=True)
    if path == "/api/bond":
        current_session=params.get("mode")=="live" and not params.get("time") and c["at"][:10]==now()[:10]
        bond = snapshot(db, c["id"], c["at"], c["horizon"], c["period"], c["board"],prefer_primary=current_session)
        profile=screen(c["at"],{"one":c["id"]})
        spreads=credit_spreads(bond["bond"]["secid"],bond["board"],bond["start"],c["at"])
        from credit_data import covered_bonds
        assessment=assess(db,bond,with_trends=True)
        prediction=assessment["forecast"]
        rows=[dict(prediction,id=c["id"])] if prediction.get("state")=="signal" else []
        quality=None
        if c["id"] in covered_bonds(db,c["at"]):
            quality=full_analysis(db,c["at"],{c["id"]},{"rows":rows},details=True)["quality"][c["id"]]
        return {**bond,"fns":fns_totals(bond["bond"]["issuer"],c["at"]),"quality":quality,"spreads":spreads,**assessment,"expert":profile,"weights":WEIGHTS,"block_labels":LABELS,
                "payment_journal":entries(c["id"],c["at"]),"terms":bond_terms(c["id"],c["at"])}
    if path == "/api/open-overdue":
        from payment_journal import calendar_outcomes
        names=dict(db.execute("SELECT id,name FROM bonds"))
        end=(date.fromisoformat(c["at"][:10])+timedelta(days=1)).isoformat()
        rows=[]
        for (bond,due,kind),records in calendar_outcomes(db,"0001-01-01",end,c["at"]).items():
            if bond in names and all(r["late"]==1 and not r["actual"] for r in records):
                proof=max(records,key=lambda r:r["published"])
                rows.append(dict(id=bond,name=names[bond],due=due,kind=kind,url=proof["url"],published=proof["published"]))
        return {"rows":sorted(rows,key=lambda r:(r["due"],r["name"]),reverse=True)}
    if path == "/api/payment-calendar":
        from credit_data import covered_bonds
        start = date.fromisoformat(params.get("month", c["at"][:7]) + "-01")
        end = (start + timedelta(days=32)).replace(day=1)
        allowed = covered_bonds(db, c["at"])
        rows = db.execute("""WITH visible AS (
            SELECT p.*, row_number() OVER (PARTITION BY bond, id LIKE 'next:%'
                ORDER BY known DESC,id DESC) AS recency FROM plans p
            WHERE (CASE WHEN length(known)=10 THEN known||'T23:59:59' ELSE known END)<=?
        ) SELECT b.id,b.name,p.date,p.kind,p.source,p.known FROM visible p
          JOIN bonds b ON b.id=p.bond WHERE p.date>=? AND p.date<?
          AND (p.id NOT LIKE 'next:%' OR p.recency=1) AND length(trim(p.source))>0
          ORDER BY p.date,b.name,p.kind,(p.id LIKE 'next:%'),(p.id LIKE 'announced:%'),p.known DESC""",
          (c["at"],start.isoformat(),end.isoformat()))
        events = {}
        for row in rows:
            if row["id"] in allowed:
                events.setdefault((row["id"],row["date"],row["kind"]),dict(row))
        from payment_journal import calendar_outcomes
        names = dict(db.execute("SELECT id,name FROM bonds"))
        facts = calendar_outcomes(db,start.isoformat(),end.isoformat(),c["at"])
        for key,records in facts.items():
            bond,due,kind = key
            open_late = all(r["late"]==1 and not r["actual"] for r in records)
            if bond in names and (bond in allowed or open_late) and key not in events:
                events[key] = dict(id=bond,name=names[bond],date=due,kind=kind,
                    source=next((r["terms"] for r in records if r["terms"]),None),known=None)
        for key,event in events.items():
            records = sorted(facts.get(key,[]),key=lambda r:r["published"],reverse=True)
            dates = {r["actual"] for r in records if r["actual"]}
            flags = {r["late"] for r in records}
            actual = next(iter(dates)) if len(dates)==1 else None
            conflict = len(flags)>1 or len(dates)>1
            status = "planned" if event["date"]>c["at"][:10] else "unconfirmed"
            if not conflict and flags=={1}: status="late"
            if not conflict and flags=={0} and actual: status="ontime"
            event.update(in_catalog=key[0] in allowed,status=status,actual=None if conflict else actual,conflict=conflict,
                evidence=[dict(url=url,published=pub) for url,pub in dict.fromkeys((r["url"],r["published"]) for r in records)])
        return {"payments":sorted(events.values(),key=lambda r:(r["date"],r["name"],r["kind"]))}
    if path == "/api/watch":
        return market_watch(db, c["at"])
    if path == "/api/market":
        return market_overview(db, c["at"])
    raise KeyError(path)
