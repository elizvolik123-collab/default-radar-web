"""Read the same dated market data on the server and in the browser."""
from datetime import date, timedelta
from analytics import coverage, moment, search, snapshot
from risk_model import forecast, market_watch, payment_history, report
from storage import now


def context(params):
    cutoff=moment(str(params.get("date",now()[:10])),params.get("time"))
    horizon=int(params.get("horizon",90))
    period=int(params.get("period",30))
    if horizon not in (30,90) or period not in (14,30,90):
        raise ValueError("Период вне диапазона")
    week=params.get("week")
    week_end=None
    if week:
        start=date.fromisoformat(week)
        week_end=str(start+timedelta(days=7))
        if not (cutoff[:10]<=week<str(date.fromisoformat(cutoff[:10])+timedelta(days=horizon))):
            week=None
    point=params.get("point")
    if point and (date.fromisoformat(point)>date.fromisoformat(cutoff[:10])):
        point=None
    return {"at":cutoff,"id":str(params.get("id",""))[:80],"period":period,"horizon":horizon,
            "week":week,"week_end":week_end,"point":point,"board":params.get("board"),
            "event":str(params.get("event",""))[:60],"specific":params.get("specific") in (True,"1"),
            "choice_id":str(params.get("choice_id",""))[:80]}


def market_overview(db, at):
    day = at[:10]
    plans=db.execute("""SELECT b.id,b.name,b.issuer,p.date,p.kind,p.source
      FROM plans p JOIN bonds b ON b.id=p.bond WHERE p.date>? AND
      (CASE WHEN length(p.known)=10 THEN p.known||'T23:59:59' ELSE p.known END)<=?
      ORDER BY p.date,b.name,p.known DESC""",(day,at))
    seen=set();upcoming=[]
    for p in plans:
        if p["issuer"] not in seen:
            upcoming.append(dict(p));seen.add(p["issuer"])
        if len(upcoming)==8:break
    research=report()
    return {"upcoming": upcoming, "research": research if research and day >= research["built"] else None}


def read_api(db, path, params, model):
    if path == "/api/coverage":
        mode, name = model
        research = report()
        return {**coverage(db), "model": mode not in ("archive", "browser"), "provider": mode,
                "model_name": name, "outcome_bonds": research["universe"]["issues"] if research else 0}
    c = context(params)
    if path == "/api/search":
        return search(db, c["at"], params.get("q", "")[:160], params.get("issuer", "")[:150],
                      params.get("currency", ""), params.get("status", ""), params.get("event_filter", ""),
                      max(0, int(params.get("offset", 0))), 20)
    if path == "/api/bond":
        bond = snapshot(db, c["id"], c["at"], c["horizon"], c["period"], c["board"])
        return {**bond, "forecast": forecast(db, bond), "outcomes": payment_history(c["id"], c["at"])}
    if path == "/api/watch":
        return market_watch(db, c["at"])
    if path == "/api/market":
        return market_overview(db, c["at"])
    raise KeyError(path)
