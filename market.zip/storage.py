"""SQLite storage for the catalog, dated observations and source documents."""
import os
import sqlite3
from datetime import datetime, timezone, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = Path(os.environ.get("RADAR_DB", ROOT / "data" / "radar.sqlite3"))
MSK = timezone(timedelta(hours=3))


def now():
    return datetime.now(MSK).isoformat(timespec="seconds")[:19]


def connect():
    db = sqlite3.connect(DB, timeout=30)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    return db


def init(db):
    db.executescript("""
    CREATE TABLE IF NOT EXISTS issuers(id TEXT PRIMARY KEY,name TEXT NOT NULL,inn TEXT);
    CREATE TABLE IF NOT EXISTS bonds(id TEXT PRIMARY KEY,isin TEXT,secid TEXT,name TEXT,short TEXT,
      issuer TEXT REFERENCES issuers(id),primary_board TEXT,traded INTEGER,currency TEXT,nominal REAL,
      maturity TEXT,seen TEXT,registered TEXT,source TEXT);
    CREATE TABLE IF NOT EXISTS boards(bond TEXT,secid TEXT,board TEXT,firstday TEXT,lastday TEXT,
      PRIMARY KEY(bond,secid,board));
    CREATE INDEX IF NOT EXISTS boards_bond ON boards(bond,firstday);
    CREATE INDEX IF NOT EXISTS bonds_issuer ON bonds(issuer);
    CREATE TABLE IF NOT EXISTS quotes(bond TEXT,board TEXT,day TEXT,price REAL,volume REAL,trades INTEGER,
      yield_close REAL,currency TEXT,loaded TEXT, PRIMARY KEY(bond,board,day));
    CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY,issuer TEXT,bond TEXT,title TEXT,
      publisher TEXT,url TEXT,body TEXT,published TEXT,occurred TEXT,loaded TEXT,kind TEXT);
    CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,document TEXT REFERENCES documents(id),
      bond TEXT,issuer TEXT,kind TEXT,day TEXT,label TEXT,agency TEXT,old TEXT,new TEXT,outlook TEXT);
    CREATE TABLE IF NOT EXISTS plans(id TEXT PRIMARY KEY,bond TEXT,date TEXT,kind TEXT,amount REAL,
      per_unit REAL,currency TEXT,known TEXT,source TEXT,label TEXT,loaded TEXT);
    CREATE INDEX IF NOT EXISTS plan_by_bond ON plans(bond,date,known);
    CREATE TABLE IF NOT EXISTS executions(plan TEXT,document TEXT REFERENCES documents(id),
      status TEXT,planned REAL,overdue REAL,remaining REAL,day TEXT,PRIMARY KEY(plan,document,status));
    CREATE TABLE IF NOT EXISTS news(id TEXT PRIMARY KEY,scope TEXT,issuer TEXT,bond TEXT,
      published TEXT,title TEXT,publisher TEXT,url TEXT,document TEXT,loaded TEXT);
    CREATE TABLE IF NOT EXISTS refresh(source TEXT PRIMARY KEY,success TEXT,attempt TEXT,error TEXT,count INTEGER);
    CREATE TABLE IF NOT EXISTS moex_defaults(record_id INTEGER,observed TEXT,bond TEXT,inn TEXT,
      due TEXT,kind TEXT,status TEXT,executed TEXT,url TEXT,PRIMARY KEY(record_id,observed));
    CREATE INDEX IF NOT EXISTS defaults_issue ON moex_defaults(bond,observed);
    """)


def log(db, source, count=None, error=None):
    stamp = now()
    db.execute("""INSERT INTO refresh VALUES(?,?,?,?,?) ON CONFLICT(source) DO UPDATE SET
      success=coalesce(excluded.success,refresh.success),attempt=excluded.attempt,error=excluded.error,
      count=coalesce(excluded.count,refresh.count)""",
               (source, None if error else stamp, stamp, error, count))
