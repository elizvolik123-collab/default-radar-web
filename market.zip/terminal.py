"""Dated cross-sectional bond screener and transparent five-block expert index."""
import json
import sqlite3
from collections import Counter
from contextlib import closing
from datetime import date, timedelta
from functools import lru_cache
from urllib.parse import quote

from analytics import search, visible
from credit_data import DB, ISSUER_PROFILES, open_data, issuer_reports, issuer_filings
from risk_model import HISTORY
from storage import connect, ROOT, DB as CATALOG

WEIGHTS = json.loads((ROOT/"data/expert_weights.json").read_text("utf-8"))

LABELS = dict(zip(WEIGHTS,("Финансы","Платежи","Рынок","Рейтинги","Юридические события")))


def score(blocks,weights=WEIGHTS):
    total=sum(weights.values())
    known=sum(weights[k] for k in blocks)
    coverage=round(100*known/total) if total else 0
    sufficient=total and known/total>=0.5 and sum(weights[k]>0 for k in blocks)>=2
    value=round(sum(weights[k]*v["points"] for k,v in blocks.items())/known,1) if sufficient else None
    level="Нет оценки" if value is None else "Высокий" if value>=65 else "Повышенный" if value>=35 else "Низкий"
    if level=="Низкий" and not {"finance","payments","market"}.issubset(blocks):level="Частичная оценка"
    return value,coverage,level


def fact(points,text,stamp,url):
    return dict(points=points,reason=text,day=stamp[:10],url=url)


def cutoff_day(at):
    day=date.fromisoformat(at[:10])
    return str(day if at.endswith("23:59:59") else day-timedelta(days=1))


def universe(at):
    signature=tuple(p.stat().st_mtime_ns if p.is_file() else 0 for p in (CATALOG,DB,HISTORY))
    return _universe(at,signature)


@lru_cache(maxsize=2)
def _universe(at,signature):
    day=at[:10]; last=cutoff_day(at)
    start=str(date.fromisoformat(last)-timedelta(days=30))
    recent=str(date.fromisoformat(day)-timedelta(days=180))
    quotes={};finance={};payments={};ratings={};legal={};terms={};reg={};offers={};next_dates={};types={};banks=set();sectors={}
    def observe(key,r):
        if r["price"] is None or not r["trades"]:return
        pair=quotes.setdefault((key,r["board"]),[r,r])
        if r["day"]<pair[0]["day"]:pair[0]=r
        if r["day"]>=pair[1]["day"]:pair[1]=r
    with closing(connect()) as db:
        items=search(db,at,limit=100000)["items"]
        registry_check=db.execute("SELECT max(observed) FROM registry_checks WHERE observed<=?",(at,)).fetchone()[0]
        maturity=dict(db.execute("SELECT id,maturity FROM bonds WHERE seen<=?",(at,)))
        for r in db.execute("SELECT * FROM quotes WHERE day BETWEEN ? AND ? ORDER BY day",(start,last)):observe(r["bond"],r)
        for r in db.execute("""SELECT m.* FROM moex_defaults m JOIN bonds b ON b.id=m.bond
            WHERE (m.inn=b.issuer OR m.inn='') AND m.observed<=? AND m.due<=? AND m.observed=(
            SELECT max(v.observed) FROM moex_defaults v WHERE v.record_id=m.record_id AND v.observed<=?)
            ORDER BY due DESC""",(at,day,at)):reg.setdefault(r["bond"],[]).append(dict(r))
        for r in db.execute("SELECT bond,min(date) due FROM plans WHERE kind='Оферта' AND date>=? AND "+visible("known")+" GROUP BY bond",(day,at)):
            offers[r["bond"]]=r["due"]
        for r in db.execute("SELECT bond,min(date) due FROM plans WHERE date>=? AND kind IN ('Купон','Амортизация','Погашение') AND "+visible("known")+" GROUP BY bond",(day,at)):
            next_dates[r["bond"]]=r["due"]
        for r in db.execute("SELECT e.*,d.url,d.published FROM events e JOIN documents d ON e.document=d.id WHERE e.kind='Рейтинг' AND "+visible("d.published")+" ORDER BY d.published",(at,)):
            ratings[(r["issuer"],r["bond"])]=dict(r)
        for r in db.execute("""SELECT p.bond,p.date due,p.kind,x.day,x.status,x.remaining,d.url,d.published
                FROM executions x JOIN plans p ON p.id=x.plan JOIN documents d ON d.id=x.document
                WHERE x.day<=? AND """+visible("d.published")+" ORDER BY p.date,x.day,d.published",(day,at)):
            payments.setdefault(r["bond"],[]).append(dict(due=r["due"],kind=r["kind"],actual=r["day"] if r["remaining"]==0 else None,
                   late=r["status"]!="Исполнено в срок",url=r["url"]))
    if HISTORY.is_file():
        with closing(sqlite3.connect(HISTORY.as_uri()+"?mode=ro",uri=True)) as h:
            h.row_factory=sqlite3.Row
            for r in h.execute("""SELECT bond,due,kind,min(late) late,max(actual) actual,min(url) url FROM evidence
               WHERE due<=? AND published||'T23:59:59'<=? AND (actual IS NULL OR actual<=?)
               GROUP BY bond,due,kind HAVING min(late)=max(late) ORDER BY due""",(day,at,day)):
                payments.setdefault(r["bond"],[]).append(dict(r))
    with closing(open_data()) as db:
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='issuer_sector'").fetchone():
            sectors={r["inn"]:dict(r) for r in db.execute("SELECT * FROM issuer_sector WHERE day=(SELECT max(day) FROM issuer_sector WHERE day<=?)",(last,))}
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='issue_type'").fetchone():
            types=dict(db.execute("SELECT secid,code FROM issue_type WHERE seen<=? ORDER BY seen",(at,)))
        for r in db.execute("SELECT * FROM daily WHERE day BETWEEN ? AND ?",(start,last)):observe(r["secid"],r)
        for r in db.execute("SELECT * FROM terms WHERE seen<=? ORDER BY seen",(at,)):terms[r["bond"]]=dict(r)
        for (inn,) in db.execute("SELECT issuer FROM reports WHERE published<=? UNION SELECT issuer FROM filing_numbers WHERE substr(published,1,10)<=?",(day,day)):
            reports=issuer_reports(inn,at)
            if not reports:continue
            report=reports[0];period=report["period"]
            end=period[:4]+{"":"-12-31","Q1":"-03-31","Q2":"-06-30","Q3":"-09-30","Q4":"-12-31","H1":"-06-30","M9":"-09-30"}.get(period[4:],"-01-01")
            if (date.fromisoformat(day)-date.fromisoformat(end)).days>370:continue
            metrics=report["metrics"]
            if any(k in metrics for k in ("loan_portfolio","net_interest_income","total_capital_adequacy_ratio")):
                banks.add(inn)
                continue
            checks=[(k,fn) for k,fn in (("current_ratio",lambda v:v<1),("interest_cover",lambda v:v<1),("ocf",lambda v:v<0),("net_leverage",lambda v:v>=4)) if k in metrics]
            if len(checks)>=2:
                bad=sum(fn(metrics[k]["value"]) for k,fn in checks)
                details=", ".join(metrics[k]["name"]+" "+str(metrics[k]["value"]).replace(".",",")+" "+metrics[k]["unit"] for k,_ in checks)
                finance[inn]=fact(round(100*bad/len(checks)),f"За {period} пороги нарушены по {bad} из {len(checks)} показателей. {details}.",report["published"],report["original"] or report["url"])
        for (inn,) in db.execute("SELECT DISTINCT issuer FROM filings"):
            for r in issuer_filings(inn,at):
                if r["isin"] and r["published"][:10]>=recent and any(w in r["title"].lower() for w in ("требовании досрочного","реструктуризац","банкротств")):
                    legal.setdefault(r["isin"],fact(75,r["title"],r["published"],r["url"]))
    by_id={}
    for (key,board),pair in quotes.items():
        rank=(pair[1]["day"],board in ("TQCB","TQOB"),pair[1]["trades"])
        if key not in by_id or rank>by_id[key][0]:by_id[key]=(rank,pair)
    result=[]
    for b in items:
        key=b["id"];inn=b["issuer"];blocks={};entry=by_id.get(b["secid"]) or by_id.get(key)
        prices=entry[1] if entry else None
        q=prices[1] if prices else {}
        change=None;url=None
        if prices:
            url="https://iss.moex.com/iss/history/engines/stock/markets/bonds/boards/"+quote(q["board"])+"/securities/"+quote(b["secid"])+".json?from="+prices[0]["day"]+"&till="+q["day"]
            if prices[0]["price"] and (date.fromisoformat(q["day"])-date.fromisoformat(prices[0]["day"])).days>=7:
                change=round(100*(q["price"]/prices[0]["price"]-1),2)
                if (date.fromisoformat(day)-date.fromisoformat(q["day"])).days<=7:
                    blocks["market"]=fact(85 if change<=-10 else 50 if change<=-5 else 10,f"Изменение чистой цены за период {prices[0]['day']} — {q['day']} составило {change:g}%.",q["day"],url)
        records=reg.get(key,[]);history=sorted(payments.get(key,[]),key=lambda p:(p["due"],p["actual"] or ""))
        settled={(p["due"],p["kind"]):p for p in history if p["actual"]}
        unresolved=[r for r in records if not r["executed"] and (r["due"],r["kind"]) not in settled]
        event="Нет подтверждения";event_url=None
        if unresolved:
            r=next((d for d in unresolved if d["status"]=="Дефолт"),unresolved[0])
            event=r["status"];event_url=r["url"]
            blocks["payments"]=fact(100 if event=="Дефолт" else 85,"Биржевой реестр · "+event+", срок "+r["due"]+". Дата исполнения в записи отсутствует.",r["observed"],event_url)
            if not registry_check or (date.fromisoformat(day)-date.fromisoformat(registry_check[:10])).days>14:
                blocks.pop("payments",None)
        elif records or history:
            p=history[-1] if history else None;r=records[0] if records else None
            if r and (not p or r["due"]>=p["due"]):
                event="Исполнено после просрочки";event_url=r["url"];stamp=r["executed"] or settled[(r["due"],r["kind"])]["actual"];points=65
            else:
                event=("Исполнено после просрочки" if p["actual"] else "Подтверждённая просрочка") if p["late"] else "Исполнено в срок"
                event_url=p["url"];stamp=p["actual"] or p["due"];points=65 if p["late"] else 10
            if stamp>=recent:blocks["payments"]=fact(points,event,stamp,event_url)
        rating=ratings.get((inn,key)) or ratings.get((inn,None))
        if rating and rating["published"][:10]>=recent:
            adverse=rating["old"]!=rating["new"] and "снижен" in rating["label"].lower()
            blocks["rating"]=fact(85 if adverse else 55 if "наблюден" in rating["label"].lower() or "пересмотр" in (rating["outlook"] or "").lower() else 30,rating["label"],rating["published"],rating["url"])
        if inn in finance:blocks["finance"]=finance[inn]
        if key in legal:blocks["legal"]=legal[key]
        term=terms.get(key,{})
        profile=next((p for p in ISSUER_PROFILES if p["inn"]==inn and p["known"]<=at),{})
        code=types.get(b["secid"])
        sovereign=inn=="7710168360" or code=="ofz_bond"
        domestic=key.startswith("RU") and bool(b["inn"])
        kind="ОФЗ" if sovereign else {"ifi_bond":"Международная финансовая организация","cb_bond":"Облигация Банка России","non_exchange_bond":"Коммерческая облигация"}.get(code,"Не классифицирован")
        if inn in banks or profile.get("sector")=="Банки":kind="Банк"
        elif code in ("subfederal_bond","municipal_bond"):kind="Субфедеральная / муниципальная"
        elif not sovereign and domestic and (code in ("corporate_bond","exchange_bond") or not code and term.get("board")=="TQCB"):
            kind="Корпоративная"
        sector=profile.get("sector") or ("Банки" if inn in banks else sectors.get(inn,{}).get("sector"))
        eligible=kind=="Корпоративная" and sector!="Финансовый сектор"
        if not eligible:blocks.pop("finance",None)
        value,coverage,level=score(blocks)
        if not eligible:value,level=None,"Нет оценки"
        if value is not None and level=="Низкий" and event!="Исполнено в срок":level="Частичная оценка"
        known_dates=[d for d in (next_dates.get(key),term.get("due")) if d and d>=day]
        result.append(dict(id=key,name=b["name"],issuer=b["issuer_name"],inn=inn,kind=kind,isin=b["isin"],currency=b["currency"],
            status=b["status"],price=q["price"] if q else None,ytm=q["yield_close"] if q else None,volume=q["volume"] if q else None,
            day=q["day"] if q else None,change=change,board=q["board"] if q else None,quote_url=url,coupon=term.get("coupon"),
            eligible=eligible,ogrn=profile.get("ogrn"),sector=sector,sector_url=profile.get("url") if profile.get("sector") else sectors.get(inn,{}).get("url"),identity_url=profile.get("url"),next_due=min(known_dates,default=None),maturity=maturity.get(key),offer=offers.get(key),rating=rating["new"] if rating else None,event=event,event_url=event_url,
            score=value,coverage=coverage,level=level,blocks=blocks))
    return result


def screen(at,p):
    rows=universe(at)
    if p.get("one"):
        return next((r for r in rows if r["id"]==p["one"]),{})
    query=str(p.get("query","")).casefold().strip()
    ids=set(str(p.get("ids","")).split(",")) if p.get("ids") else None
    def match(r):
        if ids is not None and r["id"] not in ids:return False
        if query and query not in " ".join(str(r[k] or "") for k in ("name","issuer","inn","id","ogrn")).casefold():return False
        if any(p.get(k) and p[k]!=r[k] for k in ("level","kind","status","rating","event","sector")):return False
        if p.get("till") and (not r["maturity"] or r["maturity"]>p["till"]):return False
        for key,sign in (("ymin",1),("ymax",-1)):
            if str(p.get(key,"")).strip() and (r["ytm"] is None or sign*r["ytm"]<sign*float(p[key])):return False
        return True
    selected=[r for r in rows if match(r)]
    sort=p.get("sort","volume")
    if sort not in ("score","volume","ytm","maturity","price","name","change"):sort="volume"
    known=sorted((r for r in selected if r[sort] is not None),key=lambda r:r[sort],reverse=p.get("dir")!="asc")
    ordered=known+[r for r in selected if r[sort] is None]
    offset=max(0,int(p.get("offset",0)))
    sectors=Counter((r["sector"] or "Отрасль не установлена",r["level"]) for r in selected)
    return {"heatmap":[[sector,level,count] for (sector,level),count in sorted(sectors.items())],"count":len(ordered),"items":ordered[offset:offset+(len(ordered) if p.get("export")=="1" else 25)],
            "distribution":dict(Counter(r["level"] for r in selected)),
            "matrix":[[r["score"],r["ytm"],r["id"],r["name"]] for r in selected if r["score"] is not None and r["ytm"] is not None],
            "kinds":sorted({r["kind"] for r in rows}),"sectors":sorted({r["sector"] for r in rows if r["sector"]}),"ratings":sorted({r["rating"] for r in rows if r["rating"]}),"events":sorted({r["event"] for r in rows}),
            "weights":WEIGHTS,"labels":LABELS}
