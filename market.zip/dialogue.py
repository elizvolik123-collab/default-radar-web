"""Ground a natural-language question in issue-level evidence available at the cutoff."""
import json
import re
from urllib.parse import quote
from analytics import MISSING, norm, peer_move, registry, search, snapshot
from archive import RULES
from risk_model import forecast, payment_history
from credit_data import DB, open_data, issuer_reports, issuer_filings, bond_terms, market
from bond_radar import assess
from topic_model import infer
from contextlib import closing

TOPICS=("паспорт","цена","календарь","исполнение","риск","термин","финансы","купон")
IDS=re.compile(r"(?<![A-Z0-9])[A-Z]{2}[A-Z0-9]{9}[0-9](?![A-Z0-9])",re.I|re.ASCII)
OFZ=re.compile(r"\b(?:офз[\s-]*(?:пд|пк|ин|ад)?[\s-]*)?(2[469]\d{3}|5[23]\d{3})\b",re.I)
ALIASES={"сбер":"Сбербанк","газпром":"Газпром","ржд":"РЖД","самолет":"Самолет","соби":"СОБИ-ЛИЗИНГ",
         "евротранс":"ЕвроТранс","мсблизинг":"МСБ-Лизинг","втб":"ВТБ","роснефт":"Роснефть","мтс":"МТС"}


def day(value):
    return ".".join(value[:10].split("-")[::-1])


def num(value):
    return f"{value:,.3f}".rstrip("0").rstrip(".").replace(","," ").replace(".",",")


def currency(code):
    return "₽" if code in ("RUB","RUR","SUR") else code or ""


def refs(label,url):
    return [{"label":label,"url":url}] if url else []


def typed_plan(question,previous,selected):
    from model_runtime import generate
    schema={"type":"object","properties":{
        "queries":{"type":"array","items":{"type":"string"},"maxItems":2},
        "topics":{"type":"array","items":{"type":"string","enum":list(TOPICS)},"minItems":1,"maxItems":3}},
        "required":["queries","topics"],"additionalProperties":False}
    history=[p["content"][:300] for p in previous[-4:] if p["role"]=="user"]
    prompt=json.dumps({"предыдущие вопросы":history,"открытый выпуск":selected,"вопрос":question},ensure_ascii=False)
    plan=generate("Разбери вопрос инвестора. queries — только дословно названные в последнем вопросе компании, серии или ISIN. Если вопрос о выбранной бумаге, верни []. topics — нужные инструменты. Дата и размер предстоящего купона — календарь; прошлый платёж, просрочка и дефолт — исполнение; торги и доходность — цена. На вопрос пока не отвечай.",prompt,schema,135)
    queries=[q.strip() for q in (plan.get("queries") or []) if isinstance(q,str) and q.strip()]
    topics=list(dict.fromkeys(t for t in (plan.get("topics") or []) if t in TOPICS))
    return queries, topics or ["паспорт"]


def targets(question,proposed):
    lower=question.lower().replace("ё","е")
    exact=[(m.start(),m[0].upper()) for m in IDS.finditer(question)]
    for match in OFZ.finditer(lower):
        if not any(start<=match.start()<start+12 for start,_ in exact):
            exact.append((match.start(),"ОФЗ "+match[1]))
    literal=[v for _,v in sorted(exact)]
    fragments={norm(w) for w in re.findall(r"[\w-]+",lower) if len(w)>=3}
    for term in proposed:
        if re.fullmatch(r"\d{10,12}",term) and not exact:
            verified=term in question
            if not verified and DB.is_file():
                words={w.upper() for w in re.findall(r"[A-Za-z][A-Za-z0-9]+",question)}
                with closing(open_data()) as db:
                    verified=any(r[0].upper() in words for r in db.execute("SELECT DISTINCT ticker FROM reports WHERE issuer=?",(term,)))
            if verified:literal.append(term)
            continue
        if not (norm(term) in norm(question) or any(len(w)>3 and norm(term).startswith(w[:max(3,len(w)-2)]) for w in fragments)):
            continue
        if exact and (any(norm(term) in norm(k) or norm(k) in norm(term) for k in literal) or len(exact)>=2):
            continue
        literal.append(term)
    if not literal:
        literal.extend(v for k,v in ALIASES.items() if k in lower.replace("-",""))
    if len(literal)>1 and exact:
        # "Сбербанк RU..." identifies one issue, unless an explicit comparison is requested.
        if not re.search(r"сравн|обе|обоих|между| и |против",lower):
            literal=[v for _,v in sorted(exact)]
    return list(dict.fromkeys(literal))[:2]


def resolve(db,term,cutoff):
    found=search(db,cutoff,query=term,limit=40)
    items=found["items"]
    exact=[r for r in items if norm(term) in [norm(r[k]) for k in ("id","isin","secid","name","short")]]
    if exact:
        return exact,len(exact),exact[0]["issuer"] if len({v["issuer"] for v in exact})==1 else None
    return items,found["total"],items[0]["issuer"] if items and found["issuer_summary"] else None


def statement_fact(inn,name,at,question):
    reports=issuer_reports(inn,at)
    if not reports:
        filings=issuer_filings(inn,at)
        filing=next((r for r in filings if re.search("отч[её]т",r["title"],re.I)),None)
        if not filing:return None
        return (f"{name}. {filing['title']} за {filing['period']}, опубликовано {day(filing['published'])}. Числовые показатели из этого документа пока не извлечены.",
                refs("Интерфакс · отчёт эмитента",filing["url"]))
    else:
        r=reports[0]
        proof=refs(r["provider"]+" · финансовые показатели",r["url"])
        if r["original"]!=r["url"]:proof+=refs("Финансовый отчёт эмитента",r["original"])
        metrics=r["metrics"]
        patterns={"interest_cover":"процент|покрыти","net_leverage":"долг|долгов|ebitda","debt_ebitda":"долг|ebitda","debt":"долг",
                  "fcf":"свободн|fcf","ocf":"поток|денежн","revenue":"выруч","net_income":"прибыл|убыт",
                  "equity":"капитал","capital":"капитал","share_of_non_performing_loans":"проблемн|npl",
                  "total_capital_adequacy_ratio":"достаточн","current_ratio":"ликвид","cash":"ликвид|денег"}
        selected=[k for k,v in patterns.items() if k in metrics and re.search(v,question,re.I)]
        if not selected:selected=[k for k in ("net_leverage","interest_cover","current_ratio","ocf","fcf","net_income","total_capital_adequacy_ratio","revenue","cash") if k in metrics]
        details=". ".join(f"{metrics[k]['name']} — {num(metrics[k]['value'])} {metrics[k]['unit']}".rstrip(".") for k in selected[:5])
        warnings=" ".join(s["text"] for s in r["flags"][:3])
        head=f"{name}. {r['standard']}, период {r['period']}, опубликовано {day(r['published'])}."
        return " ".join(filter(None,(head,details+"." if details else "",warnings))),proof



def facts(db,s,topics,question,context):
    b=s["bond"]; key=b["id"]; at=s["asof"]; official=b["source"] or "https://www.moex.com/ru/bonds/"+quote(key)
    name=b["name"] or b["short"] or key
    result=[]
    def add(section,statement,proofs):
        result.append({"section":section,"text":statement,"refs":proofs,"bond":key})
    card=refs("Московская биржа · "+key,official)
    if "документ" in topics:
        for filing in issuer_filings(b["issuer"],at,key)[:4]:
            add("events",f'{day(filing["published"])} · {filing["title"]} {filing["period"]}.',refs("Интерфакс · ЦРКИ",filing["url"]))
    if "риск" in topics:
        radar=assess(db,s)["radar"]
        evidence=radar["factors"][:3]
        reason=" ".join(f['scope']+". "+f['reason'] for f in evidence) or " ".join(radar["gaps"][:2])
        radar_refs=[ref for f in evidence for ref in refs(f["scope"]+" · "+day(f["day"]),f["url"])]
        add("bondRadar",f'{name}. {radar["label"]} на {day(at)}. {reason}',radar_refs or card)
        result[-1]["required"]=True
    if "финансы" in topics:
        item=statement_fact(b["issuer"],b["issuer_name"],at,question)
        text,proof=item or (f"{name}. На эту дату отсутствует сопоставленный по ИНН финансовый отчёт.",card)
        add("fundamentals",text,proof)
        result[-1]["required"]=True
    if "купон" in topics:
        t=bond_terms(key,at)
        if t:
            def display(k,unit):
                return str(num(t[k]))+" "+unit if t[k] is not None else "нет сведений"
            text=f"{name}. НКД на одну бумагу — {display('accrued',currency(t.get('settlement_currency')))}"
            if t['settle']:text+=" на дату расчётов "+day(t["settle"])
            text+=f". Купон на бумагу — {display('coupon',currency(t['currency']))}. Ставка купона — {display('rate','% годовых')}."
            if t['due']:text+=" Плановая дата — "+day(t["due"])+"."
            add("coupons",text,refs("Московская биржа · параметры выпуска",t["source"]))
        else:
            add("coupons",f"{name}. На эту дату в опубликованных данных нет снимка НКД.",card)
        result[-1]["required"]=True
    if "паспорт" in topics:
        terms=f" Эмитент — {b['issuer_name']}"+(f", ИНН {b['inn']}." if b["inn"] else ".")
        if b["maturity"]:
            terms+=f" Дата погашения по справочнику — {day(b['maturity'])}."
        if b["nominal"] is not None:
            terms+=f" Номинал на срез — {num(b['nominal'])} {currency(b['currency'])}."
        add("detail",f"{name}, ISIN {b['isin'] or 'не указан'}, SECID {b['secid']}."+terms,card)
    if "цена" in topics:
        point=context.get("point") or at[:10]
        observed=[r for r in s["quotes"] if r["day"]<=point]
        last=observed[-1] if observed else s["last"]
        if last and last["day"]<=point:
            dt=last["day"];board=last["board"]
            url=f"https://iss.moex.com/iss/history/engines/stock/markets/bonds/boards/{quote(board)}/securities/{quote(b['secid'])}.json?from={dt}&till={dt}"
            proof=refs(f"MOEX ISS · {board} · {day(dt)}",url)
            text=f"{name}: последняя сохранённая цена закрытия на {day(dt)} — {num(last['price'])}% номинала. Режим {board}."
            if last["trades"] is not None:
                text+=f" Сделок — {num(last['trades'])}."
            if last["yield_close"] is not None and "доходност" in question.lower():
                text+=f" Доходность на закрытии по методике биржи (YIELDCLOSE) — {num(last['yield_close'])}% годовых."
            add("price",text,proof)
            if len(observed)>1 and re.search("измен|упа|сниз|вырос|движ|рынок",question,re.I):
                prev=observed[-2];delta=last["price"]-prev["price"]
                text=f"С {day(prev['day'])} по {day(dt)} изменение цены выпуска составило {num(delta)} п. п."
                peers=peer_move(db,key,board,dt)
                if peers:
                    text+=f" Медиана для {peers['sample']} других бумаг режима {board} за те же сессии — {num(peers['median_pp'])} п. п."
                add("price",text+" Причинная связь с конкретной новостью не установлена.",refs("MOEX ISS · история торгов",url.replace("from="+dt,"from="+prev["day"])))
        else:
            add("price",f"В сохранённой истории {name} до {day(point)} цены сделки нет.",card)
    if "календарь" in topics:
        upcoming=s["next"]
        if re.search(r"купон",question,re.I):
            from analytics import dated_plans
            upcoming=next((p for p in dated_plans(db,b["issuer"],at) if p["bond"]==key and p["kind"]=="Купон"),None)
        if upcoming:
            p=upcoming
            text=f"{name}: {p['label']}, плановая дата — {day(p['date'])}."
            if p["per_unit"] is not None:
                text+=f" На одну облигацию — {num(p['per_unit'])} {currency(p['currency'])}."
            if p["amount"] is not None:
                text+=f" План по выпуску — {num(p['amount'])} {currency(p['currency'])}."
            add("calendar",text,refs("График · "+key,p["source"]))
            if context.get("week") or re.search(r"раньше|до моего|до купона|до выплаты|обязательства",question,re.I):
                seen=[v for v in s["plans"] if v["date"]<p["date"] and
                      (not context.get("week") or context["week"]<=v["date"]<context["week_end"])]
                for v in seen[:5]:
                    add("calendar",f"До этого платежа наступает {v['label']} по {v['name']} ({v['bond']}) — {day(v['date'])}"+
                        (f", {num(v['amount'])} {currency(v['currency'])}." if v["amount"] is not None else ". Сумма не раскрыта."),refs("График · "+v["bond"],v["source"]))
                    result[-1]["required"]=True
                if not seen:
                    add("calendar","В выбранном интервале среди загруженных графиков более ранних обязательств эмитента не найдено.",refs("График · "+key,p["source"]))
        else:
            add("calendar",f"На срез {day(at)} для {name} в сохранённых данных нет опубликованного графика следующего запрошенного платежа.",card)
    if "исполнение" in topics or "риск" in topics:
        p=s["payment"]
        verified=payment_history(key,at) if "исполнение" in topics else []
        for v in [r for r in verified if r["source"]!="MOEX"][:3]:
            text=f"{name}. {v['kind']}, договорный срок {day(v['due'])}. "+("Зафиксирована просрочка." if v["late"] else "Выплата подтверждена в срок.")
            if v["actual"]:text+=f" Фактическая дата — {day(v['actual'])}."
            proof=refs(v["source"],v["url"])
            if v["terms_url"]!=v["url"]:proof+=refs("Срок по графику",v["terms_url"])
            add("payment",text,proof)
        if "исполнение" in topics and p:
            text=f"{name}: {p['label']}, плановая дата {day(p['date'])}. {p['status']}."
            proofs=[{"label":h["publisher"]+" · "+day(h["published"]),"url":h["url"]} for h in s["history"] if h["plan"]==p["plan"]]
            if p["planned"] is not None and p["ontime"] is not None:
                text+=f" В срок перечислено {num(p['planned'])} − {num(p['overdue'])} = {num(p['ontime'])} {currency(p['currency'])}."
            if p["percent"]:
                text+=f" На плановую дату просрочено {num(p['percent'])}% суммы этого платежа."
            if p["remaining"] is not None:
                text+=f" Остаток на {day(p['day'])} — {num(p['remaining'])} {currency(p['currency'])}."
            add("payment",text,proofs)
        before=bool(re.search(r"заранее|до выплат|до платеж|накануне",question,re.I))
        event_cutoff=min(at,p["date"]+"T00:00:00") if before and p else at
        entries=registry(db,key,event_cutoff)
        for r in entries[:3]:
            text=f"{name} ({key}): {r['kind']}, плановая дата {day(r['due'])}. В реестре биржи указан статус «{r['status']}»."
            if r["executed"]:
                text+=f" Указанная биржей фактическая дата исполнения — {day(r['executed'])}."
            else:
                text+=" Фактическая дата исполнения в этой записи не указана."
            add("events",text,refs("Московская биржа · карточка обязательства",r["url"]))
            if r is entries[0] and re.search(r"дефолт|нарушен|пропуст|просроч|неисполн",question,re.I):result[-1]["required"]=True
        if not p and not entries and not verified and "исполнение" in topics:
            add("payment",f"{name} ({key}). {MISSING}. График купонов сам по себе не подтверждает перевод денег.",card)
        events={e["document"]:e for e in s["events"] if e["published"]<event_cutoff}
        if "риск" in topics:
            if re.search(r"прогноз|риск|вероятност|шанс",question,re.I):
                f=forecast(db,s)
                if f["state"]=="signal":
                    text=("Порог предупреждения достигнут" if f["alert"] else "Порог предупреждения не достигнут")+f". {name}, {f['kind'].lower()} со сроком {day(f['due'])}. Дата оценки — {day(f['anchor'])}. Цена перед прогнозом {num(f['close'])}% номинала. Модель пока не даёт калиброванную вероятность."
                    add("forecast",text,refs("Московская биржа · входные данные модели",f["url"])+refs("План платежа",f["terms"]))
                else:add("forecast","Прогноз для "+name+". "+f["reason"],refs("Условия выпуска",f.get("terms",official)))
                result[-1]["required"]=True
            for e in list(events.values())[:4]:
                add("events",f"{day(e['published'])} · {e['body']}",refs(e["publisher"]+" · "+day(e["published"]),e["url"]))
            if not events and not entries and not radar["factors"]:
                add("events",f"Для оценки риска {name} на {day(at)} не хватает датированных сведений о ликвидности и платёжной дисциплине. Вероятность дефолта не рассчитана.",card)
            elif re.search(r"вероятност|шанс|в процент|процент.{0,11}риск",question,re.I):
                add("events",f"Для {name} вероятность следующей просрочки в процентах не рассчитана. Доступна качественная оценка по факторам риска.",radar_refs or card)
                result[-1]["required"]=True
    if "термин" in topics:
        q=question.lower()
        guide=refs("Московская биржа · устройство облигаций","https://www.moex.com/ru/bonds")
        if "купон" in q:
            add("calendar","Купон — проценты по долгу эмитента перед владельцем облигации. Дату и размер выплаты определяют условия конкретного выпуска.",guide)
        if "оферт" in q:
            add("calendar","Оферта позволяет предъявить облигацию к выкупу на условиях выпуска. Объём фактического выкупа зависит от предъявленных бумаг.",guide)
        if "номинал" in q or "погашен" in q:
            add("calendar","При погашении эмитент возвращает оставшуюся часть номинала. Рыночная цена покупки может отличаться от этой суммы.",guide)
        if "дефолт" in question.lower():
            add("events","По правилам Московской биржи задержка может быть техническим дефолтом. Критерий дефолта — отказ от исполнения или просрочка свыше 10 рабочих дней, если условия выпуска не установили меньший срок.",refs("Московская биржа · правила",RULES))
        if "амортиз" in question.lower():
            add("calendar","Амортизация означает возврат части номинала до окончательного погашения облигации. Купон — отдельная выплата.",refs("Московская биржа · амортизация","https://bondguide.moex.com/terms/9"))
        if "доходност" in question.lower():
            add("price","Доходность к погашению учитывает цену покупки и будущие платежи. При расчёте доходности к оферте срок денежных потоков ограничивают датой предполагаемого выкупа.",refs("Московская биржа · доходность","https://bondguide.moex.com/articles/placement-process/8"))
    if context.get("event"):
        selected=next((d for d in s["documents"] if d["id"]==context["event"]),None)
        if selected:
            add("events",selected["body"],refs(selected["publisher"]+" · "+day(selected["published"]),selected["url"]))
    if not result:
        words={w[:5] for w in re.findall(r"[а-яёa-z]{4,}",question.lower())} - {"какой","какие","этого","выпус","облиг","эмите","расск","можно"}
        ranked=[]
        for doc in s["documents"]:
            terms={w[:5] for w in re.findall(r"[а-яёa-z]{4,}",(doc["title"]+" "+doc["body"]).lower())}
            rank=len(terms & words)
            if rank:ranked.append((rank,doc))
        for _,doc in sorted(ranked,key=lambda v:(v[0],v[1]["published"]),reverse=True)[:2]:
            add("events",doc["title"]+". "+doc["body"],refs(doc["publisher"],doc["url"]))
    return result


def augment_topics(topics,q):
    # Preserve explicit requests even when a compact model omits one of them.
    patterns=(("цена",r"котиров|торгов|торговал|цен[ауые]|доходност|закрыти|стоил"),
              ("календарь",r"следующ.{0,18}купон|ближайш|предсто|до моего|до купона|будет купон|когда.{0,12}купон"),
              ("исполнение",r"просроч|дефолт|в срок|заплатил|выплатил|опоздан|перечислил|погасили|долг закры|пропустил.{0,18}(плат[её]ж|купон|выплат)|неисполн"),
              ("риск",r"рейтин|сигнал|ухудш|риск|вероятност|шанс|прогноз|светофор|цвет.{0,16}(радар|бумаг|выпуск)|красн.{0,10}(статус|индикатор)|над[её]жн|плат[её]жеспособ|слабые места"),("термин",r"чем.{0,22}дефолт.{0,28}отлич|чем отлич.{0,24}дефолт"),
              ("паспорт",r"эмитентом|кто выпустил|номинал|когда погаш|дата погаш"))
    explicit=[k for k,pattern in patterns if re.search(pattern,q,re.I)]
    if re.search(r"нкд|накопленн.{0,10}купон|ставк.{0,10}купон|купонн.{0,10}ставк|размер.{0,10}купон",q,re.I):explicit.insert(0,"купон")
    if re.search(r"фундамент|баланс|оборотн.{0,10}актив|отч[её]тност|ликвидност|покрыти.{0,14}процент|долгов.{0,12}нагруз|финансов.{0,14}(состоян|устойчив)|выручк|прибыл|убыт|капитал|ebitda|fcf|денежн.{0,9}поток",q,re.I):explicit.insert(0,"финансы")
    if not explicit and re.search(r"событи|предпосыл|критическ|признак.{0,10}ухудш",q,re.I):explicit.append("риск")
    if re.search(r"что такое|что значит|объясни.{0,15}термин|в чем разница|в чём разница|чем отлич",q,re.I):
        explicit.insert(0,"термин")
    return list(dict.fromkeys(explicit or infer(q) or topics))[:4]


def archive_plan(db, question, previous):
    topics=augment_topics([],question)
    if not topics and re.search(r"а (раньше|сейчас|потом)|а за |динамик|изменил",question,re.I):
        for message in reversed(previous):
            if message["role"]=="user":
                topics=augment_topics([],message["content"])
                if topics:break
    queries=re.findall(r"[«\"]([^»\"]{2,65})[»\"]",question)
    if not queries and not targets(question,[]) and DB.is_file():
        with closing(open_data()) as store:
            codes={r[0].upper():r[1] for r in store.execute("SELECT DISTINCT ticker,issuer FROM reports WHERE ticker<>''")}
        for word in re.findall(r"\b[A-Z][A-Z0-9]{1,9}\b",question,re.I|re.ASCII):
            if word.upper() in codes:queries.append(codes[word.upper()])
        if not queries:
            skip={"акционерное","общество","компания","группа","группы","финанс","банк","публичное","российской","федерации"}
            words={v.lower() for v in re.findall(r"[А-Яа-яЁё-]{4,}",question)}
            for row in db.execute("SELECT name FROM issuers"):
                for token in re.findall(r"[А-Яа-яЁё-]{4,}",row[0].lower()):
                    if token not in skip and any(w==token or len(token)>5 and w.startswith(token[:-1]) and abs(len(w)-len(token))<=1 for w in words):
                        if token not in queries: queries.append(token)
        queries=sorted(queries,key=len,reverse=True)[:2]
    return queries, topics


def select_claims(question,previous,available):
    """Generate a short answer plus the IDs of the records that support it."""
    from model_runtime import generate
    ref_id={"type":"integer","minimum":1,"maximum":len(available)}
    schema={"type":"object","properties":{"passages":{"type":"array","items":ref_id,
        "minItems":1,"maxItems":min(5,len(available))},"basis":ref_id,"answer":{"type":"string"}},
        "required":["passages","basis","answer"],"additionalProperties":False}
    info=[f"{i}. {v['text']}" for i,v in enumerate(available,1)]
    prompt=json.dumps({"последний вопрос":question,"предыдущие вопросы":[p["content"][:250] for p in previous[-2:] if p["role"]=="user"],"сведения":info},ensure_ascii=False)
    output=generate("Ты отвечаешь инвестору по-русски. passages: номера подходящих сведений. basis: номер главного источника. answer: одно короткое предложение, которое отвечает на вопрос простыми словами и полностью следует из basis. Не используй внешние знания, прогнозы и рекомендации. Если данных недостаточно, назови пробел. Не меняй единицы, направление и статус. Дословные цифры и ссылки приложит программа.",prompt,schema,220)
    selected=[i-1 for i in dict.fromkeys(output.get("passages",[])) if type(i) is int and 1<=i<=len(available)]
    basis=output.get("basis")
    lead=str(output.get("answer","")).strip()
    if type(basis) is int and 1<=basis<=len(available) and grounded_lead(lead,available[basis-1]["text"]):
        return selected, {**available[basis-1],"text":lead}
    return selected,None


def grounded_lead(lead, evidence):
    # Numbers, statuses and named entities are rendered verbatim below. Only admit a
    # conservative, short paraphrase of a single record, never a freestanding forecast.
    if not 15<=len(lead)<=220 or re.search(r"\d|https?://|вероятн|гарант|совету|рекоменд|надежн|надёжн|покупать|продавать",lead,re.I):
        return False
    if any(w in lead.lower() for w in ("выплач","погашен","исполнен","перечисл","просроч","дефолт","в срок","риск","выше","ниже","сниж","вырос")):
        return False
    if (" не " in " "+lead.lower()+" ")!=(" не " in " "+evidence.lower()+" "):
        return False
    words=lambda s:{w[:5] for w in re.findall(r"[а-яёa-z]{4,}",s.lower())}
    words_used=words(lead)
    return bool(words_used) and words_used<=words(evidence)|{"облиг","выпус","бумаг","согла","данны","источ","сведе"}


def compose(question,previous,items,topics,*,saved_only=False):
    if saved_only:
        selected,lead=list(range(min(3,len(items)))),None
    else:
        selected,lead=select_claims(question,previous,items)
    selected=list(dict.fromkeys([i for i,item in enumerate(items) if item.get("required")]+selected))
    # Do not lose an explicitly requested issue or an important payment/estimate distinction.
    for bond in dict.fromkeys(i["bond"] for i in items):
        if not any(items[i]["bond"]==bond for i in selected):
            selected.append(next(i for i,v in enumerate(items) if v["bond"]==bond))
    for section,topic in (("price","цена"),("calendar","календарь"),("payment","исполнение"),("events","риск")):
        if topic in topics and not any(items[i]["section"]==section for i in selected):
            index=next((i for i,v in enumerate(items) if v["section"]==section),None)
            if index is not None:
                selected.append(index)
    result=[items[i] for i in selected[:8]]
    return ([lead]+result if lead and lead["text"] not in {v["text"] for v in result} else result)


def live_answer(db,context,question,previous,*,saved_plan=None,mode_label=None):
    at=context["at"]
    current=snapshot(db,context["id"],at,context["horizon"],context["period"],context.get("board")) if context["id"] else None
    b=current["bond"] if current else {"id":"","name":"","short":"","issuer":None}
    if saved_plan is None:
        from model_runtime import provider
        mode,name=provider()
        mode_label=("Локальная модель · " if mode=="local" else "Языковая модель · ")+name
    base={"id":b["id"],"asof":at,"mode":mode_label,
          "section":"detail","choices":[],"refs":[],"related":[]}
    if not current and re.search(r"(?:какие|какими|каких).{0,18}документ",question,re.I) and re.search("распозна|подтвер|установ|определ|свидетельств",question,re.I) and not targets(question,[]):
        return {**base,"text":"Для проверки дефолта нужны условия именно этого выпуска, договорная дата и сумма обязательства, сообщение эмитента или представителя владельцев о неисполнении и последующее подтверждение исполнения. Статус можно сверить с реестром Московской биржи [1]. Если сроки менялись, проверьте зарегистрированные изменения и решение собрания владельцев. Отчётность, аудиторское заключение и сообщения о ковенантах помогают оценить будущий риск [2].",
                "refs":refs("Мосбиржа · неисполнение обязательств","https://www.moex.com/s28")+refs("Мосбиржа · раскрытие и права владельцев","https://bondguide.moex.com/articles/life-bonds-after-placement/20")}
    if re.search(r"\bКБД\b|бескупонн|преми.{0,20}(офз|корпоратив)|дюраци.{0,16}индекс",question,re.I):
        m=market(at);curve=m["curve"];lines=[];proof=[]
        if curve:
            lines.append("КБД ОФЗ на "+day(curve["day"])+": "+", ".join(f"{num(t)} г. — {num(y)}%" for t,y in curve["points"])+" [1].")
            proof+=refs("Банк России · кривая по срокам",curve["url"])
        for row in m["corporate"]:
            proof+=refs("MOEX ISS · "+row["code"],row["url"])
            text=f'{row["code"]} на {day(row["day"])}. Доходность {num(row["yield_pct"])}%, дюрация {row["duration_days"]} дн. [{len(proof)}].'
            if row['premium_bp'] is not None:
                if row["curve_url"] not in [p["url"] for p in proof]:proof+=refs("Банк России · сопоставимый срок",row["curve_url"])
                text+=f' Расчётная премия к КБД на срок дюрации {row["premium_bp"]} б. п. [{next(i for i,p in enumerate(proof,1) if p["url"]==row["curve_url"])}].'
            lines.append(text)
        return {**base,"text":"\n".join(lines) or "На эту дату нет опубликованных наблюдений.","refs":proof}
    macro_codes={"RGBI":r"\bRGBI\b","RUCBCPNS":r"RUCBCPNS","RUCBTRAAANS":r"RUCBTRAAANS","RUCBTRNS":r"RUCBTRNS|индекс.{0,18}корпоративн",
                 "IMOEX":r"IMOEX|индекс.{0,10}мосбирж","KEY":r"ключев.{0,9}ставк|ставк.{0,9}(цб|банка россии)"}
    requested=[k for k,p in macro_codes.items() if re.search(p,question,re.I)]
    if requested or re.search(r"индекс[ыов]{1,2} (рынка|облигац)|макроэконом",question,re.I):
        series=[s for s in market(at)["series"] if not requested or s["code"] in requested]
        lines=[f"{s['label']} ({s['code']}) на {day(s['day'])} — {num(s['value'])} {s['unit']} [{i}]." for i,s in enumerate(series,1)]
        if re.search("почему|повлия|причин|влия",question,re.I):lines.append("По этим наблюдениям нельзя установить причинную связь с изменением цены выпуска.")
        return {**base,"text":"\n".join(lines) or "На эту дату нет сохранённых наблюдений.","refs":[{"label":s["label"],"url":s["url"]} for s in series]}
    queries,topics=saved_plan if saved_plan is not None else typed_plan(question,previous,b["name"])
    topics=augment_topics(topics,question)
    requests=targets(question,queries)
    if current and question.lower().startswith("объясни документ") and any(d["id"]==context.get("event") for d in current["documents"]):
        requests=[];topics=["документ"]
    if b["id"] and context.get("choice_id")==b["id"] and len(requests)<=1:
        requests=[b["id"]]
    if topics==["финансы"] and len(requests)==1:
        term=requests[0]
        # Match the legal issuer itself. Finance subsidiaries have distinct INNs.
        def short_title(value):
            clean=re.sub(r'(?i)(публичное|открытое|закрытое)?\s*акционерное общество|общество с ограниченной ответственностью|^ПАО |^АО |^ООО ', '',value)
            return norm(clean)
        exact=[r for r in db.execute("SELECT id,name FROM issuers") if term==r["id"] or short_title(r["name"])==norm(term)]
        if not exact:
            symbols={"сбербанк":"SBER","ржд":"RZHD","мтс":"MTSS","самолет":"SMLT","роснефть":"ROSN","втб":"VTBR"}
            ticker=symbols.get(term.lower().replace("ё","е"),term.upper())
            if DB.is_file():
                with closing(open_data()) as store:
                    inns=store.execute("SELECT DISTINCT issuer FROM reports WHERE ticker=?",(ticker,)).fetchall()
                if len(inns)==1:exact=db.execute("SELECT id,name FROM issuers WHERE id=?",(inns[0][0],)).fetchall()
        if len(exact)==1:
            issuer=exact[0]; record=statement_fact(issuer["id"],issuer["name"],at,question)
            if record:
                statement,proof=record
                return {**base,"text":statement+" "+" ".join(f"[{i}]" for i in range(1,len(proof)+1)), "refs":proof}
            return {**base,"text":"По этому ИНН на выбранную дату отсутствует сопоставленная финансовая отчётность."}
    selected=[]
    issuer_facts=[]
    for term in requests:
        items,total,one_issuer=resolve(db,term,at)
        if not total:
            return {**base,"text":f"В каталоге на {day(at)} не удалось найти «{term}». Уточните ISIN, SECID или серию."}
        if current and total>1 and context.get("choice_id")==b["id"] and (one_issuer==b["issuer"] or any(r["id"]==b["id"] for r in items)):
            selected.append(b["id"])
            continue
        if total>1 and one_issuer and len(requests)==1 and re.search(r"по каким|были.{0,12}дефолт|у .{2,28}дефолт|просрочк.{0,12}эмитент",question,re.I):
            records=registry(db,None,at,issuer=one_issuer)
            issues={}
            for r in records:
                issues.setdefault(r["bond"],r)
            for r in list(issues.values())[:5]:
                issuer_facts.append({"bond":r["bond"],"section":"events","text":f"{r['name']} ({r['bond']}), {r['kind']}, срок {day(r['due'])}. Статус биржи — {r['status']}.",
                                    "refs":refs("Московская биржа · запись "+str(r["record_id"]),r["url"])})
            if len(issues)>5:
                issuer_facts.insert(0,{"bond":records[0]["bond"],"section":"events","required":True,
                    "text":f"В сохранённом реестре записи относятся к {len(issues)} выпускам этого эмитента. Ниже пять выпусков с наиболее поздними сроками нарушенных обязательств.",
                    "refs":refs("Реестр дефолтов Московской биржи","https://www.moex.com/ru/listing/emidocs.aspx?type=4")})
            dated=db.execute("""SELECT e.bond,b.name,d.body,d.publisher,d.url FROM events e JOIN documents d ON d.id=e.document
               JOIN bonds b ON b.id=e.bond WHERE e.issuer=? AND e.kind='Просрочка' AND
               (CASE WHEN length(d.published)=10 THEN d.published||'T23:59:59' ELSE d.published END)<=?
               ORDER BY d.published DESC LIMIT 5""",(one_issuer,at))
            for event in dated:
                issuer_facts.append({"bond":event["bond"],"section":"events","text":f"{event['name']} ({event['bond']}). {event['body']}",
                                    "refs":refs(event["publisher"],event["url"])})
            if issuer_facts:
                selected=[v["bond"] for v in issuer_facts];break
        if total>1 and not (context.get("specific") and b["id"] in {r["id"] for r in items} and
                            norm(term) in (norm(b["name"]),norm(b["short"]))):
            return {**base,"text":f"По запросу «{term}» на {day(at)} найдено выпусков: {total}. Выберите серию, и я продолжу ответ на ваш вопрос.",
                    "choices":items,"retry":question,"query":term,"issuer":one_issuer}
        selected.append(b["id"] if total>1 else items[0]["id"])
    if not selected:
        if not current:
            return {**base,"text":"Укажите название эмитента, серию или ISIN, и я проверю документы по нужной облигации."}
        selected=[b["id"]]
        if not context.get("specific") and re.search("мой купон|моя облигация",question,re.I):
            found=search(db,at,issuer=b["issuer"],limit=40)
            if found["total"]>1:
                return {**base,"text":"Какой выпуск вы имеете в виду?","choices":found["items"],"retry":question}
    available=list(issuer_facts)
    for key in dict.fromkeys(selected):
        s=current if key==b["id"] else snapshot(db,key,at,context["horizon"],context["period"])
        ctx=context if key==b["id"] else {**context,"event":"","point":None,"week":None}
        if not issuer_facts:
            if saved_plan is None:
                from sync import enrich_for_chat
                if enrich_for_chat(db,s,topics):
                    s=snapshot(db,key,at,context["horizon"],context["period"],context.get("board") if key==b["id"] else None)
            available.extend(facts(db,s,topics,question,ctx))
        base["related"].append({"id":key,"name":s["bond"]["name"]})
    if not available:
        return {**base,"id":selected[0],"text":"На "+day(at)+" в подключённых источниках недостаточно сведений, чтобы ответить на этот вопрос."}
    chosen=compose(question,previous,available,topics,saved_only=saved_plan is not None)
    references=[]; paragraphs=[]
    for f in chosen:
        indices=[]
        for r in f["refs"]:
            ix=next((i for i,v in enumerate(references) if v["url"]==r["url"]),None)
            if ix is None:
                ix=len(references);references.append(r)
            if ix+1 not in indices:
                indices.append(ix+1)
        message=f["text"]+" "+" ".join(f"[{i}]" for i in indices)
        if message not in paragraphs:
            paragraphs.append(message)
    return {**base,"id":selected[0],"section":chosen[0]["section"],"refs":references,
            "text":f"На {day(at)}"+(f", {at[11:16]} МСК" if at[11:16]!="23:59" else "")+".\n\n"+"\n\n".join(paragraphs)}
