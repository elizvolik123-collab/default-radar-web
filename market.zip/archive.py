"""Hand-checked, dated summaries of the demonstration's primary sources."""
from storage import connect, init, now, log

EU, MS = "5029169023", "6164218952"
MAIN, OTHER, PEOPLE, COMP = "RU000A10BB75","RU000A10CZB9","RU000A109LH7","RU000A107C91"
RA5 = "https://raexpert.ru/releases/2026/mar05f/"
RA19 = "https://www.raexpert.ru/releases/2026/mar19e"
NCR = "https://ratings.ru/upload/iblock/27c/vznqn4nirkgdaslgsivmlccap31c698l/NCR_Evrotrans_CR_070426.pdf"
REVEAL = "https://www.e-disclosure.ru/portal/event.aspx?EventId=-CeoSjmE5QUa7AqBrQBr13A-B-B"
TERMS = "https://www.evrotrans-ao.ru/пао-евротранс-выплатило-4-й-купон-по-с/"
TERMS8 = "https://www.evrotrans-ao.ru/пао-евротранс-выплатило-5-й-купон-по-в-4/"
TERMS6 = "https://www.evrotrans-ao.ru/пао-евротранс-выплатило-5-й-купон-по-ш/"
MSDOC = "https://smart-lab.ru/company/msbleasing/blog/1269827.php"
RULES = "https://www.moex.com/a23"
NSD = "https://www.aton.ru/support/notice/issuer/?corp_nav=page-6&p=1888"
CASE_DATES=["2026-03-18","2026-03-19","2026-04-07","2026-04-08"]


def seed(db):
    stamp=now()
    db.executemany("INSERT OR IGNORE INTO issuers VALUES(?,?,?)",
                   [(EU,"ПАО «ЕвроТранс»",EU),(MS,"ООО «МСБ-Лизинг»",MS)])
    for key,name,issuer,registered,mat in [
        (MAIN,"ЕвроТранс БО-001Р-07",EU,"2025-04-02","2027-03-31"),
        (OTHER,"ЕвроТранс БО-001Р-08",EU,"2025-09-25","2030-09-07"),
        (PEOPLE,"ЕвроТранс 01",EU,"2024-09-10","2029-08-30"),
        (COMP,"МСБ-Лизинг 003Р-02",MS,"2023-11-28","2026-11-22")]:
        db.execute("""INSERT INTO bonds(id,isin,secid,name,short,issuer,currency,registered,maturity,source)
          VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET registered=excluded.registered,
          issuer=excluded.issuer,name=excluded.name,maturity=excluded.maturity""",
          (key,key,key,name,name,issuer,"RUB",registered,mat,"https://www.moex.com/ru/bonds/"+key))
    docs=[
      ("terms7",EU,MAIN,"Параметры седьмого выпуска","ЕвроТранс",TERMS,
       "Размещено 4,3 млн облигаций по 1 000 ₽. Купон фиксирован на уровне 24,5% годовых. Срок обращения составляет 720 дней.","2025-08-08","2025-05-27","Условия"),
      ("terms6",EU,"RU000A10ATS0","Параметры шестого выпуска","ЕвроТранс",TERMS6,
       "Эмитент разместил 1,93 млн облигаций номиналом 1 000 ₽. Ставка купона составляет 25% годовых, периодичность выплат — ежемесячная.","2025-07-07","2025-07-07","Условия"),
      ("terms8",EU,OTHER,"Купон и объём восьмого выпуска","ЕвроТранс",TERMS8,
       "По серии БО-001Р-08 размещено 4,5 млн облигаций. Для первых 24 купонов установлена ставка 21% годовых.","2026-03-03","2026-03-03","Условия"),
      ("notice",EU,MAIN,"Объявление о предстоящем купоне № 12","НРД через АТОН",NSD,
       "Уведомление № 1027816 о купоне серии БО-001Р-07 опубликовано 17 марта. Продолжительность периода — 30 дней.","2026-03-17","2026-03-17","Календарь"),
      ("watch",EU,None,"Рейтинг ruA− под наблюдением","Эксперт РА",RA5,
       "Рейтинг эмитента сохранён на уровне ruA− со стабильным прогнозом. Агентство поместило рейтинг под наблюдение.","2026-03-05","2026-03-05","Рейтинг"),
      ("downgrade",EU,None,"Снижение рейтинга эмитента до ruC","Эксперт РА",RA19,
       "Эксперт РА понизило рейтинг эмитента с ruA− до ruC после задержки выкупа другой серии — «ЕвроТранс, 01». Агентство квалифицировало её как технический дефолт. Прогноз развивающийся, наблюдение продолжается.","2026-03-19","2026-03-19","Рейтинг"),
      ("ncr",EU,MAIN,"НКР подтвердило просрочку и последующую выплату","НКР",NCR,
       "Купон БО-001Р-07 следовало выплатить 6 апреля. По данным НКР, полная выплата завершилась 7 апреля. НКР снизило рейтинг компании с A−.ru до CC.ru и поместило его на пересмотр с неопределённым прогнозом.","2026-04-07","2026-04-07","Платёж"),
      ("disclosure",EU,MAIN,"Эмитент раскрыл размер просрочки","Центр раскрытия · Интерфакс",REVEAL,
       "План по 12-му купону составлял 86 602 000 ₽. К 6 апреля эмитент не перечислил 76 602 000 ₽. Компания объяснила частичное исполнение ошибкой при расчёте выплаты.","2026-04-08T17:16:00","2026-04-06","Раскрытие"),
      ("msb",MS,COMP,"Купон № 27 выплачен в срок","МСБ-Лизинг",MSDOC,
       "Эмитент подтвердил своевременное перечисление купона в размере 1 314 000 ₽ и частичное погашение номинала на 9 999 000 ₽. Следующий купон назначен на 27 марта.","2026-02-25T14:23:00","2026-02-25","Платёж")]
    for doc in docs:
        db.execute("""INSERT INTO documents VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
          published=excluded.published,url=excluded.url,body=excluded.body""",(*doc[:-1],stamp,doc[-1]))
    events=[
      ("watch","watch",None,EU,"Рейтинг","2026-03-05","Рейтинг под наблюдением","Эксперт РА","ruA−","ruA−","Стабильный"),
      ("rating","downgrade",None,EU,"Рейтинг","2026-03-19","Снижение рейтинга","Эксперт РА","ruA−","ruC","Развивающийся"),
      ("buyback","downgrade",PEOPLE,EU,"Просрочка","2026-03-18","Задержка выкупа серии 01",None,None,None,None),
      ("late","ncr",MAIN,EU,"Просрочка","2026-04-06","Нарушен срок купона № 12",None,None,None,None),
      ("paid","ncr",MAIN,EU,"Исполнение","2026-04-07","Выплата завершена",None,None,None,None),
      ("ncr-rating","ncr",None,EU,"Рейтинг","2026-04-07","НКР пересмотрело рейтинг","НКР","A−.ru","CC.ru","На пересмотре"),
      ("amounts","disclosure",MAIN,EU,"Раскрытие","2026-04-08","Раскрыты суммы",None,None,None,None),
      ("msb","msb",COMP,MS,"Исполнение","2026-02-25","Купон выплачен в срок",None,None,None,None)]
    db.executemany("INSERT OR REPLACE INTO events VALUES(?,?,?,?,?,?,?,?,?,?,?)",events)
    def plan(key,bond,day,kind,amount,unit,known,source,label):
        db.execute("""INSERT INTO plans VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
                   source=excluded.source,known=excluded.known,amount=excluded.amount""",
                   (key,bond,day,kind,amount,unit,"RUB",known,source,label,stamp))
    # Fixed-rate contractual estimates from published terms. Dates below are working settlement dates.
    for index,day in enumerate(["2026-04-06","2026-05-05","2026-06-04","2026-07-06"],12):
        plan(f"c{index}",MAIN,day,"Купон",20.14*4300000,20.14,"2026-03-17",TERMS,f"Купон № {index}")
    for index,day in enumerate(["2026-04-01","2026-05-04","2026-06-01","2026-06-30"],6):
        plan(f"eight{index}",OTHER,day,"Купон",17.26*4500000,17.26,"2026-03-03",TERMS8,f"Купон № {index}")
    for index,day in enumerate(["2026-04-03","2026-05-04","2026-06-02"],14):
        plan(f"six{index}","RU000A10ATS0",day,"Купон",20.55*1930000,20.55,"2025-07-07",TERMS6,f"Купон № {index}")
    plan("msb27",COMP,"2026-02-25","Купон",1314000,4.38,"2026-02-25T14:23:00",MSDOC,"Купон № 27")
    plan("msbam",COMP,"2026-02-25","Амортизация",9999000,33.33,"2026-02-25T14:23:00",MSDOC,"Частичное погашение")
    plan("msb28",COMP,"2026-03-27","Купон",None,None,"2026-02-25T14:23:00",MSDOC,"Купон № 28")
    db.executemany("INSERT OR REPLACE INTO executions VALUES(?,?,?,?,?,?,?)",[
        ("c12","ncr","Срок нарушен",None,None,None,"2026-04-06"),
        ("c12","ncr","Исполнено с опозданием",None,None,0,"2026-04-07"),
        ("c12","disclosure","Частично в срок",86602000,76602000,None,"2026-04-06"),
        ("msb27","msb","Исполнено в срок",1314000,0,0,"2026-02-25"),
        ("msbam","msb","Исполнено в срок",9999000,0,0,"2026-02-25")])
    for doc in docs:
        key,issuer,bond,title,publisher,url,_,published,_,kind=doc
        if kind in ("Платёж","Рейтинг","Раскрытие"):
            db.execute("INSERT OR IGNORE INTO news VALUES(?,?,?,?,?,?,?,?,?,?)",
                       (key,"Выпуск" if bond else "Эмитент",issuer,bond,published,title,publisher,url,key,stamp))
    db.execute("INSERT OR IGNORE INTO news VALUES(?,?,?,?,?,?,?,?,?,?)",
        ("mt366482","Эмитент",EU,None,"2026-04-13T09:17:44","Обзор двух задержек выплат ЕвроТранса",
         "MarketTwits","https://t.me/markettwits/366482","ncr",stamp))
    if not db.execute("SELECT 1 FROM refresh WHERE source='Архив документов' AND count=?",(len(docs),)).fetchone():
        log(db,"Архив документов",len(docs))


if __name__=="__main__":
    with connect() as db:
        init(db)
        seed(db)
