"""Queries against the published snapshot, executed inside one visitor's browser."""
import json
import re
from contextlib import closing
from urllib.parse import parse_qsl, urlsplit

from dialogue import TOPICS, augment_topics, live_answer, targets
from credit_data import DB, open_data
from market_api import context, read_api
from storage import connect


def archive_plan(db, question, previous):
    topics=augment_topics([],question)
    if not topics and re.search(r"а (раньше|сейчас|потом)|а за |динамик|изменил",question,re.I):
        for message in reversed(previous):
            if message["role"]=="user":
                topics=augment_topics([],message["content"])
                if topics:break
    queries=re.findall(r"[«\"]([^»\"]{2,65})[»\"]",question)
    if not queries and not targets(question,[]) and DB.is_file():
        with closing(open_data()) as store:
            codes={r[0].upper():r[1] for r in store.execute("SELECT DISTINCT ticker,issuer FROM reports")}
        for word in re.findall(r"\b[A-Z][A-Z0-9]{1,9}\b",question,re.I|re.ASCII):
            if word.upper() in codes:queries.append(codes[word.upper()])
        if not queries:
            skip={"акционерное","общество","компания","группа","группы","финанс","банк","публичное","российской","федерации"}
            words={v.lower() for v in re.findall(r"[А-Яа-яЁё-]{4,}",question)}
            for row in db.execute("SELECT name FROM issuers"):
                for token in re.findall(r"[А-Яа-яЁё-]{4,}",row[0].lower()):
                    if token not in skip and any(w==token or len(token)>5 and w.startswith(token[:-1]) and abs(len(w)-len(token))<=1 for w in words):
                        if token not in queries: queries.append(token)
        queries=sorted(queries,key=len,reverse=True)[:2]
    return queries, topics


def dispatch(raw):
    req = json.loads(raw)
    url = urlsplit(req["url"])
    with closing(connect()) as db:
        if url.path == "/api/chat":
            body = req["body"]
            question = body["question"].strip()[:2000]
            plan = req.get("plan") or {}
            queries = [v for v in plan.get("queries", []) if isinstance(v, str)][:2]
            topics = [v for v in plan.get("topics", []) if v in TOPICS]
            previous=[{"role":"user","content":str(v)[:400]} for v in body.get("history",[])[-4:]]
            if not plan:queries,topics=archive_plan(db,question,previous)
            label="GPT · проверка по источникам" if plan else "Поиск по опубликованным данным"
            result = live_answer(db, context(body), question, previous, saved_plan=(queries, topics), mode_label=label)
        else:
            result = read_api(db, url.path, dict(parse_qsl(url.query)), ("browser", "Поиск по документам"))
    return json.dumps(result, ensure_ascii=False, allow_nan=False)
