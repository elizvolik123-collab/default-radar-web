"""Queries against the published snapshot, executed inside one visitor's browser."""
import json
from contextlib import closing
from urllib.parse import parse_qsl, urlsplit

from dialogue import TOPICS, live_answer
from market_api import context, read_api
from storage import connect


def dispatch(raw):
    req = json.loads(raw)
    url = urlsplit(req["url"])
    with closing(connect()) as db:
        if url.path == "/api/chat":
            body = req["body"]
            question = body["question"].strip()[:2000]
            plan = req.get("plan") or {}
            queries = [v for v in plan.get("queries", []) if isinstance(v, str)][:2]
            topics = [v for v in plan.get("topics", []) if v in TOPICS] or ["паспорт"]
            label = "Qwen2.5 · разбор вопроса по документам" if req.get("plan") else "Поиск по сохранённым документам"
            result = live_answer(db, context(body), question, [], saved_plan=(queries, topics), mode_label=label)
        else:
            result = read_api(db, url.path, dict(parse_qsl(url.query)), ("browser", "Поиск по документам"))
    return json.dumps(result, ensure_ascii=False, allow_nan=False)
