"""Queries against the published snapshot, executed inside one visitor's browser."""
import json
from contextlib import closing
from urllib.parse import parse_qsl, urlsplit

from dialogue import archive_plan, live_answer
from market_api import context, read_api
from storage import connect


def hosted_answer(db,body,question,previous,endpoint):
    # Pyodide runs in a browser worker. API credentials stay on the hosting service.
    from js import XMLHttpRequest
    model=None

    def generate(system,prompt,schema,max_tokens):
        nonlocal model
        operation="plan" if "queries" in schema["properties"] else "answer"
        xhr=XMLHttpRequest.new()
        xhr.open("POST",endpoint,False)
        xhr.timeout=65000
        xhr.setRequestHeader("Content-Type","application/json")
        xhr.send(json.dumps({"operation":operation,"input":json.loads(prompt)},ensure_ascii=False))
        if xhr.status!=200:
            raise OSError("HTTP "+str(xhr.status))
        reply=json.loads(str(xhr.responseText))
        if not isinstance(reply.get("output"),dict) or not isinstance(reply.get("model"),str):
            raise ValueError("Некорректный ответ модели")
        provider=reply.get("provider")
        model=(provider+" · " if provider in ("DeepSeek","Groq") else "")+reply["model"]
        return reply["output"]

    try:
        result=live_answer(db,context(body),question,previous,mode_label="Данные радара",generate=generate)
        if model:result["mode"]=model
        return result
    except Exception as exc:
        # Browser transport errors are JsException. Never send prompt or provider response to logs.
        label="Модель недоступна · поиск по архиву"
        if isinstance(exc,OSError) and str(exc)=="HTTP 429":
            label="Суточный лимит вызовов исчерпан · поиск по архиву"
        return live_answer(db,context(body),question,previous,saved_plan=archive_plan(db,question,previous),mode_label=label)


def dispatch(raw):
    req = json.loads(raw)
    url = urlsplit(req["url"])
    with closing(connect()) as db:
        if url.path == "/api/chat":
            body = req["body"]
            question = body["question"].strip()[:2000]
            previous=[{"role":"user","content":str(v)[:400]} for v in body.get("history",[])[-4:]]
            if req.get("groq_endpoint") and body.get("mode")!="demo":
                result=hosted_answer(db,body,question,previous,req["groq_endpoint"])
            else:
                result=live_answer(db,context(body),question,previous,saved_plan=archive_plan(db,question,previous),
                                   mode_label="Поиск по опубликованным данным")
        else:
            result = read_api(db, url.path, dict(parse_qsl(url.query)), ("browser", "Поиск по документам"))
    return json.dumps(result, ensure_ascii=False, allow_nan=False)
