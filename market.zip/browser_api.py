"""Queries against the published snapshot, executed inside one visitor's browser."""
import json
from contextlib import closing
from urllib.parse import parse_qsl, urlsplit

from dialogue import archive_plan, live_answer
from market_api import context, read_api
from storage import connect


def dispatch(raw):
    req = json.loads(raw)
    url = urlsplit(req["url"])
    with closing(connect()) as db:
        if url.path == "/api/chat":
            body = req["body"]
            question = body["question"].strip()[:2000]
            previous=[{"role":"user","content":str(v)[:400]} for v in body.get("history",[])[-4:]]
            result=live_answer(db,context(body),question,previous,saved_plan=archive_plan(db,question,previous),
                               mode_label="Поиск по опубликованным данным")
        else:
            result = read_api(db, url.path, dict(parse_qsl(url.query)), ("browser", "Поиск по документам"))
    return json.dumps(result, ensure_ascii=False, allow_nan=False)
