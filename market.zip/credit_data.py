"""Dated market and issuer evidence shared by the site, chat and JSON API."""
import json
import sqlite3
from contextlib import closing
from datetime import date, timedelta
from storage import ROOT

DB = ROOT / "data/market.sqlite3"
LABELS = {
    "revenue":"Выручка", "operating_income":"Операционная прибыль", "net_income":"Чистая прибыль",
    "ebitda":"EBITDA", "ocf":"Операционный денежный поток", "fcf":"Свободный денежный поток",
    "capex":"Капитальные затраты", "interest_expenses":"Процентные расходы", "assets":"Активы",
    "net_assets":"Чистые активы", "equity":"Собственный капитал", "cash":"Денежные средства",
    "debt":"Финансовый долг", "net_debt":"Чистый долг", "debt_ebitda":"Долг / EBITDA",
    "net_leverage":"Чистый долг / EBITDA", "interest_cover":"Покрытие процентов операционной прибылью",
    "cash_cover":"Денежные средства / краткосрочный долг", "current_ratio":"Текущая ликвидность",
    "current_assets":"Оборотные активы", "current_liabilities":"Краткосрочные обязательства",
    "short_term_debt":"Краткосрочный финансовый долг","long_term_debt":"Долгосрочный финансовый долг",
    "roe":"Рентабельность капитала","roa":"Рентабельность активов","net_margin":"Чистая рентабельность",
    "ebitda_margin":"Маржа EBITDA","net_interest_income":"Чистый процентный доход",
    "net_interest_margin":"Чистая процентная маржа","cost_of_risk":"Стоимость риска",
    "capital_adequacy":"Достаточность капитала","npl":"Проблемные кредиты","npl_ratio":"Доля проблемных кредитов",
    "core_capital_adequacy_ratio":"Достаточность основного капитала","total_capital_adequacy_ratio":"Достаточность общего капитала",
    "share_of_non_performing_loans":"Доля проблемных кредитов (NPL)","cost_of_risk_ratio":"Стоимость риска (CoR)",
    "net_intertest_margin":"Чистая процентная маржа","provision_for_loan_impairment":"Резервы под обесценение",
    "creation_of_provision_for_loan_impairment":"Создание резервов","capital":"Капитал","loan_portfolio":"Кредитный портфель",
}


def open_data():
    db = sqlite3.connect(DB.as_uri()+"?mode=ro", uri=True)
    db.row_factory=sqlite3.Row
    return db


def market(at):
    result={"series":[], "headlines":[]}
    if not DB.is_file():return result
    # Intraday cuts use the last complete trading day in the saved daily series.
    last=at[:10] if at[11:19]=="23:59:59" else (date.fromisoformat(at[:10])-timedelta(days=1)).isoformat()
    with closing(open_data()) as db:
        for code in ("KEY","RGBI","RGBITR","RUCBTRNS","IMOEX"):
            rows=db.execute("SELECT * FROM series WHERE code=? AND day<=? ORDER BY day DESC LIMIT 255",(code,last)).fetchall()
            if rows:
                row=dict(rows[0]);row["points"]=[[r["day"],r["value"]] for r in reversed(rows)]
                row["previous"]=rows[1]["value"] if len(rows)>1 else None
                result["series"].append(row)
        result["headlines"]=[dict(r) for r in db.execute("SELECT * FROM headlines WHERE published<=? ORDER BY published DESC LIMIT 6",(at,))]
    return result


def issuer_reports(inn,at):
    if not DB.is_file():return []
    with closing(open_data()) as db:
        rows=db.execute("""SELECT * FROM reports WHERE issuer=? AND published||'T23:59:59'<=?
                            ORDER BY published DESC,length(period),period DESC LIMIT 16""",(inn,at)).fetchall()
    result=[]
    for row in rows:
        report=dict(row)
        metrics=json.loads(report.pop("metrics"))
        for field in metrics.values():field[1]=field[1].rsplit(",",1)[-1].strip()
        def ratio(key,numerator,denominator):
            a,b=metrics.get(numerator),metrics.get(denominator)
            if a and b and b[0]>0 and a[1] and a[1]==b[1]:metrics[key]=[round(a[0]/b[0],3),"×"]
        bank="loan_portfolio" in metrics or "total_capital_adequacy_ratio" in metrics
        if not bank:
            ratio("interest_cover","operating_income","interest_expenses")
            if "Q" not in report["period"]:ratio("net_leverage","net_debt","ebitda")
            ratio("current_ratio","current_assets","current_liabilities")
            ratio("cash_cover","cash","short_term_debt")
        flags=[]
        checks=[("ocf",0,"Операционная деятельность потребляет денежные средства."),
                ("fcf",0,"После капитальных затрат свободный денежный поток отрицателен."),
                ("net_income",0,"За отчётный период получен чистый убыток."),
                ("net_assets",0,"Чистые активы отрицательны."),
                ("interest_cover",1,"Операционная прибыль ниже процентных расходов."),
                ("current_ratio",1,"Краткосрочные обязательства превышают оборотные активы."),
                ("cash_cover",1,"Остаток денежных средств меньше краткосрочного финансового долга."),
                ("ebitda",0,"EBITDA отрицательна. Отношение долга к EBITDA теряет экономический смысл.")]
        for key,threshold,reason in checks:
            if bank and key in ("ocf","fcf","ebitda"):continue
            if key in metrics and metrics[key][0]<threshold:flags.append({"key":key,"text":reason})
        report["metrics"]={k:{"name":LABELS[k],"value":v[0],"unit":v[1]} for k,v in metrics.items() if k in LABELS}
        report["flags"]=flags
        result.append(report)
    for current in result:
        prior_period=str(int(current["period"][:4])-1)+current["period"][4:]
        previous=next((r for r in result if r["period"]==prior_period and r["standard"]==current["standard"]),None)
        if not previous:continue
        for key in ("net_leverage","interest_cover","revenue","cost_of_risk_ratio","share_of_non_performing_loans","total_capital_adequacy_ratio"):
            a,b=current["metrics"].get(key),previous["metrics"].get(key)
            if not a or not b or a["unit"]!=b["unit"]:continue
            rising=key in ("net_leverage","cost_of_risk_ratio","share_of_non_performing_loans")
            if (rising and a["value"]>b["value"]) or (not rising and a["value"]<b["value"]):
                current["flags"].append({"key":key,"text":f"{a['name']}: {b['value']:g} → {a['value']:g} {a['unit']} за год."})
    return result


def bond_terms(bond,at):
    if not DB.is_file():return None
    with closing(open_data()) as db:
        row=db.execute("SELECT * FROM terms WHERE bond=? AND seen<=? ORDER BY seen DESC LIMIT 1",(bond,at)).fetchone()
    return dict(row) if row else None


def saved_prices(secid,board,start,last):
    if not DB.is_file():return []
    with closing(open_data()) as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='daily'").fetchone():return []
        return [dict(r) for r in db.execute("SELECT * FROM daily WHERE secid=? AND board=? AND day BETWEEN ? AND ? ORDER BY day",
                                            (secid,board,start,last))]
