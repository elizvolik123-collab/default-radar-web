"""Dated market and issuer evidence shared by the site, chat and JSON API."""
import json
import sqlite3
from functools import lru_cache
from contextlib import closing
from datetime import date, timedelta
from storage import ROOT, connect, now

DB = ROOT / "data/market.sqlite3"
ISSUER_PROFILES = json.loads((ROOT/"data/issuer_profiles.json").read_text("utf-8"))
INDICES = {
    "RGBI": "RGBI · чистые цены ОФЗ",
    "RUCBCPNS": "Корпоративные облигации · чистые цены",
    "RUCBTRNS": "Корпоративные облигации · совокупный доход",
    "RUCBTRAAANS": "Корпоративные облигации AAA · совокупный доход",
    "IMOEX": "Индекс Мосбиржи",
}
CURVE_URL = "https://www.cbr.ru/hd_base/zcyc_params/"
LABELS = {
    "working_capital":"Чистый оборотный капитал", "inventories":"Запасы",
    "short_debt_share":"Доля краткосрочных заёмных средств",
    "cash_to_debt_pct":"Деньги и эквиваленты / финансовый долг",
    "debt_to_assets_pct":"Финансовый долг / активы",
    "revenue":"Выручка", "operating_income":"Операционная прибыль", "net_income":"Чистая прибыль",
    "ebitda":"EBITDA", "ocf":"Операционный денежный поток", "fcf":"Свободный денежный поток",
    "capex":"Капитальные затраты", "interest_expenses":"Процентные расходы", "assets":"Активы",
    "net_assets":"Чистые активы", "equity":"Собственный капитал", "cash":"Денежные средства",
    "debt":"Финансовый долг", "net_debt":"Чистый долг", "debt_ebitda":"Долг / EBITDA",
    "net_leverage":"Чистый долг / EBITDA", "interest_cover":"Покрытие процентов операционной прибылью",
    "cash_cover":"Денежные средства / краткосрочный долг", "current_ratio":"Текущая ликвидность",
    "current_assets":"Оборотные активы", "current_liabilities":"Краткосрочные обязательства",
    "short_term_debt":"Краткосрочный финансовый долг","long_term_debt":"Долгосрочный финансовый долг",
    "roe":"Рентабельность капитала","roa":"Рентабельность активов","net_margin":"Чистая рентабельность",
    "ebitda_margin":"Маржа EBITDA","net_interest_income":"Чистый процентный доход",
    "net_interest_margin":"Чистая процентная маржа","cost_of_risk":"Стоимость риска",
    "capital_adequacy":"Достаточность капитала","npl":"Проблемные кредиты","npl_ratio":"Доля проблемных кредитов",
    "core_capital_adequacy_ratio":"Достаточность основного капитала","total_capital_adequacy_ratio":"Достаточность общего капитала",
    "share_of_non_performing_loans":"Доля проблемных кредитов (NPL)","cost_of_risk_ratio":"Стоимость риска (CoR)",
    "net_intertest_margin":"Чистая процентная маржа","provision_for_loan_impairment":"Резервы под обесценение",
    "creation_of_provision_for_loan_impairment":"Создание резервов","capital":"Капитал","loan_portfolio":"Кредитный портфель",
}


def open_data():
    db = sqlite3.connect(DB.as_uri()+"?mode=ro", uri=True)
    db.row_factory=sqlite3.Row
    return db


def market(at):
    result={"series":[], "headlines":[], "bonds":[], "curve":None,"corporate":[]}
    if not DB.is_file():return result
    # Intraday cuts use the last complete trading day in the saved daily series.
    last=at[:10] if at[11:19]=="23:59:59" else (date.fromisoformat(at[:10])-timedelta(days=1)).isoformat()
    with closing(open_data()) as db:
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='curve'").fetchone():
            curve=db.execute("SELECT * FROM curve WHERE day=(SELECT max(day) FROM curve WHERE day<=?) ORDER BY years",(last,)).fetchall()
            if curve:
                day=curve[0]["day"]
                result["curve"]={"day":day,"points":[[r["years"],r["yield_pct"]] for r in curve],
                                 "url":CURVE_URL+"zcyc/?DateTo="+date.fromisoformat(day).strftime("%d.%m.%Y")}
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='corporate_yields'").fetchone():
            for code in ("RUCBTRNS","RUCBTRAAANS"):
                row=db.execute("SELECT * FROM corporate_yields WHERE code=? AND day<=? ORDER BY day DESC LIMIT 1",(code,last)).fetchone()
                if not row:continue
                item=dict(row);item["premium_bp"]=None;item["benchmark"]=None
                points=db.execute("SELECT years,yield_pct FROM curve WHERE day=? ORDER BY years",(row["day"],)).fetchall()
                years=row["duration_days"]/365
                for (t1,y1),(t2,y2) in zip(points,points[1:]):
                    if t1<=years<=t2:
                        spot=y1+(y2-y1)*(years-t1)/(t2-t1)
                        item.update(benchmark=round(spot,3),premium_bp=round(100*(row["yield_pct"]-spot)))
                        break
                item["url"]="https://iss.moex.com/iss/history/engines/stock/markets/index/boards/RTSI/securities/"+code+".json?from="+row["day"]+"&till="+row["day"]
                item["curve_url"]=CURVE_URL+"zcyc/?DateTo="+date.fromisoformat(row["day"]).strftime("%d.%m.%Y")
                result["corporate"].append(item)
        candle_columns = {r[1] for r in db.execute("PRAGMA table_info(index_candles)")}
        turnover = "turnover_rub" if "turnover_rub" in candle_columns else "NULL"
        completed=min(last,(date.fromisoformat(now()[:10])-timedelta(days=1)).isoformat())
        for code in ("KEY",*INDICES):
            rows=db.execute("SELECT * FROM series WHERE code=? AND day<=? ORDER BY day DESC LIMIT 730",(code,last if code=="KEY" else completed)).fetchall()
            if rows:
                row=dict(rows[0]);row["points"]=[[r["day"],r["value"]] for r in reversed(rows)]
                row["label"]=INDICES.get(code,row["label"])
                row["previous"]=rows[1]["value"] if len(rows)>1 else None
                if code in INDICES:
                    row["candles"] = [list(r) for r in db.execute(
                        f"SELECT day,open,high,low,close,{turnover} FROM index_candles WHERE code=? AND day<=? ORDER BY day",
                        (code, completed))] if candle_columns else []
                    row["candles_url"] = (f"https://iss.moex.com/iss/engines/stock/markets/index/securities/{code}/candles.json"
                                          f"?interval=24&from=2014-01-01&till={completed}")
                result["series"].append(row)
        result["headlines"]=[dict(r) for r in db.execute("SELECT * FROM headlines WHERE published<=? ORDER BY published DESC LIMIT 6",(at,))]
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='daily'").fetchone():
            with closing(connect()) as catalog:
                allowed = covered_bonds(catalog, at)
                for board in ("TQOB","TQCB"):
                    added = 0
                    for r in db.execute("""SELECT * FROM daily WHERE board=? AND day=(
                            SELECT max(day) FROM daily WHERE board=? AND day<=?) ORDER BY trades DESC,secid""",(board,board,last)):
                        label=catalog.execute("SELECT short,id FROM bonds WHERE secid=?",(r["secid"],)).fetchone()
                        if not label or label[1] not in allowed:
                            continue
                        added += 1
                        prev=db.execute("SELECT price FROM daily WHERE secid=? AND board=? AND day<? ORDER BY day DESC LIMIT 1",(r["secid"],board,r["day"])).fetchone()
                        result["bonds"].append({"code":r["secid"],"label":label[0] if label else r["secid"],"board":board,
                                  "day":r["day"],"unit":"% ном.","value":r["price"],"previous":prev[0] if prev else None})
                        if added == 2:
                            break
    return result


def reviewed_statements():
    path=ROOT/"data/reviewed_statements.json"
    return json.loads(path.read_text("utf-8")) if path.exists() else []


def issuer_reports(inn,at):
    if not DB.is_file():return []
    with closing(open_data()) as db:
        rows=db.execute("""SELECT * FROM reports WHERE issuer=? AND published||'T23:59:59'<=?
                            ORDER BY published DESC,length(period),period DESC LIMIT 16""",(inn,at)).fetchall()
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='report_editions'").fetchone():
            by_period={(r["period"],r["standard"]):r for r in rows}
            for revision in db.execute("""SELECT * FROM report_editions WHERE issuer=? AND observed<=?
                AND published||'T23:59:59'<=? ORDER BY observed""",(inn,at,at)):
                by_period[revision["period"],revision["standard"]]=revision
            rows=list(by_period.values())
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='filing_numbers'").fetchone():
            rows+=db.execute("""SELECT n.issuer,n.period,'МСФО' standard,substr(n.published,1,10) published,
                '' ticker,f.url,f.url original,n.metrics FROM filing_numbers n JOIN filings f
                ON (n.issuer,n.uid,n.published)=(f.issuer,f.uid,f.published)
                WHERE f.issuer=? AND f.removed=0 AND f.published=(SELECT max(v.published) FROM filings v
                WHERE v.issuer=f.issuer AND v.uid=f.uid AND v.published<=?)""",(inn,at)).fetchall()
        verified={}
        for record in reviewed_statements():
            if record["inn"]!=inn or record["published"]+"T23:59:59">at:continue
            verified[record["url"],record["period"]]=record
            rows.append(dict(issuer=inn,period=record["period"],standard=record["standard"],published=record["published"],
                             ticker="",url=record["url"],original=record["url"],metrics=json.dumps(
                                 {k:[v[0],record["unit"]] for k,v in record["metrics"].items()})))
        rows.sort(key=lambda r:(r["published"],(r["url"],r["period"]) in verified,r["period"]),reverse=True)
    result=[]
    for row in rows:
        report=dict(row)
        report["provider"]="Smart-Lab" if "smart-lab.ru/" in report["url"] else ("Интерфакс · ЦРКИ" if "e-disclosure.ru/" in report["url"] else "Эмитент")
        metrics=json.loads(report.pop("metrics"))
        record=verified.get((report["url"],report["period"]))
        if record:
            report["provider"]=record.get("provider",report["provider"])
            report["publication_url"]=record.get("publication_url")
            report["pages"]={k:v[1] for k,v in record["metrics"].items()}
            inputs={
                "current_ratio":("current_assets","current_liabilities"),"cash_cover":("cash","short_term_debt"),
                "working_capital":("current_assets","current_liabilities"),"short_debt_share":("short_term_debt","long_term_debt"),
                "interest_cover":("operating_income","interest_expenses"),
            }
            for key,fields in inputs.items():
                if all(k in report["pages"] for k in fields):
                    pages=list(dict.fromkeys(report["pages"][k] for k in fields))
                    adjacent=len(pages)==2 and all(p.isdigit() for p in pages) and int(pages[1])==int(pages[0])+1
                    report["pages"][key]=("–" if adjacent else ", ").join(pages)
        for field in metrics.values():field[1]=field[1].rsplit(",",1)[-1].strip()
        def ratio(key,numerator,denominator):
            a,b=metrics.get(numerator),metrics.get(denominator)
            if a and b and b[0]>0 and a[1] and a[1]==b[1]:metrics[key]=[round(a[0]/b[0],3),"×"]
        bank="loan_portfolio" in metrics or "total_capital_adequacy_ratio" in metrics
        if not bank:
            ratio("interest_cover","operating_income","interest_expenses")
            if len(report["period"])==4:ratio("net_leverage","net_debt","ebitda")
            ratio("current_ratio","current_assets","current_liabilities")
            ratio("cash_cover","cash","short_term_debt")
            for key,numerator,denominator in (("cash_to_debt_pct","cash","debt"),("debt_to_assets_pct","debt","assets")):
                a,b=metrics.get(numerator),metrics.get(denominator)
                if a and b and b[0]>0 and a[0]>=0 and a[1] and a[1]==b[1]:
                    metrics[key]=[round(100*a[0]/b[0],2),"%"]
            for a,b,key in (("current_assets","current_liabilities","working_capital"),("short_term_debt","long_term_debt","short_debt_share")):
                if a in metrics and b in metrics and metrics[a][1] and metrics[a][1]==metrics[b][1]:
                    x,y=metrics[a][0],metrics[b][0]
                    if key=="working_capital":metrics[key]=[x-y,metrics[a][1]]
                    elif x>=0 and y>=0 and x+y>0:metrics[key]=[round(100*x/(x+y),2),"%"]
        flags=[]
        checks=[("ocf",0,"Операционная деятельность потребляет денежные средства."),
                ("fcf",0,"После капитальных затрат свободный денежный поток отрицателен."),
                ("net_income",0,"За отчётный период получен чистый убыток."),
                ("net_assets",0,"Чистые активы отрицательны."),
                ("interest_cover",1,"Операционная прибыль ниже процентных расходов."),
                ("current_ratio",1,"Краткосрочные обязательства превышают оборотные активы."),
                ("cash_cover",1,"Остаток денежных средств меньше краткосрочного финансового долга."),
                ("ebitda",0,"EBITDA отрицательна. Отношение долга к EBITDA теряет экономический смысл.")]
        for key,threshold,reason in checks:
            if bank and key in ("ocf","fcf","ebitda"):continue
            if key in metrics and metrics[key][0]<threshold:flags.append({"key":key,"text":reason})
        report["metrics"]={k:{"name":LABELS[k],"value":v[0],"unit":v[1]} for k,v in metrics.items() if k in LABELS}
        report["flags"]=flags
        result.append(report)
    for current in result:
        prior_period=str(int(current["period"][:4])-1)+current["period"][4:]
        previous=next((r for r in result if r["period"]==prior_period and r["standard"]==current["standard"]),None)
        if not previous:continue
        for key in ("net_leverage","interest_cover","revenue","cost_of_risk_ratio","share_of_non_performing_loans","total_capital_adequacy_ratio"):
            a,b=current["metrics"].get(key),previous["metrics"].get(key)
            if not a or not b or a["unit"]!=b["unit"]:continue
            rising=key in ("net_leverage","cost_of_risk_ratio","share_of_non_performing_loans")
            if (rising and a["value"]>b["value"]) or (not rising and a["value"]<b["value"]):
                current["flags"].append({"key":key,"text":f"{a['name']}: {b['value']:g} → {a['value']:g} {a['unit']} за год."})
    return result


def covered_bonds(db, at):
    """Public universe on the analysis date. Federal debt has no corporate accounts."""
    inns = reporting_issuers(at, DB.stat().st_mtime_ns if DB.exists() else 0,
                             (ROOT/"data/reviewed_statements.json").stat().st_mtime_ns)
    return {key for key, inn, secid in db.execute(
        """SELECT id, issuer, secid FROM bonds WHERE length(isin)=12
           AND (source LIKE 'https://%' OR source LIKE 'http://%')""")
        if inn in inns or (inn == "7710168360" and secid.startswith("SU"))}


@lru_cache(maxsize=8)
def reporting_issuers(at, database_version, reviewed_version):
    if not DB.exists():
        return frozenset()
    with closing(open_data()) as store:
        candidates = {row[0] for row in store.execute("SELECT DISTINCT issuer FROM reports")}
        if store.execute("SELECT 1 FROM sqlite_master WHERE name='filing_numbers'").fetchone():
            candidates.update(row[0] for row in store.execute("SELECT DISTINCT issuer FROM filing_numbers"))
    candidates.update(item["inn"] for item in reviewed_statements())
    return frozenset(inn for inn in candidates if any(
        r["url"].startswith(("https://", "http://")) and r["metrics"]
        for r in issuer_reports(inn, at)))


def payment_pressures(report):
    """Financial warning signs for a payment review, with their original reporting period."""
    explanations={
        "current_ratio":"Оборотных активов меньше, чем краткосрочных обязательств.",
        "cash_cover":"Деньги и эквиваленты покрывают лишь часть краткосрочного финансового долга.",
        "interest_cover":"Операционная прибыль за период не покрывает процентные расходы.",
        "ocf":"Операционная деятельность за период потребляла деньги.",
        "fcf":"Свободный денежный поток за период отрицательный.",
        "equity":"Собственный капитал отрицательный.",
        "net_leverage":"Чистый долг превышает либо равен четырём годовым EBITDA.",
    }
    metrics=report["metrics"]
    bank=any(k in metrics for k in ("loan_portfolio","total_capital_adequacy_ratio","net_interest_income"))
    result=[]
    for key,reason in explanations.items():
        metric=metrics.get(key)
        if not metric or (bank and key!="equity"):continue
        value=metric["value"]
        adverse=value>=4 if key=="net_leverage" else value<(1 if key in ("cash_cover","current_ratio","interest_cover") else 0)
        if adverse:
            page=report.get("pages",{}).get(key)
            number=format(value,",.3f").rstrip("0").rstrip(".").replace(","," ").replace(".",",")
            label=f"{metric['name']} за {report['period']} — {number} {metric['unit']}"
            result.append(f"{label}. {reason}"+(f" Стр. {page}." if page else ""))
    return result


def issuer_filings(inn,at,bond=None):
    if not DB.is_file():return []
    with closing(open_data()) as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='filings'").fetchone():return []
        rows=db.execute("""SELECT f.* FROM filings f WHERE issuer=? AND published<=?
            AND published=(SELECT max(v.published) FROM filings v WHERE v.issuer=f.issuer AND v.uid=f.uid AND v.published<=?)
            AND removed=0 AND (? IS NULL OR isin='' OR isin=?) ORDER BY published DESC,uid""",(inn,at,at,bond,bond))
        result={}
        for row in rows:result.setdefault(row["url"].lower(),dict(row))
        return list(result.values())


def bond_terms(bond,at):
    if not DB.is_file():return None
    with closing(open_data()) as db:
        row=db.execute("SELECT * FROM terms WHERE bond=? AND seen<=? ORDER BY seen DESC LIMIT 1",(bond,at)).fetchone()
    return dict(row) if row else None


def saved_prices(secid,board,start,last):
    if not DB.is_file():return []
    with closing(open_data()) as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='daily'").fetchone():return []
        query="SELECT * FROM daily"
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='sessions'").fetchone():
            query="SELECT daily.*, s.open,s.high,s.low,s.quantity,s.currency FROM daily LEFT JOIN sessions s USING(secid,board,day)"
        return [dict(r) for r in db.execute(query+" WHERE secid=? AND board=? AND day BETWEEN ? AND ? ORDER BY day",
                                            (secid,board,start,last))]


def credit_spreads(secid,board,start,at):
    """Yield less the interpolated sovereign zero rate at the bond's duration."""
    if board!="TQCB" or not DB.is_file():return []
    last=at[:10] if at.endswith("23:59:59") else str(date.fromisoformat(at[:10])-timedelta(days=1))
    with closing(open_data()) as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='bond_yields'").fetchone():return []
        result=[]
        for row in db.execute("SELECT * FROM bond_yields WHERE secid=? AND board=? AND day BETWEEN ? AND ? ORDER BY day",(secid,board,start,last)):
            curve=db.execute("SELECT years,yield_pct FROM curve WHERE day=? ORDER BY years",(row["day"],)).fetchall()
            years=row["duration"]/365
            for (t1,y1),(t2,y2) in zip(curve,curve[1:]):
                if t1<=years<=t2:
                    reference=y1+(y2-y1)*(years-t1)/(t2-t1)
                    result.append([row["day"],round(100*(row["ytm"]-reference),1)])
                    break
    return result

def statement_trends(reports):
    """Compare like measures in publications visible at the requested cutoff."""
    rules = [
        ("current_ratio", True, True, "покрытие краткосрочных обязательств оборотными активами"),
        ("cash_cover", True, True, "покрытие краткосрочного долга денежными средствами"),
        ("interest_cover", False, True, "покрытие процентных расходов операционной прибылью"),
        ("net_leverage", False, False, "долговая нагрузка относительно EBITDA"),
        ("debt_to_assets_pct", True, False, "доля финансового долга в активах"),
        ("cash_to_debt_pct", True, True, "покрытие финансового долга денежными средствами"),
        ("total_capital_adequacy_ratio", True, True, "достаточность капитала банка"),
        ("share_of_non_performing_loans", True, False, "доля проблемных кредитов"),
        ("ocf", False, True, "операционный денежный поток"),
    ]
    ends = {"":12,"Q4":12,"Q3":9,"M9":9,"H1":6,"Q2":6,"Q1":3}
    result = []
    for key, balance, higher_better, meaning in rules:
        groups = {}
        for r in reports:
            metric = r["metrics"].get(key)
            suffix = r["period"][4:]
            url = r.get("original") or r.get("url")
            if not metric or metric["value"] is None or suffix not in ends or not url:
                continue
            group = (r["standard"], metric["unit"], "" if balance else suffix)
            period_end = (int(r["period"][:4]), ends[suffix])
            points = groups.setdefault(group, {})
            point = dict(period=r["period"], value=metric["value"], published=r["published"], url=url)
            if period_end not in points or points[period_end]["published"] < point["published"]:
                points[period_end] = point
        eligible = [(g, p) for g,p in groups.items() if len(p)>=2]
        if not eligible:
            continue
        group, series = max(eligible,key=lambda pair:(max(pair[1]),len(pair[1])))
        values = [series[end] for end in sorted(series)[-4:]]
        delta = values[-1]["value"] - values[-2]["value"]
        direction = "усиливает" if (delta>0)!=higher_better else "ослабляет"
        explanation = (f"Изменение показателя «{meaning}» {direction} финансовое давление."
                       if delta else f"Показатель «{meaning}» остался на прежнем уровне.")
        result.append(dict(key=key,name=LABELS[key],unit=group[1],standard=group[0],points=values,
                           higher_better=higher_better,meaning=meaning,
                           delta=round(delta,6),explanation=explanation))
        if len(result)==3:
            break
    return result
