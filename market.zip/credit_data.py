"""Dated market and issuer evidence shared by the site, chat and JSON API."""
import json
import sqlite3
from contextlib import closing
from datetime import date, timedelta
from storage import ROOT, connect, now

DB = ROOT / "data/market.sqlite3"
INDICES = {
    "RGBI": "RGBI · чистые цены ОФЗ",
    "RUCBCPNS": "Корпоративные облигации · чистые цены",
    "RUCBTRNS": "Корпоративные облигации · совокупный доход",
    "RUCBTRAAANS": "Корпоративные облигации AAA · совокупный доход",
    "IMOEX": "Индекс Мосбиржи",
}
CURVE_URL = "https://www.cbr.ru/hd_base/zcyc_params/"
LABELS = {
    "revenue":"Выручка", "operating_income":"Операционная прибыль", "net_income":"Чистая прибыль",
    "ebitda":"EBITDA", "ocf":"Операционный денежный поток", "fcf":"Свободный денежный поток",
    "capex":"Капитальные затраты", "interest_expenses":"Процентные расходы", "assets":"Активы",
    "net_assets":"Чистые активы", "equity":"Собственный капитал", "cash":"Денежные средства",
    "debt":"Финансовый долг", "net_debt":"Чистый долг", "debt_ebitda":"Долг / EBITDA",
    "net_leverage":"Чистый долг / EBITDA", "interest_cover":"Покрытие процентов операционной прибылью",
    "cash_cover":"Денежные средства / краткосрочный долг", "current_ratio":"Текущая ликвидность",
    "current_assets":"Оборотные активы", "current_liabilities":"Краткосрочные обязательства",
    "short_term_debt":"Краткосрочный финансовый долг","long_term_debt":"Долгосрочный финансовый долг",
    "roe":"Рентабельность капитала","roa":"Рентабельность активов","net_margin":"Чистая рентабельность",
    "ebitda_margin":"Маржа EBITDA","net_interest_income":"Чистый процентный доход",
    "net_interest_margin":"Чистая процентная маржа","cost_of_risk":"Стоимость риска",
    "capital_adequacy":"Достаточность капитала","npl":"Проблемные кредиты","npl_ratio":"Доля проблемных кредитов",
    "core_capital_adequacy_ratio":"Достаточность основного капитала","total_capital_adequacy_ratio":"Достаточность общего капитала",
    "share_of_non_performing_loans":"Доля проблемных кредитов (NPL)","cost_of_risk_ratio":"Стоимость риска (CoR)",
    "net_intertest_margin":"Чистая процентная маржа","provision_for_loan_impairment":"Резервы под обесценение",
    "creation_of_provision_for_loan_impairment":"Создание резервов","capital":"Капитал","loan_portfolio":"Кредитный портфель",
}


def open_data():
    db = sqlite3.connect(DB.as_uri()+"?mode=ro", uri=True)
    db.row_factory=sqlite3.Row
    return db


def market(at):
    result={"series":[], "headlines":[], "bonds":[], "curve":None,"corporate":[]}
    if not DB.is_file():return result
    # Intraday cuts use the last complete trading day in the saved daily series.
    last=at[:10] if at[11:19]=="23:59:59" else (date.fromisoformat(at[:10])-timedelta(days=1)).isoformat()
    with closing(open_data()) as db:
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='curve'").fetchone():
            curve=db.execute("SELECT * FROM curve WHERE day=(SELECT max(day) FROM curve WHERE day<=?) ORDER BY years",(last,)).fetchall()
            if curve:
                day=curve[0]["day"]
                result["curve"]={"day":day,"points":[[r["years"],r["yield_pct"]] for r in curve],
                                 "url":CURVE_URL+"zcyc/?DateTo="+date.fromisoformat(day).strftime("%d.%m.%Y")}
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='corporate_yields'").fetchone():
            for code in ("RUCBTRNS","RUCBTRAAANS"):
                row=db.execute("SELECT * FROM corporate_yields WHERE code=? AND day<=? ORDER BY day DESC LIMIT 1",(code,last)).fetchone()
                if not row:continue
                item=dict(row);item["premium_bp"]=None;item["benchmark"]=None
                points=db.execute("SELECT years,yield_pct FROM curve WHERE day=? ORDER BY years",(row["day"],)).fetchall()
                years=row["duration_days"]/365
                for (t1,y1),(t2,y2) in zip(points,points[1:]):
                    if t1<=years<=t2:
                        spot=y1+(y2-y1)*(years-t1)/(t2-t1)
                        item.update(benchmark=round(spot,3),premium_bp=round(100*(row["yield_pct"]-spot)))
                        break
                item["url"]="https://iss.moex.com/iss/history/engines/stock/markets/index/boards/RTSI/securities/"+code+".json?from="+row["day"]+"&till="+row["day"]
                item["curve_url"]=CURVE_URL+"zcyc/?DateTo="+date.fromisoformat(row["day"]).strftime("%d.%m.%Y")
                result["corporate"].append(item)
        for code in ("KEY",*INDICES):
            completed=min(last,(date.fromisoformat(now()[:10])-timedelta(days=1)).isoformat())
            rows=db.execute("SELECT * FROM series WHERE code=? AND day<=? ORDER BY day DESC LIMIT 730",(code,last if code=="KEY" else completed)).fetchall()
            if rows:
                row=dict(rows[0]);row["points"]=[[r["day"],r["value"]] for r in reversed(rows)]
                row["label"]=INDICES.get(code,row["label"])
                row["previous"]=rows[1]["value"] if len(rows)>1 else None
                result["series"].append(row)
        result["headlines"]=[dict(r) for r in db.execute("SELECT * FROM headlines WHERE published<=? ORDER BY published DESC LIMIT 6",(at,))]
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='daily'").fetchone():
            with closing(connect()) as catalog:
                for board in ("TQOB","TQCB"):
                    for r in db.execute("""SELECT * FROM daily WHERE board=? AND day=(
                            SELECT max(day) FROM daily WHERE board=? AND day<=?) ORDER BY trades DESC,secid LIMIT 2""",(board,board,last)):
                        label=catalog.execute("SELECT short FROM bonds WHERE secid=?",(r["secid"],)).fetchone()
                        prev=db.execute("SELECT price FROM daily WHERE secid=? AND board=? AND day<? ORDER BY day DESC LIMIT 1",(r["secid"],board,r["day"])).fetchone()
                        result["bonds"].append({"code":r["secid"],"label":label[0] if label else r["secid"],"board":board,
                                  "day":r["day"],"unit":"% ном.","value":r["price"],"previous":prev[0] if prev else None})
    return result


def issuer_reports(inn,at):
    if not DB.is_file():return []
    with closing(open_data()) as db:
        rows=db.execute("""SELECT * FROM reports WHERE issuer=? AND published||'T23:59:59'<=?
                            ORDER BY published DESC,length(period),period DESC LIMIT 16""",(inn,at)).fetchall()
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='filing_numbers'").fetchone():
            rows+=db.execute("""SELECT n.issuer,n.period,'МСФО' standard,substr(n.published,1,10) published,
                '' ticker,f.url,f.url original,n.metrics FROM filing_numbers n JOIN filings f
                ON (n.issuer,n.uid,n.published)=(f.issuer,f.uid,f.published)
                WHERE f.issuer=? AND f.removed=0 AND f.published=(SELECT max(v.published) FROM filings v
                WHERE v.issuer=f.issuer AND v.uid=f.uid AND v.published<=?)""",(inn,at)).fetchall()
            rows.sort(key=lambda r:(r["published"],r["period"]),reverse=True)
    result=[]
    for row in rows:
        report=dict(row)
        report["provider"]="Smart-Lab" if "smart-lab.ru/" in report["url"] else ("Интерфакс · ЦРКИ" if "e-disclosure.ru/" in report["url"] else "Эмитент")
        metrics=json.loads(report.pop("metrics"))
        for field in metrics.values():field[1]=field[1].rsplit(",",1)[-1].strip()
        def ratio(key,numerator,denominator):
            a,b=metrics.get(numerator),metrics.get(denominator)
            if a and b and b[0]>0 and a[1] and a[1]==b[1]:metrics[key]=[round(a[0]/b[0],3),"×"]
        bank="loan_portfolio" in metrics or "total_capital_adequacy_ratio" in metrics
        if not bank:
            ratio("interest_cover","operating_income","interest_expenses")
            if len(report["period"])==4:ratio("net_leverage","net_debt","ebitda")
            ratio("current_ratio","current_assets","current_liabilities")
            ratio("cash_cover","cash","short_term_debt")
        flags=[]
        checks=[("ocf",0,"Операционная деятельность потребляет денежные средства."),
                ("fcf",0,"После капитальных затрат свободный денежный поток отрицателен."),
                ("net_income",0,"За отчётный период получен чистый убыток."),
                ("net_assets",0,"Чистые активы отрицательны."),
                ("interest_cover",1,"Операционная прибыль ниже процентных расходов."),
                ("current_ratio",1,"Краткосрочные обязательства превышают оборотные активы."),
                ("cash_cover",1,"Остаток денежных средств меньше краткосрочного финансового долга."),
                ("ebitda",0,"EBITDA отрицательна. Отношение долга к EBITDA теряет экономический смысл.")]
        for key,threshold,reason in checks:
            if bank and key in ("ocf","fcf","ebitda"):continue
            if key in metrics and metrics[key][0]<threshold:flags.append({"key":key,"text":reason})
        report["metrics"]={k:{"name":LABELS[k],"value":v[0],"unit":v[1]} for k,v in metrics.items() if k in LABELS}
        report["flags"]=flags
        result.append(report)
    for current in result:
        prior_period=str(int(current["period"][:4])-1)+current["period"][4:]
        previous=next((r for r in result if r["period"]==prior_period and r["standard"]==current["standard"]),None)
        if not previous:continue
        for key in ("net_leverage","interest_cover","revenue","cost_of_risk_ratio","share_of_non_performing_loans","total_capital_adequacy_ratio"):
            a,b=current["metrics"].get(key),previous["metrics"].get(key)
            if not a or not b or a["unit"]!=b["unit"]:continue
            rising=key in ("net_leverage","cost_of_risk_ratio","share_of_non_performing_loans")
            if (rising and a["value"]>b["value"]) or (not rising and a["value"]<b["value"]):
                current["flags"].append({"key":key,"text":f"{a['name']}: {b['value']:g} → {a['value']:g} {a['unit']} за год."})
    return result


def issuer_filings(inn,at,bond=None):
    if not DB.is_file():return []
    with closing(open_data()) as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='filings'").fetchone():return []
        rows=db.execute("""SELECT f.* FROM filings f WHERE issuer=? AND published<=?
            AND published=(SELECT max(v.published) FROM filings v WHERE v.issuer=f.issuer AND v.uid=f.uid AND v.published<=?)
            AND removed=0 AND (? IS NULL OR isin='' OR isin=?) ORDER BY published DESC,uid""",(inn,at,at,bond,bond))
        result={}
        for row in rows:result.setdefault(row["url"].lower(),dict(row))
        return list(result.values())


def bond_terms(bond,at):
    if not DB.is_file():return None
    with closing(open_data()) as db:
        row=db.execute("SELECT * FROM terms WHERE bond=? AND seen<=? ORDER BY seen DESC LIMIT 1",(bond,at)).fetchone()
    return dict(row) if row else None


def saved_prices(secid,board,start,last):
    if not DB.is_file():return []
    with closing(open_data()) as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='daily'").fetchone():return []
        return [dict(r) for r in db.execute("SELECT * FROM daily WHERE secid=? AND board=? AND day BETWEEN ? AND ? ORDER BY day",
                                            (secid,board,start,last))]
