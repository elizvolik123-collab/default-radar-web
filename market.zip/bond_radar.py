"""Point-in-time screening rules. Market warnings and payment facts retain their own scope."""
from datetime import date
import re
from analytics import registry
from credit_data import period_date, issuer_reports, issuer_filings
from risk_model import forecast, payment_history, shift
from payment_journal import calendar_outcomes

LEVELS={"red":"Высокий риск","yellow":"Повышенное внимание","green":"Низкий наблюдаемый риск","gray":"Недостаточно данных"}


def evaluate(s, issuer_registry, verified, prediction, reports, outcomes, filings=()):
    key=s["bond"]["id"]
    cutoff=date.fromisoformat(s["asof"][:10])
    def age(value):return (cutoff-date.fromisoformat(value[:10])).days
    factors=[]
    def note(level,scope,reason,day,url):
        factors.append(dict(level=level,scope=scope,reason=reason,day=day[:10],url=url))
    has_registry=verified and 0<=age(verified)<=14
    last_paid={(o["due"],o["kind"]):o for o in outcomes if o["actual"]}
    full_payments={(h["date"],h["kind"]):h for h in s.get("history",[]) if h["remaining"]==0 and h["day"]<=s["asof"][:10]}
    historical_open=False
    for r in issuer_registry:
        own=r["bond"]==key
        paid=r["executed"]
        if own and not paid:
            matched=last_paid.get((r["due"],r["kind"]))
            if matched:paid=matched["actual"]
            kind="Амортизация" if r["kind"]=="Амортизация номинальной стоимости" else r["kind"]
            settled=full_payments.get((r["due"],kind))
            if settled:paid=settled["day"]
        if paid and age(paid)>180:continue
        if not paid and not has_registry and age(r["observed"])>30:
            historical_open=True
            continue
        level="yellow" if paid or not own or r["status"]!="Дефолт" else "red"
        reason=f'{r["status"]} · {r["kind"]}, срок {r["due"]}. '
        reason+=f"Исполнено {paid}." if paid else "Дата исполнения в реестре не указана."
        scope="Выпуск" if own else "Другой выпуск эмитента · "+r["bond"]
        note(level,scope,reason,verified or r["observed"],r["url"])
        if own and paid and not r["executed"]:
            proof=settled or matched
            note("info","Выпуск","Подтверждение исполнения обязательства "+paid+".",proof["published"],proof["url"])
    for o in outcomes:
        if o["late"] and 0<=age(o["due"])<=180:
            note("yellow","Выпуск",f'Просрочен платёж со сроком {o["due"]}.',o["published"],o["url"])
            break
    for filing in filings:
        if filing["isin"]!=key or not 0<=age(filing["published"])<=180:continue
        if re.search("просроч|неисполн|требовани.{0,16}досрочн|реструктуризац",filing["title"],re.I):
            note("yellow","Раскрытие по выпуску",filing["title"]+". Проверьте последующие сообщения об исполнении.",filing["published"],filing["url"])
    f=prediction
    if f.get("state")=="signal":
        note("yellow" if f["alert"] else "info","Модель ближайшего платежа",
             ("Достигнут" if f["alert"] else "Не достигнут")+" ценовой порог предупреждения для платежа "+f["due"]+".",f["last"],f["url"])
    report=reports[0] if reports else None
    complete=False
    if report:
        # The age of accounts is measured from the end of the fiscal period.
        period=report["period"]
        end=period_date(period).isoformat()
        if 0<=age(end)<=370:
            metrics=report["metrics"]
            tests=(("interest_cover",1,"Покрытие процентов"),("current_ratio",1,"Текущая ликвидность"),
                   ("ocf",0,"Операционный денежный поток"),("equity",0,"Собственный капитал"))
            bank=any(k in metrics for k in ("loan_portfolio","net_interest_income","net_interest_margin","total_capital_adequacy_ratio"))
            complete=not bank and all(k in metrics for k in ("current_ratio","interest_cover","ocf"))
            for k,threshold,label in tests:
                if k not in metrics or bank and k!="equity":continue
                value=metrics[k]["value"]
                if value<threshold:
                    display=f"{value:g}".replace(".",",")
                    note("yellow","Эмитент",f'{label} за {period} составляет {display} {metrics[k]["unit"]}. Порог внимания {threshold:g}.',
                         report["published"],report["original"] or report["url"])
            leverage=metrics.get("net_leverage")
            if not bank and leverage and leverage["value"]>=4:
                display=f'{leverage["value"]:g}'.replace(".",",")
                note("yellow","Эмитент",f'Чистый долг / EBITDA за {period} составляет {display}×. Ориентир внимания радара — 4×. Интерпретация зависит от отрасли.',
                     report["published"],report["original"] or report["url"])
            if bank:
                for flag in report.get("flags",[]):
                    if flag["key"] in ("share_of_non_performing_loans","total_capital_adequacy_ratio","cost_of_risk_ratio"):
                        note("yellow","Банк-эмитент",flag["text"],report["published"],report["original"] or report["url"])
            if complete:
                note("info","Эмитент",f"Проверены ликвидность, покрытие процентов и денежный поток за {period}.",
                     report["published"],report["original"] or report["url"])
    last_good=next((o for o in outcomes if not o["late"] and o["actual"] and 0<=age(o["actual"])<=180),None)
    if last_good:note("info","Выпуск","Документировано своевременное исполнение платежа "+last_good["due"]+".",last_good["published"],last_good["url"])
    levels={n["level"] for n in factors}
    newer=report and any(v["published"][:10]>report["published"] and re.search("финансовая отч[её]тность|отч[её]тность (МСФО|РСБУ)",v["title"],re.I) for v in filings)
    ready=complete and has_registry and last_good and f.get("state")=="signal" and not historical_open and not newer
    level="red" if "red" in levels else "yellow" if "yellow" in levels else "green" if ready else "gray"
    gaps=[]
    if newer:gaps.append("В документах есть более свежая отчётность. Её числовые показатели пока не разобраны.")
    if not has_registry:gaps.append("Нет проверки реестра Мосбиржи за последние 14 дней.")
    if historical_open:gaps.append("Есть архивная запись без более позднего подтверждения состояния обязательства.")
    if not complete:gaps.append("Недостаточно сопоставимых показателей ликвидности, покрытия процентов и денежного потока за последние 370 дней.")
    if not last_good:gaps.append("Нет документированного своевременного платежа по выпуску за последние 180 дней.")
    if f.get("state")!="signal":gaps.append(f.get("reason") or "Рыночный прогноз ближайшего платежа недоступен.")
    factors.sort(key=lambda n:({"red":0,"yellow":1,"info":2}[n["level"]],n["scope"]!="Выпуск"))
    return dict(level=level,label=LEVELS[level],asof=cutoff.isoformat(),factors=factors,gaps=gaps,
                due=s["next"]["date"] if s.get("next") else None)


def risk_history(key, at, reports, current):
    from terminal import historical_profile
    days=sorted({r["published"][:10] for r in reports if r["published"][:10]<at[:10]})[-2:]
    history=[]
    for day in days:
        row=historical_profile(key,day)
        if row:
            history.append({"day":day,"level":row["level"],"reasons":row["assessment_reasons"]})
    if current:
        history.append({"day":at[:10],"level":current["level"],"reasons":current["assessment_reasons"]})
    return history


def credit_conclusion(radar, profile, prediction, facts, entries):
    """Issue-level reading of the calendar, expert assessment and payment forecast on one cutoff."""
    def result(tone,title,detail,proof=None):
        return dict(tone=tone,title=title,detail=detail,source=proof.get("url") if proof else None,
                    published=(proof.get("published") or proof.get("day")) if proof else None)
    unpaid=[];disputed=[];settled=[]
    for (_,due,kind),rows in facts.items():
        paid=[r for r in rows if r["actual"]]
        late=[r for r in rows if r["late"]]
        if late and len(late)!=len(rows):
            disputed.append((due,kind,max(late,key=lambda r:r["published"])))
        elif late and not paid:
            unpaid.append((due,kind,max(late,key=lambda r:r["published"])))
        elif paid:
            settled.append((due,kind,max(paid,key=lambda r:(r["actual"],r["published"]))))
    def latest(rows):
        return max(rows,key=lambda r:(r[0],r[2]["published"]))
    if unpaid:
        def event(row,status):
            return next((e for e in entries if e["due"]==row[0] and
                ("Амортизация" if e["kind"].startswith("Амортизац") else e["kind"])==row[1]
                and e["status"]==status),None)
        defaults=[row for row in unpaid if event(row,"Дефолт")]
        due,kind,proof=latest(defaults or unpaid)
        e=event((due,kind,proof),"Дефолт" if defaults else "Технический дефолт")
        title="Платёж просрочен"
        if e:
            proof=dict(url=e["url"],published=e["observed"])
            title="Зафиксирован "+e["status"].lower()
        return result("danger",title,
            f"{kind}, срок {due}. Подтверждение погашения задолженности в источниках отсутствует. Перед покупкой проверьте исполнение.",proof)
    if disputed:
        due,kind,proof=latest(disputed)
        return result("unknown","Статус выплаты требует сверки",f"Источники расходятся по обязательству «{kind}» со сроком {due}.",proof)
    blocks=(profile or {}).get("blocks",{})
    factors=[f for f in radar["factors"] if f.get("url") and f["level"] in ("red","yellow")]
    if radar["level"]=="red":
        candidates=sorted(blocks.values(),key=lambda f:-f["points"])
        proof=next(iter(factors or candidates),None)
        return result("danger","Высокий кредитный риск",proof["reason"] if proof else "Экспертная оценка выпуска находится в зоне высокого риска.",proof)
    if prediction.get("state")=="signal" and prediction["alert"]:
        return result("watch","Есть сигнал по ближайшей выплате",
            f"К сроку {prediction['due']} модель выявила ценовой сигнал риска. Последнее закрытие — {prediction['close']:g}% номинала.",
            dict(url=prediction["url"],day=prediction["last"]))
    if radar["level"]=="yellow" or factors:
        proof=next(iter(factors),None) or (profile or {}).get("financial_warning")
        if not proof and blocks:
            proof=max(blocks.values(),key=lambda f:f["points"])
        return result("watch","Проверьте фактор риска перед покупкой",
            proof["reason"] if proof else "Экспертная оценка выпуска повышена. Изучите основания ниже.",proof)
    last_paid=latest(settled)[2] if settled else None
    if radar["level"]=="green":
        proof=blocks.get("finance") or last_paid
        score=(profile or {}).get("score")
        basis=f"Экспертный индекс — {score:g} из 100." if score is not None else "Радар оценивает кредитный риск как низкий."
        return result("low","Можно рассматривать по кредитному риску",
            basis+" Сопоставьте доходность и срок погашения со своим горизонтом.",proof)
    if (profile or {}).get("kind")=="ОФЗ":
        return result("neutral","ОФЗ · сравните доходность и срок",
            "Эмитент — Российская Федерация. При продаже до погашения результат зависит от рыночной цены. Корпоративная модель к ОФЗ неприменима.",last_paid)
    if last_paid and not last_paid["late"]:
        return result("neutral","Последний подтверждённый платёж прошёл в срок",
            f"Дата исполнения — {last_paid['actual']}. Данных для вывода о низком кредитном риске пока недостаточно.",last_paid)
    return result("unknown","Недостаточно данных для решения",
        next(iter(radar.get("gaps",[])),"Нет достаточных датированных оснований для оценки кредитного риска."))


def assess(db,s,*,with_trends=False):
    b=s["bond"];at=s["asof"]
    reports=issuer_reports(b["issuer"],at)
    outcomes=payment_history(b["id"],at)
    prediction=forecast(db,s)
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='registry_checks'").fetchone():
        latest=db.execute("SELECT max(observed) FROM registry_checks WHERE observed<=?",(at,)).fetchone()
    else:
        latest=db.execute("SELECT success FROM refresh WHERE source=? AND success<=?",("MOEX · реестр дефолтов",at)).fetchone()
    entries=registry(db,None,at,issuer=b["issuer"])
    filings=issuer_filings(b["issuer"],at,b["id"])
    radar=evaluate(s,entries,latest[0] if latest else None,prediction,reports,outcomes,filings)
    from terminal import screen
    profile=screen(at,{"one":b["id"]})
    if profile:
        level={"Высокий":"red","Повышенный":"yellow","Низкий":"green"}.get(profile["level"],"gray")
        radar.update(level=level,label=LEVELS[level],assessment=profile["assessment_reasons"])
        warning=profile.get("financial_warning")
        if warning:
            radar["factors"].insert(0,dict(level="yellow",scope="Финансы эмитента",**{k:warning[k] for k in ("day","reason","url")}))
    facts=calendar_outcomes(db,"0001-01-01",shift(at[:10],1),at,b["id"])
    radar["conclusion"]=credit_conclusion(radar,profile,prediction,facts,[r for r in entries if r["bond"]==b["id"]])
    from credit_data import statement_trends
    trend_data=dict(trends=statement_trends(reports),risk_history=risk_history(b["id"],at,reports,profile)) if with_trends else {}
    return dict(**trend_data,radar=radar,financials=reports,outcomes=outcomes,forecast=prediction,filings=filings)
