"""Small Russian nearest-example classifier for retrieval in the offline edition."""
from collections import Counter
from functools import lru_cache
from math import log, sqrt
import re

EXAMPLES={
    "риск":("Насколько надёжна эта бумага","Может ли компания подвести держателей","Стоит ли опасаться за деньги","Хватит ли средств расплатиться","Почему у бумаги жёлтый свет","Способна ли компания обслуживать долг","О чём предупреждает светофор"),
    "документ":("Где посмотреть основания вывода","На основании чего это известно","Покажи доказательства","Что сообщил представитель владельцев","Какие есть материалы по этому займу","На что ссылается эмитент"),
    "исполнение":("Дошли ли деньги в назначенный день","Держателям уже заплатили","Что получили владельцы","Были ли задержки перечислений","Когда закрыли задолженность"),
    "календарь":("Какая выплата на очереди","Когда ждать деньги по этой бумаге","Сколько осталось до следующего перечисления","Что предстоит выплатить"),
    "финансы":("Что видно из баланса компании","За счёт чего фирма обслуживает долг","Зарабатывает ли компания на основной деятельности","Как дела с деньгами у предприятия","Достаточно ли оборотных активов"),
    "цена":("Как менялась стоимость бумаги","Что происходило с ценой на торгах","Сколько давали за бумагу","Покажи динамику котировки"),
}

def grams(question):
    words=re.findall(r"[а-яa-z]+",question.lower().replace("ё","е"))
    return Counter(g for w in words if len(w)>2 for word in ["^"+w+"$"]
                   for size in (3,4) for g in (word[i:i+size] for i in range(len(word)-size+1)))

@lru_cache(maxsize=1)
def fitted():
    docs=[(topic,grams(q)) for topic,examples in EXAMPLES.items() for q in examples]
    counts=Counter(term for _,doc in docs for term in doc)
    weights={t:1+log((1+len(docs))/(1+n)) for t,n in counts.items()}
    return weights,[(t,{k:v*weights[k] for k,v in doc.items()}) for t,doc in docs]

def infer(question):
    weights,docs=fitted()
    vector={t:n*weights[t] for t,n in grams(question).items() if t in weights}
    length=sqrt(sum(v*v for v in vector.values()))
    if not length:return []
    scores={}
    for topic,doc in docs:
        score=sum(vector.get(t,0)*v for t,v in doc.items())/(length*sqrt(sum(v*v for v in doc.values())))
        scores[topic]=max(scores.get(topic,0),score)
    first,second=sorted(scores,key=scores.get,reverse=True)[:2]
    return [first] if scores[first]>=0.3 and scores[first]-scores[second]>=0.045 else []
