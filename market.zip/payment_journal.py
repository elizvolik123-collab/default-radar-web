"""Daily observed schedules and documented outcomes. Missing confirmation stays unknown."""
import sqlite3
from contextlib import closing
from datetime import date, timedelta

from analytics import dated_plans
from risk_model import HISTORY
from storage import connect, now

SCHEMA = """
CREATE TABLE IF NOT EXISTS payment_journal(
 day TEXT, observed TEXT, bond TEXT, due TEXT, kind TEXT, entry TEXT, published TEXT,
 actual TEXT, late INTEGER, per_unit REAL, currency TEXT, url TEXT,
 PRIMARY KEY(day,bond,due,kind,entry,url,published));
CREATE INDEX IF NOT EXISTS journal_bond ON payment_journal(bond,observed);
CREATE TABLE IF NOT EXISTS journal_days(day TEXT PRIMARY KEY,observed TEXT,plans INTEGER,facts INTEGER);
"""


def record(catalog,history,stamp):
    history.executescript(SCHEMA)
    day=stamp[:10]
    end=(date.fromisoformat(day)+timedelta(days=90)).isoformat()
    plans=[]
    for inn, in catalog.execute("SELECT DISTINCT issuer FROM bonds WHERE traded=1"):
        first_due={}
        for row in dated_plans(catalog,inn,stamp):
            first_due.setdefault(row["bond"],row["date"])
            if row["date"]<=end or row["date"]==first_due[row["bond"]]:
                plans.append((day,stamp,row["bond"],row["date"],row["kind"],"plan",row["known"],
                              None,None,row["per_unit"],row["currency"],row["source"]))
    facts=[]
    for b,d,k,actual,late,pub,url in history.execute(
            "SELECT bond,due,kind,actual,late,published,url FROM evidence WHERE source<>'MOEX' AND published||'T23:59:59'<=? AND due<=?",(stamp,day)):
        if not actual or actual<=day:
            facts.append((day,stamp,b,d,k,"fact",pub,actual,late,None,None,url))
    registry_evidence=[]
    for b,d,k,actual,pub,url in catalog.execute("""SELECT m.bond,m.due,m.kind,m.executed,m.observed,m.url
        FROM moex_defaults m JOIN bonds b ON b.id=m.bond AND b.issuer=m.inn
        WHERE m.observed<=? AND m.due<=? ORDER BY m.observed""",(stamp,day)):
        if k.startswith("Амортизац"):k="Амортизация"
        execution=actual if actual and actual<=day else None
        facts.append((day,stamp,b,d,k,"fact",pub,execution,1,None,None,url))
        registry_evidence.append((b,d,k,1,execution,pub[:10],url,url,"MOEX"))
    # One copy of each observation per day. A retry preserves the first time it was visible.
    with history:
        if registry_evidence:
            history.executemany("INSERT OR IGNORE INTO evidence(bond,due,kind,late,actual,published,url,terms_url,source) VALUES(?,?,?,?,?,?,?,?,?)",registry_evidence)
        history.executemany("INSERT OR IGNORE INTO payment_journal VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",plans+facts)
        counts=dict(history.execute("SELECT entry,count(*) FROM payment_journal WHERE day=? GROUP BY entry",(day,)))
        history.execute("INSERT OR REPLACE INTO journal_days VALUES(?,?,?,?)",(day,stamp,counts.get("plan",0),counts.get("fact",0)))
    return counts


def entries(bond,at):
    if not HISTORY.is_file():return []
    with closing(sqlite3.connect(HISTORY.as_uri()+"?mode=ro",uri=True)) as db:
        db.row_factory=sqlite3.Row
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='payment_journal'").fetchone():return []
        rows=db.execute("""SELECT * FROM payment_journal WHERE bond=? AND observed<=?
            ORDER BY observed DESC,CASE entry WHEN 'plan' THEN 0 ELSE 1 END,abs(julianday(due)-julianday(day)),published DESC""",(bond,at))
        result=[];seen=set()
        for row in rows:
            key=tuple(row[k] for k in ("due","kind","entry","published","url","actual","late","per_unit","currency"))
            if key in seen:continue
            seen.add(key);result.append(dict(row))
            if len(result)==40:break
        return result


if __name__=="__main__":
    with closing(connect()) as catalog, closing(sqlite3.connect(HISTORY)) as history:
        print(record(catalog,history,now()))


def calendar_outcomes(catalog, start, end, at):
    '''Sources available for each obligation at the analysis cutoff.'''
    from collections import defaultdict
    facts = defaultdict(list)
    day = at[:10]

    def add(bond, due, kind, late, actual, published, url, terms=None):
        if not url or not url.startswith(('https://','http://')) or due>day:
            return
        kind = 'Амортизация' if kind.startswith('Амортизац') else kind
        if actual and actual>day:
            actual = None
        facts[bond,due,kind].append(dict(late=late,actual=actual,published=published,url=url,terms=terms))

    if HISTORY.is_file():
        with closing(sqlite3.connect(HISTORY.as_uri()+'?mode=ro',uri=True)) as history:
            for row in history.execute('''SELECT bond,due,kind,late,actual,published,url,terms_url FROM evidence
                WHERE source<>'MOEX' AND due>=? AND due<? AND published||'T23:59:59'<=?''',(start,end,at)):
                add(*row)
    for row in catalog.execute('''SELECT m.bond,m.due,m.kind,1,m.executed,m.observed,m.url
        FROM moex_defaults m JOIN bonds b ON b.id=m.bond AND b.issuer=m.inn
        WHERE m.due>=? AND m.due<? AND m.observed<=?''',(start,end,at)):
        add(*row)
    for bond,due,kind,status,actual,published,url,terms in catalog.execute('''SELECT p.bond,p.date,p.kind,x.status,x.day,d.published,d.url,p.source
        FROM executions x JOIN plans p ON p.id=x.plan JOIN documents d ON d.id=x.document
        WHERE p.date>=? AND p.date<? AND x.day<=? AND (CASE WHEN length(d.published)=10 THEN d.published||'T23:59:59' ELSE d.published END)<=?''',(start,end,day,at)):
        if status in ('Срок нарушен','Исполнено с опозданием','Исполнено в срок'):
            add(bond,due,kind,int(status!='Исполнено в срок'),actual if status.startswith('Исполнено') else None,published,url,terms)
    return facts
