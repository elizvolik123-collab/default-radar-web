"""Seven-day early warning for rouble corporate coupons, trained on documented outcomes."""
import csv
import hashlib
import json
import math
import os
import sqlite3
from collections import Counter, defaultdict
from contextlib import closing
from functools import lru_cache
from datetime import date, timedelta
from pathlib import Path
from urllib.parse import quote

from storage import ROOT, connect, now

DATA=ROOT/"data"
HISTORY=DATA/"payment_history.sqlite3"
MODEL=DATA/"risk_model.json"
CUTOFF="2026-01-01"
LEAD=7

def shift(day,delta):
    return (date.fromisoformat(day)+timedelta(days=delta)).isoformat()

def features(points,anchor):
    """Use two actual trading sessions on or before the seven-day prediction date."""
    recent=sorted((d,p) for d,p in points if shift(anchor,-45)<=d<=anchor and p and p>0)
    if not recent or recent[-1][0]<shift(anchor,-10):return None
    past=[(d,p) for d,p in recent if d<=shift(anchor,-18)]
    if not past:return None
    last,close=recent[-1];start,old=past[-1]
    # Scale in advance, independently of all training and test observations.
    clip=lambda v:max(-4,min(4,v))
    return {"x":[clip((100-close)/20),clip((old-close)/10)],"start":start,"last":last,"close":close,"change":round(close-old,4)}

def score(beta,x):
    v=max(-35,min(35,beta[0]+sum(w*a for w,a in zip(beta[1:],x))))
    return 1/(1+math.exp(-v))

def fit(train):
    """Regularized logistic regression. Equal class and within-class issuer weight."""
    counts=Counter((r["late"],r["issuer"]) for r in train)
    issuers=Counter(y for y,_ in counts)
    if len(issuers)!=2:raise ValueError("Для обучения нужны оба исхода")
    weighted=[(r["x"],r["late"],0.5/(issuers[r["late"]]*counts[r["late"],r["issuer"]])) for r in train]
    beta=[0.]*(1+len(train[0]["x"]))
    for _ in range(1800):
        g=[0.,*(.06*w for w in beta[1:])]
        for x,y,w in weighted:
            e=(score(beta,x)-y)*w
            for j,a in enumerate([1,*x]):g[j]+=e*a
        if max(map(abs,g))<1e-8:break
        beta=[v-.4*grad for v,grad in zip(beta,g)]
    return beta

def metrics(ys,scores,threshold):
    n=len(ys);pos=sum(ys);neg=n-pos
    tp=sum(y==1 and s>=threshold for y,s in zip(ys,scores));fp=sum(y==0 and s>=threshold for y,s in zip(ys,scores))
    groups=defaultdict(list)
    for y,s in zip(ys,scores):groups[s].append(y)
    below=0;wins=0;cum=0;seen=0;ap=0
    for s,labels in sorted(groups.items()):
        p=sum(labels);z=len(labels)-p
        wins+=p*(below+z/2);below+=z
    for s,labels in sorted(groups.items(),reverse=True):
        p=sum(labels);cum+=p;seen+=len(labels);ap+=p*cum/seen
    return dict(n=n,late=pos,ontime=neg,tp=tp,fp=fp,fn=pos-tp,tn=neg-fp,
        roc_auc=round(wins/(pos*neg),4) if pos and neg else None,average_precision=round(ap/pos,4) if pos else None,
        recall=round(tp/pos,4) if pos else None,precision=round(tp/(tp+fp),4) if tp+fp else None)

def canonical(db,before=None):
    groups=defaultdict(list)
    query="SELECT * FROM evidence"+(" WHERE published<?" if before else "")+" ORDER BY published,url"
    for r in db.execute(query,(before,) if before else ()):groups[r["bond"],r["due"],r["kind"]].append(dict(r))
    result=[];conflicts=0
    for (bond,due,kind),claims in sorted(groups.items()):
        if len({r["late"] for r in claims})!=1:
            conflicts+=1;continue
        first=claims[0].copy()
        confirmation=next((r for r in claims if r["actual"]),None)
        first["actual"]=confirmation["actual"] if confirmation else None
        first["actual_known"]=confirmation["published"] if confirmation else None
        first["sources"]=list(dict.fromkeys(r["url"] for r in claims))
        result.append(first)
    return result,conflicts

@lru_cache(maxsize=2048)
def statement_features(issuer,anchor):
    from credit_data import issuer_reports
    # Date-only filings become available at the end of the prior date.
    reports=issuer_reports(issuer,shift(anchor,-1)+"T23:59:59")
    for report in reports:
        period=report["period"]
        endings={"":"12-31","Q1":"03-31","Q2":"06-30","Q3":"09-30","Q4":"12-31","H1":"06-30","H2":"12-31"}
        end=endings.get(period[4:])
        if not period[:4].isdigit() or not end or not shift(anchor,-550)<=period[:4]+"-"+end<anchor:
            continue
        metrics=report["metrics"]
        if {"loan_portfolio","total_capital_adequacy_ratio"} & metrics.keys():
            continue
        ratios=[]
        for a,b,neutral,scale in (
            ("cash","current_liabilities",.15,.20),("equity","assets",.20,.25),
        ):
            left,right=metrics.get(a),metrics.get(b)
            if left and right and left["unit"]==right["unit"] and right["value"]>0:
                ratios.append(max(-4,min(4,(neutral-left["value"]/right["value"])/scale)))
            else:
                ratios.append(None)
        if any(v is not None for v in ratios):
            return ratios,report["published"],report["original"] or report["url"]
    return [None,None],None,None


def compare_financial_features(train,test,first_delay,baseline):
    def extend(rows):
        result=[]
        for r in rows:
            values,published,url=statement_features(r["issuer"],r["anchor"])
            result.append({**r,"x_fin":r["x"]+[v if v is not None else 0. for v in values],
                           "published_fin":published,"url_fin":url})
        return result

    training,testing=extend(train),extend(test)
    weights=fit([{**r,"x":r["x_fin"]} for r in training])
    def evaluate(rows):
        y=[r["late"] for r in rows]
        return {"price_only":metrics(y,[score(baseline,r["x"]) for r in rows],.5),
                "plus_financials":metrics(y,[score(weights,r["x_fin"]) for r in rows],.5)}

    first_events=defaultdict(list)
    for r in testing:
        if r["late"] and r["due"]==first_delay.get(r["issuer"]):
            first_events[r["issuer"]].append(r)
    # Keep all bonds on the first date, but count the issuer only once.
    # Report false alerts per on-time obligation in the same later sample.
    on_time=[r for r in testing if not r["late"]]
    hits=lambda beta,key:sum(any(score(beta,r[key])>=.5 for r in rows) for rows in first_events.values())
    return {"split":CUTOFF,"threshold":.5,"weights":weights,"all_coupons":evaluate(testing),
            "on_time":evaluate(on_time),
            "first_late_issuers":{"total":len(first_events),"baseline_hits":hits(baseline,"x"),
                "candidate_hits":hits(weights,"x_fin"),
                "with_financials":sum(any(r["published_fin"] for r in rows) for rows in first_events.values())},
            "coverage":{"training":[sum(bool(r["published_fin"]) for r in training),len(training)],
                        "testing":[sum(bool(r["published_fin"]) for r in testing),len(testing)]}}


def train_model(compare_financials=False):
    with closing(connect()) as main,closing(sqlite3.connect(HISTORY)) as hist:
        hist.row_factory=sqlite3.Row
        bonds={r["id"]:dict(r) for r in main.execute("SELECT * FROM bonds")}
        units=dict(hist.execute("SELECT bond,faceunit FROM instruments"))
        allowed={r[0] for r in main.execute("SELECT DISTINCT bond FROM boards WHERE board='TQCB'")}
        prices=defaultdict(list)
        for b,d,p in hist.execute("SELECT * FROM prices"):prices[b].append((d,p))
        preannounced={}
        for b,d,k,known,url in main.execute("SELECT bond,date,kind,known,source FROM plans"):
            key=(b,d,k);value=(known[:10],url)
            if key not in preannounced or value<preannounced[key]:preannounced[key]=value
        for b,d,known,url in hist.execute("SELECT bond,due,known,url FROM announced"):
            key=(b,d,"Купон");value=(known,url)
            if key not in preannounced or value<preannounced[key]:preannounced[key]=value
        payments,conflicts=canonical(hist)
        original,_=canonical(hist,CUTOFF)
        identity=lambda r:(r["bond"],r["due"],r["kind"])
        original={identity(r):r for r in original}
        # Train off the state of the label archive at the split, even if a subsequent
        # correction removes an event from the modern consensus used for evaluation.
        present={identity(r) for r in payments}
        payments.extend({**v,"training_only":True} for k,v in original.items() if k not in present)
        training=defaultdict(list);testing=defaultdict(list);audited=[]
        for item in payments:
            bond=item["bond"];b=bonds[bond];anchor=shift(item["due"],-LEAD)
            use=item["kind"] in ("Купон","Амортизация","Погашение","Оферта") and bond in allowed and (units.get(bond) or b["currency"]) in ("RUB","RUR","SUR")
            x=features(prices[bond],shift(anchor,-1)) if use else None
            notice=preannounced.get((bond,item["due"],item["kind"]))
            row={**item,"issuer":b["issuer"],"name":b["name"],"anchor":anchor,**(x or {}),
                 "schedule_known":notice[0] if notice else None,"schedule_url":notice[1] if notice else None}
            if x:row["price_url"]=f"https://iss.moex.com/iss/engines/stock/markets/bonds/boards/TQCB/securities/{quote(b['secid'])}/candles.json?interval=24&from={x['start']}&till={x['last']}"
            if not use:split="вне сегмента"
            elif not x:split="нет предшествующих торгов"
            elif item["due"]<CUTOFF and identity(item) in original:
                split="обучение";training[item["kind"]].append({**row,"late":original[identity(item)]["late"]})
            elif anchor>=CUTOFF:
                split="проверка";testing[item["kind"]].append(row)
            else:split="исход ещё не был опубликован к границе обучения"
            row["split"]=split;audited.append(row)
        train=training["Купон"];test=testing["Купон"]
        if len({r["late"] for r in test})!=2:raise ValueError("В позднем периоде недостаточно классов")
        beta=fit(train)
        seen={r["issuer"] for r in train}
        def evaluate(rows):
            ys=[r["late"] for r in rows];ps=[score(beta,r["x"]) for r in rows]
            return metrics(ys,ps,.5)
        # A naive ranking and a fixed market-price rule do not use test labels.
        naive=metrics([r["late"] for r in test],[0]*len(test),.5)
        rule=metrics([r["late"] for r in test],[100-r["close"] for r in test],10)
        first_delay={}
        for r in audited:
            if r["late"]:
                first_delay[r["issuer"]]=min(first_delay.get(r["issuer"],r["due"]),r["due"])
        if compare_financials:return compare_financial_features(train,test,first_delay,beta)
        first_test=[r for r in test if not r["late"] or r["due"]==first_delay.get(r["issuer"])]
        counts=lambda rows:dict(n=len(rows),late=sum(r["late"] for r in rows),ontime=sum(not r["late"] for r in rows),
            issues=len({r["bond"] for r in rows}),issuers=len({r["issuer"] for r in rows}),
            first=min(r["due"] for r in rows),last=max(r["due"] for r in rows))
        variants={"Купон":{"weights":beta,"train":counts(train),"test":{**counts(test),**evaluate(test)}}}
        for kind in ("Амортизация","Погашение","Оферта"):
            a,z=training[kind],testing[kind]
            if min(sum(r["late"]==y for r in a) for y in (0,1))>=5 and len({r["late"] for r in z})==2:
                w=fit(a)
                variants[kind]={"weights":w,"train":counts(a),"test":{
                    **counts(z),**metrics([r["late"] for r in z],[score(w,r["x"]) for r in z],.5)}}
        horizons={str(LEAD):variants}
        for h in range(1,LEAD):
            horizons[str(h)]={}
            for kind in variants:
                a=[];z=[]
                for r in audited:
                    if r["kind"]!=kind or r["split"]=="вне сегмента":continue
                    anchor=shift(r["due"],-h)
                    x=features(prices[r["bond"]],shift(anchor,-1))
                    if x:
                        item={**r,**x}
                        if r["due"]<CUTOFF and identity(r) in original:a.append({**item,"late":original[identity(r)]["late"]})
                        elif anchor>=CUTOFF:z.append(item)
                if len({r["late"] for r in a})==2 and z:
                    w=fit(a)
                    horizons[str(h)][kind]={"weights":w,"train":counts(a),"test":{
                        **counts(z),**metrics([r["late"] for r in z],[score(w,r["x"]) for r in z],.5)}}
        hold=lambda issuer:int(hashlib.sha256(issuer.encode()).hexdigest(),16)%3==0
        subset=[r for r in train if not hold(r["issuer"])]
        independent=[r for r in test if hold(r["issuer"])]
        stress=None
        if len({r["late"] for r in subset})==2 and independent:
            w=fit(subset)
            stress={**metrics([r["late"] for r in independent],[score(w,r["x"]) for r in independent],.5),
                    "issuers":len({r["issuer"] for r in independent})}
        for r in audited:
            if r["kind"] not in variants and r["split"] in ("обучение","проверка"):
                r["split"]="недостаточно исходов для этого вида обязательства"
        model=dict(version=2,built=now()[:10],cutoff=CUTOFF,lead_days=LEAD,weights=beta,threshold=.5,variants=variants,horizons=horizons,issuer_holdout=stress,
            universe=counts([r for r in audited if not r.get("training_only")]),conflicts=conflicts,excluded=dict(Counter(r["split"] for r in audited)),
            train=counts(train),test={**counts(test),**evaluate(test)},unseen=evaluate([r for r in test if r["issuer"] not in seen]),
            first_defaults=evaluate(first_test),
            preannounced=evaluate([r for r in test if r["schedule_known"] and r["schedule_known"]<=r["anchor"]]),
            baseline=naive,price_rule=rule,sources=dict(Counter(r["source"] for r in audited)),
            performing_issuers=len({r["issuer"] for r in audited if not r["late"]}),
            train_performing_issuers=len({r["issuer"] for r in train if not r["late"]}),
            price_observations=sum(map(len,prices.values())),download_errors=hist.execute("SELECT count(*) FROM downloads").fetchone()[0])
        examples={}
        for r in sorted(test,key=lambda v:v["due"],reverse=True):
            predicted=score(beta,r["x"])>=.5
            code=("сигнал" if predicted else "без сигнала")+(" · просрочка" if r["late"] else " · в срок")
            if code not in examples:
                secid=bonds[r["bond"]]["secid"]
                examples[code]={"name":r["name"],"id":r["bond"],"due":r["due"],"anchor":r["anchor"],"url":r["url"],"outcome":code,
                    "price_url":f"https://iss.moex.com/iss/engines/stock/markets/bonds/boards/TQCB/securities/{quote(secid)}/candles.json?interval=24&from={r['start']}&till={r['last']}"}
        model["examples"]=list(examples.values())
        name=DATA/"payment_outcomes.csv"
        fields=["bond","issuer","name","due","kind","late","actual","actual_known","published","source","url","terms_url","sources",
                "anchor","schedule_known","schedule_url","start","last","close","change","price_url","split","signal"]
        with name.with_suffix(".tmp").open("w",encoding="utf-8-sig",newline="") as f:
            w=csv.DictWriter(f,fields,extrasaction="ignore");w.writeheader()
            for row in audited:w.writerow({**row,"sources":" ".join(row["sources"]),
                "signal":int(score(variants[row["kind"]]["weights"],row["x"])>=.5)
                         if row["split"]=="проверка" and row["kind"] in variants else ""})
        os.replace(name.with_suffix(".tmp"),name)
        tmp=MODEL.with_suffix(".tmp");tmp.write_text(json.dumps(model,ensure_ascii=False,indent=2),encoding="utf-8");os.replace(tmp,MODEL)
        write_report(model)
        print(json.dumps(model,ensure_ascii=False,indent=2))

def write_report(m):
    f=lambda v:"—" if v is None else str(v).replace(".",",")
    u=m["universe"];tr=m["train"];te=m["test"]
    lines=["# Дефолт-радар. Проверка прогноза платежей","",
        f"Сборка {m['built']}. В истории {u['n']} уникальных обязательств по {u['issues']} выпускам {u['issuers']} эмитентов. "
        f"Подтверждено {u['ontime']} своевременных выплат и {u['late']} просрочек. Противоречивых обязательств исключено {m['conflicts']}.","",
        "## Постановка","",
        "Единица наблюдения — выпуск, договорный срок и вид обязательства. Просрочкой считается нарушение срока, включая частичную выплату. "
        "Неизвестный исход пропускается. Фактическая дата исполнения остаётся пустой при отсутствии подтверждения закрытия долга.","",
        f"Основной тест фиксирован за семь календарных дней до срока. Есть отдельные оценки за один–шесть дней. "
        f"Обучение использует только исходы, опубликованные до {m['cutoff']}. В проверку попадают решения начиная с этой даты. "
        "Переходная неделя исключена из семидневного теста. Модели для разных горизонтов проверяются отдельно на платежах соответствующего периода.","",
        "Входы — отклонение биржевой цены от 100% номинала и изменение цены между двумя завершёнными сессиями. "
        "Последняя цена датирована не позднее дня перед прогнозом и отстоит от него максимум на 11 дней. "
        "Для сравнения нужна ещё одна сессия за 19–46 дней до прогноза. ISIN, эмитент, источник результата и сведения о последующей выплате не являются признаками.","",
        "Логистическая регрессия с L2-регуляризацией использует равные веса классов и равный суммарный вес эмитентов внутри каждого класса. "
        "Коэффициент регуляризации 0,06 и порог предупреждения 0,5 зафиксированы до итогового расчёта. Значение функции модели служит пороговым сигналом. Денежная вероятность потерь и рыночная вероятность дефолта не оценивались.","",
        "## Результаты проверки","",
        f"Основная купонная модель обучена на {tr['n']} платежах {tr['issuers']} эмитентов за {tr['first']} – {tr['last']}. "
        f"В обучении {tr['late']} просрочек и {tr['ontime']} своевременных купонов. Проверка охватывает {te['first']} – {te['last']}, {te['issuers']} эмитентов.","",
        "| Обязательство и горизонт | Проверено | Просрочено | Предупреждено | Пропущено | Ложных тревог | ROC AUC | Средняя точность (AP) |",
        "|---|---:|---:|---:|---:|---:|---:|---:|"]
    def result(name,v):
        lines.append("| "+" | ".join([name]+[f(v[k]) for k in ("n","late","tp","fn","fp","roc_auc","average_precision")])+" |")
    for h in ("7","3","1"):
        for kind,v in m["horizons"][h].items():result(f"{kind} · {h} дн.",v["test"])
    result("Купон · 7 дн. · постоянный прогноз",m["baseline"])
    result("Купон · 7 дн. · цена ≤ 90% номинала",m["price_rule"])
    result("Купон · 7 дн. · эмитенты, отсутствующие в обучении",m["unseen"])
    result("Купон · 7 дн. · только первая зафиксированная дата просрочки эмитента и все своевременные",m["first_defaults"])
    result("Купон · 7 дн. · подтверждённый до прогноза срок обязательства",m["preannounced"])
    if m["issuer_holdout"]:result("Купон · 7 дн. · переобучение с исключением группы эмитентов по хэшу ИНН",m["issuer_holdout"])
    lines+=["","Порог ценового ориентира — 90% номинала. Его ROC AUC считается по непрерывному рангу цены. Для постоянного прогноза ранги равны. "
        "Средняя точность AP чувствительна к доле просрочек. Наблюдения одного эмитента зависимы. Каждая строка таблицы оценивается отдельно.","",
        "## Охват и ограничения","",
        f"В обучении купонной модели своевременные выплаты подтверждены у {m['train_performing_issuers']} эмитентов. "
        "Реестр нарушений имеет более широкий охват, чем выборка своевременных выплат. Доля просрочек в базе не является частотой по рынку. "
        "Сравнение с правилом по цене помогает оценить добавочную ценность модели. Для калибровки нужна последовательная история всех назначенных выплат в заранее определённой совокупности выпусков.","",
        "В тесте срок ретроспективно восстановлен по обязательству. Полный ежедневный архив объявленных графиков на все даты отсутствует. "
        "Результаты измеряют распознавание риска при известной дате платежа. Для текущей карточки приложение дополнительно проверяет наличие графика на дату анализа. "
        "Входные торговые данные — исторические биржевые наблюдения в доступной на момент сбора версии. "
        "Модель применима к рублёвым корпоративным выпускам TQCB при доступных ценах. Причина пропуска видна в карточке и в обзоре рынка.","",
        "## Данные и воспроизведение","",
        "Первичные сообщения эмитентов, распространённые АК&М, отобраны по открытой ленте по средам и пятницам. Для расширения обучения в ноябре–декабре 2025 года использованы также остальные рабочие дни. "
        "Архив «Роснефти» и сообщения лизинговых компаний дополняют выборку. Для записей публичного реестра Мосбиржи без исходной даты публикации используется дата первого наблюдения. "
        "Более раннюю осведомлённость подтверждают датированные сообщения представителя владельцев облигаций. "
        f"В журнале загрузки осталось {m['download_errors']} запросов с ошибками. Исключённые строки и основания доступны в CSV.","",
        "[История обязательств и результаты по строкам](data/payment_outcomes.csv) · [Коэффициенты и метрики всех горизонтов](data/risk_model.json) · "
        "[Публичные раскрытия АК&М](https://www.disclosure.ru/rus/corpnews/) · [Московская биржа](https://www.moex.com/ru/listing/emidocs.aspx?type=4)","",
        "Для повторной сборки на Windows нужен Python. Импорт PDF «Роснефти» дополнительно использует пакет pypdf. Команды запускаются из папки проекта.","",
        "~~~powershell","python collect_payments.py evidence","python issuer_reports.py","python market_disclosures.py","python market_disclosures.py --plans","python collect_payments.py plans","python collect_payments.py currencies",
        "python collect_payments.py prices","python collect_payments.py upcoming","python risk_model.py","python -m unittest test_forecast test_radar","~~~",""]
    path=ROOT/"RISK_REPORT.md";temp=path.with_suffix(".tmp");temp.write_text("\n".join(lines),encoding="utf-8");os.replace(temp,path)

def report():
    return json.loads(MODEL.read_text(encoding="utf-8")) if MODEL.exists() else None

def payment_history(bond,at):
    if not HISTORY.exists():return []
    with closing(sqlite3.connect(HISTORY.as_uri()+"?mode=ro",uri=True)) as db:
        db.row_factory=sqlite3.Row
        rows=db.execute("""SELECT bond,due,kind,late,actual,published,url,source,terms_url FROM evidence
            WHERE bond=? AND due<=? AND published||'T23:59:59'<=? AND (actual IS NULL OR actual<=?)
            ORDER BY due DESC,published DESC""",(bond,at[:10],at,at[:10]))
        groups=defaultdict(list)
        for r in rows:groups[r["due"],r["kind"]].append(dict(r))
        return [rs[0] for rs in groups.values() if len({r["late"] for r in rs})==1]

def forecast(main,snapshot,model=None):
    model=model or report();plan=snapshot["next"];bond=snapshot["bond"];today=snapshot["asof"][:10]
    def pending(reason,**extra):return dict(state="unavailable",reason=reason,**extra)
    if not model:return pending("Обучение модели ещё не завершено.")
    if not plan:return pending("На эту дату неизвестен срок следующего платежа.")
    remaining=(date.fromisoformat(plan["date"])-date.fromisoformat(today)).days
    anchor=max(today,shift(plan["date"],-LEAD))
    info={"due":plan["date"],"kind":plan["kind"],"anchor":anchor,"terms":plan["source"],"horizon":remaining}
    # The model is frozen at the split. Pre-build dates are explicitly a retrospective simulation.
    if anchor<model["cutoff"]:return pending("Срок относится к периоду до временной проверки.",**info)
    faceunit=bond["currency"]
    if not faceunit and HISTORY.exists():
        with closing(sqlite3.connect(HISTORY.as_uri()+"?mode=ro",uri=True)) as hist:
            row=hist.execute("SELECT faceunit FROM instruments WHERE bond=?",(bond["id"],)).fetchone()
            faceunit=row[0] if row else None
    if plan["kind"] not in model["variants"] or faceunit not in ("RUB","RUR","SUR") or not main.execute(
        "SELECT 1 FROM boards WHERE bond=? AND board='TQCB' AND firstday<=?",(bond["id"],anchor)).fetchone():
        return pending("Для этого типа обязательства, валюты или режима торгов модель ещё не проверена.",**info)
    if remaining>LEAD:return pending("Первый прогноз появится за семь дней до выплаты.",**info)
    if today>now()[:10]:return pending("Дата прогноза ещё не наступила.",**info)
    variant=model["horizons"].get(str(remaining),{}).get(plan["kind"])
    if not variant:return pending("Для этого горизонта пока недостаточно подтверждений.",**info)
    cutoff=min(snapshot["asof"],now())
    known=plan["known"]+("T23:59:59" if len(plan["known"])==10 else "")
    if known>cutoff:
        prior=main.execute("""SELECT source FROM plans WHERE bond=? AND date=? AND kind=? AND
            (CASE WHEN length(known)=10 THEN known||'T23:59:59' ELSE known END)<=? ORDER BY known LIMIT 1""",
            (bond["id"],plan["date"],plan["kind"],cutoff)).fetchone()
        if not prior and plan["kind"]=="Купон" and HISTORY.exists():
            with closing(sqlite3.connect(HISTORY.as_uri()+"?mode=ro",uri=True)) as hist:
                prior=hist.execute("SELECT url FROM announced WHERE bond=? AND due=? AND known||'T23:59:59'<=? ORDER BY known LIMIT 1",
                    (bond["id"],plan["date"],cutoff)).fetchone()
        if not prior:return pending("К дате прогноза этот срок ещё не был подтверждён в архиве.",**info)
        info["terms"]=prior[0]
    end=shift(anchor,-1);lo=shift(end,-45)
    points=dict(main.execute("SELECT day,price FROM quotes WHERE bond=? AND board='TQCB' AND day BETWEEN ? AND ?",
        (bond["id"],lo,end)))
    if HISTORY.exists():
        with closing(sqlite3.connect(HISTORY.as_uri()+"?mode=ro",uri=True)) as hist:
            points.update(hist.execute("SELECT day,close FROM prices WHERE bond=? AND day BETWEEN ? AND ?",(bond["id"],lo,end)))
    x=features(points.items(),end)
    if not x:return pending("Недостаточно сохранённых торгов до даты прогноза.",**info)
    signal=score(variant["weights"],x["x"])>=model["threshold"]
    url=f"https://iss.moex.com/iss/engines/stock/markets/bonds/boards/TQCB/securities/{quote(bond['secid'])}/candles.json?interval=24&from={x['start']}&till={x['last']}"
    return {**info,"state":"signal","alert":signal,"retrospective":anchor<model["built"],"close":x["close"],"change":x["change"],
        "last":x["last"],"start":x["start"],"url":url}

def market_watch(main,at):
    day=at[:10];model=report()
    plans=main.execute("""SELECT p.bond,p.date,p.kind,p.source,p.known,b.name,b.secid,b.currency
        FROM plans p JOIN bonds b ON b.id=p.bond WHERE p.date>=? AND p.date<=? AND
        (CASE WHEN length(p.known)=10 THEN p.known||'T23:59:59' ELSE p.known END)<=?
        ORDER BY p.date,b.name,p.known DESC""",(day,shift(day,7),at))
    seen=set();earliest={};scored=[];skipped=Counter()
    from credit_data import covered_bonds
    allowed = covered_bonds(main, at)
    for p in plans:
        if p['bond'] not in allowed or not p['source']:
            continue
        key=(p["bond"],p["kind"])
        if key in seen or earliest.setdefault(p["bond"],p["date"])!=p["date"]:continue
        seen.add(key)
        b={"id":p["bond"],"secid":p["secid"],"currency":p["currency"]}
        f=forecast(main,{"next":p,"bond":b,"asof":at},model)
        if f["state"]=="signal":scored.append({**f,"id":p["bond"],"name":p["name"]})
        else:skipped[f["reason"]]+=1
    scored.sort(key=lambda r:(not r["alert"],r["due"],r["name"]))
    return {"issues":len(earliest),"payments":len(seen),"scored":len(scored),"alerts":sum(s["alert"] for s in scored),
            "rows":scored,"skipped":dict(skipped)}

if __name__=="__main__":
    import sys
    if sys.argv[1:]==["--compare-financials"]:
        print(json.dumps(train_model(compare_financials=True),ensure_ascii=False,indent=2))
    else:
        train_model()
